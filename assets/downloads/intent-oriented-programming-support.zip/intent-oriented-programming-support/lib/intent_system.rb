# frozen_string_literal: true

require "json"

class IntentSystem
  attr_reader :intents

  def self.define(&block)
    system = new
    system.instance_eval(&block)
    system
  end

  def initialize
    @intents = []
  end

  def intent(name, &block)
    node = Intent.new(name)
    node.instance_eval(&block)
    @intents << node
    node
  end

  def to_h
    { intents: intents.map(&:to_h) }
  end

  def to_json(*args)
    JSON.pretty_generate(to_h, *args)
  end

  def to_mermaid
    lines = ["flowchart LR"]
    intents.each_with_index do |intent, i|
      id = "I#{i}"
      lines << %(  #{id}["🎯 #{intent.name}"])
      intent.evidence_items.each_with_index do |item, j|
        eid = "#{id}E#{j}"
        lines << %(  #{eid}["🧾 #{item}"] --> #{id})
      end
      intent.delegates.each_with_index do |item, j|
        aid = "#{id}A#{j}"
        lines << %(  #{id} --> #{aid}["🤖 #{item}"])
      end
      intent.verifications.each_with_index do |item, j|
        vid = "#{id}V#{j}"
        lines << %(  #{id} --> #{vid}["🧪 #{item}"])
      end
      intent.observations.each_with_index do |item, j|
        oid = "#{id}O#{j}"
        lines << %(  #{id} --> #{oid}["📊 #{item}"])
      end
    end
    lines.join("\n")
  end

  class Intent
    attr_reader :name, :evidence_items, :outcomes, :required_constraints,
                :preserved_constraints, :delegates, :verifications,
                :observations, :revision_sources

    def initialize(name)
      @name = name
      @evidence_items = []
      @outcomes = []
      @required_constraints = []
      @preserved_constraints = []
      @delegates = []
      @verifications = []
      @observations = []
      @revision_sources = []
    end

    def evidence(*items) = @evidence_items.concat(items)
    def outcome(*items) = @outcomes.concat(items)
    def delegate(*items) = @delegates.concat(items)
    def verify(*items) = @verifications.concat(items)
    def observe(*items) = @observations.concat(items)
    def revise_from(*items) = @revision_sources.concat(items)

    def constraints(&block)
      instance_eval(&block)
    end

    def require(*items) = @required_constraints.concat(items)
    def preserve(*items) = @preserved_constraints.concat(items)

    def to_h
      {
        name: name,
        evidence: evidence_items,
        outcomes: outcomes,
        constraints: {
          require: required_constraints,
          preserve: preserved_constraints
        },
        delegates: delegates,
        verify: verifications,
        observe: observations,
        revise_from: revision_sources
      }
    end
  end
end

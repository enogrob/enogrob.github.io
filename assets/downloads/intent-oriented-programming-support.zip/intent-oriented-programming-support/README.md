# Intent-Oriented Programming — companion experiment

A tiny dependency-free Ruby experiment for the post **Intent-Oriented Programming**.

## Run

```bash
ruby examples/checkout_intent.rb
ruby test/intent_system_test.rb
```

The example writes:

- `generated/intent-system.json`
- `generated/intent-system.mmd`

The experiment is intentionally small. It tests one idea only: the same Ruby declaration can be executable **and** expose an explicit semantic model.

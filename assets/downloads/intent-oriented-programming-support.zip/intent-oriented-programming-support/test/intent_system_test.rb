# frozen_string_literal: true

require "minitest/autorun"
require_relative "../lib/intent_system"

class IntentSystemTest < Minitest::Test
  def setup
    @system = IntentSystem.define do
      intent :reduce_checkout_failure do
        evidence :support_tickets, :checkout_metrics
        outcome :successful_checkout
        constraints do
          require :pci_compliance
          preserve :idempotency
        end
        delegate :architecture, :implementation
        verify :checkout_contract
        observe :success_rate
        revise_from :incidents
      end
    end
  end

  def test_builds_one_intent
    assert_equal 1, @system.intents.size
    assert_equal :reduce_checkout_failure, @system.intents.first.name
  end

  def test_preserves_semantic_categories
    intent = @system.intents.first
    assert_includes intent.evidence_items, :support_tickets
    assert_includes intent.required_constraints, :pci_compliance
    assert_includes intent.preserved_constraints, :idempotency
    assert_includes intent.verifications, :checkout_contract
  end

  def test_serializes_to_json
    parsed = JSON.parse(@system.to_json)
    assert_equal "reduce_checkout_failure", parsed.fetch("intents").first.fetch("name")
  end

  def test_generates_mermaid
    mermaid = @system.to_mermaid
    assert_includes mermaid, "flowchart LR"
    assert_includes mermaid, "reduce_checkout_failure"
    assert_includes mermaid, "checkout_contract"
  end
end

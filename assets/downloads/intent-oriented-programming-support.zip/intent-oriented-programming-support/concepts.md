# Concept vocabulary

- **Intent** — the change or outcome the system is trying to make real.
- **Evidence** — observations or sources that justify the intent.
- **Constraint** — properties that must survive implementation.
- **Outcome** — what counts as success.
- **Delegation** — bounded responsibilities assigned to agents or humans.
- **Verification** — explicit checks that test whether the implementation is acceptable.
- **Observation** — runtime or real-world signals gathered after execution.
- **Feedback** — evidence that can revise the original intent.

The philosophical references in the post are conceptual lenses, not claims that software engineering literally implements Bohm's physics, Minsky's cognitive theory, or Krishnamurti's philosophy.

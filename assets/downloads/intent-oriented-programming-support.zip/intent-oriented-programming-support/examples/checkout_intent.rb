# frozen_string_literal: true

require_relative "../lib/intent_system"

system = IntentSystem.define do
  intent :reduce_checkout_failure do
    evidence :support_tickets, :checkout_metrics, :payment_errors
    outcome :successful_checkout

    constraints do
      require :pci_compliance
      preserve :idempotency
    end

    delegate :architecture, :implementation, :verification
    verify :checkout_contract, :payment_failure_paths
    observe :success_rate, :latency, :retry_rate
    revise_from :incidents, :customer_feedback
  end
end

File.write(File.join(__dir__, "../generated/intent-system.json"), system.to_json)
File.write(File.join(__dir__, "../generated/intent-system.mmd"), system.to_mermaid)

puts system.to_json

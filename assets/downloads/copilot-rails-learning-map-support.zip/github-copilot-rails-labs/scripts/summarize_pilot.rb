#!/usr/bin/env ruby
# Aggregate, explicitly supplied pilot observations only. No GitHub API or user identifiers.
require "csv"

COLUMNS = %w[period cohort eligible_developers active_developers prs_reviewed review_rework_count escaped_defects policy_incidents].freeze
COUNTS = COLUMNS.drop(2).freeze

path = ARGV.fetch(0) { abort "Usage: ruby scripts/summarize_pilot.rb PATH_TO_AGGREGATE_CSV" }
rows = CSV.read(path, headers: true)
abort "Invalid columns: expected #{COLUMNS.join(',')}" unless rows.headers == COLUMNS
abort "No observations yet. Keep this template blank until approved aggregate measurements exist." if rows.empty?
abort "Avoid printing small-cohort results: secure an approved reporting threshold first." unless ENV["PILOT_AGGREGATE_REPORT_APPROVED"] == "yes"

puts "| Period | Cohort | Eligible | Active | Reach | PRs reviewed | Rework | Escaped defects | Policy incidents |"
puts "|---|---|---:|---:|---:|---:|---:|---:|---:|"
rows.each_with_index do |row, index|
  period = row["period"]&.strip
  cohort = row["cohort"]&.strip
  abort "Row #{index + 2}: period and cohort are required" if period.nil? || period.empty? || cohort.nil? || cohort.empty?
  abort "Row #{index + 2}: period/cohort must be safe aggregate labels" unless [period, cohort].all? { |value| value.match?(/\A[a-zA-Z0-9 _.-]+\z/) }
  counts = COUNTS.to_h do |column|
    value = row[column]&.strip
    abort "Row #{index + 2}: #{column} must be a nonnegative integer" unless value&.match?(/\A\d+\z/)
    [column, value.to_i]
  end
  abort "Row #{index + 2}: active exceeds eligible" if counts["active_developers"] > counts["eligible_developers"]
  reach = if counts["eligible_developers"].zero?
            "n/a"
          else
            format("%.1f%%", counts["active_developers"] * 100.0 / counts["eligible_developers"])
          end
  puts "| #{period} | #{cohort} | #{counts['eligible_developers']} | #{counts['active_developers']} | #{reach} | #{counts['prs_reviewed']} | #{counts['review_rework_count']} | #{counts['escaped_defects']} | #{counts['policy_incidents']} |"
end
warn "Reach is activity, not productivity. No causal conclusion is calculated."

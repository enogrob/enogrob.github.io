#!/usr/bin/env ruby
# frozen_string_literal: true

# Checks that a local evidence record is complete. It cannot attest to authenticity.
require 'json'
require 'pathname'

root = Pathname.new(File.expand_path('..', __dir__)).realpath
input = ARGV.fetch(0) { abort 'Usage: ruby scripts/08_validate_evidence.rb parts/08-repeatable-rails-workflow/EVIDENCE.json' }
record = JSON.parse(File.read(input))
errors = []

def local_file(root, value)
  return false unless value.is_a?(String) && !value.empty?

  path = Pathname.new(File.expand_path(value, root))
  return false unless path.file?

  path.realpath.to_s.start_with?(root.to_s + File::SEPARATOR)
end

%w[task test_command reviewer decision].each do |key|
  errors << "#{key} is missing" unless record[key].is_a?(String) && !record[key].strip.empty?
end

sources = record['source_files']
if !sources.is_a?(Array) || sources.empty?
  errors << 'source_files must list existing local files'
else
  sources.each { |path| errors << "source file missing/outside repository: #{path}" unless local_file(root, path) }
end

%w[candidate_diff test_log].each do |key|
  errors << "#{key} file missing/outside repository" unless local_file(root, record[key])
end

status = record['test_exit_code']
errors << 'test_exit_code must be an integer from a real run' unless status.is_a?(Integer) && status >= 0

if errors.any?
  warn "EVIDENCE RECORD INCOMPLETE (#{errors.length} finding#{errors.length == 1 ? '' : 's'}):"
  errors.each { |error| warn "- #{error}" }
  exit 1
end

puts 'Evidence record structure complete; human review must verify the command log, provenance, results and authorization.'
puts "Recorded test exit code: #{status} (not independently verified by this script)."

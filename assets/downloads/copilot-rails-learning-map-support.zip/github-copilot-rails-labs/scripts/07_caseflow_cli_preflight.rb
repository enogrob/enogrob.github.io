#!/usr/bin/env ruby
# frozen_string_literal: true

# Read-only source fingerprint for the Part 07 CLI lab. Does not run Rails or Copilot.
require 'digest'

root = File.expand_path('..', __dir__)
sources = {
  'baseline routes' => 'caseflow/config/routes.rb',
  'request controller' => 'caseflow/app/controllers/api/requests_controller.rb',
  'request model' => 'caseflow/app/models/service_request.rb',
  'request specs' => 'caseflow/spec/requests/api/requests_spec.rb',
  'candidate patch' => 'parts/03-issue-to-pr/candidate.patch',
  'CLI instructions' => 'caseflow/.github/copilot-instructions.md'
}

puts '# CaseFlow CLI lab · local source preflight'
puts
puts '| Source | File | Status | SHA-256 (first 12 hex) |'
puts '|---|---|---|---|'
sources.each do |label, relative|
  absolute = File.join(root, relative)
  if File.file?(absolute)
    puts "| #{label} | `#{relative}` | present | `#{Digest::SHA256.file(absolute).hexdigest[0, 12]}` |"
  else
    puts "| #{label} | `#{relative}` | missing | — |"
  end
end

puts
lock = File.join(root, 'caseflow/Gemfile.lock')
puts "Dependency lockfile: #{File.file?(lock) ? 'present (review its origin and resolution)' : 'absent (bundle install will resolve versions)'}"
puts 'Status: source fingerprint only; no bundle install, Rails spec, Copilot CLI or CI was run.'

#!/usr/bin/env ruby
# frozen_string_literal: true

# Check portable article image URLs in every chapter, not just the blog edition.
require "pathname"

repo = File.expand_path("..", __dir__)
articles = Dir.glob(File.join(repo, "docs/posts/*/article.md")).sort
errors = []
errors << "no companion articles found" if articles.empty?

articles.each do |article_path|
  article = File.read(article_path)
  chapter = File.basename(File.dirname(article_path))
  paths = []
  paths << article[/^image:\s*(\S+)/, 1]
  paths.concat(article.scan(/<img\s+[^>]*src=["']([^"']+)["']/).flatten)
  errors << "#{chapter}: missing image metadata or inline image" if paths.first.nil? || paths.length < 2

  paths.compact.each do |relative|
    reference = Pathname.new(relative)
    if reference.absolute? || !relative.start_with?("assets/") || reference.each_filename.include?("..")
      errors << "#{chapter}: image must be relative to its chapter assets/: #{relative}"
      next
    end

    image = File.expand_path(relative, File.dirname(article_path))
    unless File.file?(image)
      errors << "#{chapter}: missing #{relative}"
      next
    end

    signature = File.binread(image, 12)
    errors << "#{chapter}: invalid WebP image #{relative}" unless signature.start_with?("RIFF") && signature.byteslice(8, 4) == "WEBP"
  end

  errors << "#{chapter}: portable article uses a Jekyll Mermaid fence" if article.include?("```mermaid!\n")
end

errors.each { |problem| warn "BLOCKED: #{problem}" }
puts "Companion image check: #{errors.empty? ? 'PASSED' : 'BLOCKED'} (#{articles.length} articles)"
exit(errors.empty? ? 0 : 1)

# Part 04 · Rails CI and DevSecOps gates

A complete [article](../../docs/posts/04-ci-and-devsecops/article.md), [staged workflow](rails-pr.yml), [review worksheet](REVIEW-GATES.md), [source diagram](../../docs/diagrams/04-ci-evidence.mmd) and [workbook with answers](../../docs/labs/04-ci-and-devsecops-workbook.md) are included. The integrated CaseFlow baseline remains unchanged. The candidate feature is a separate [Part 03 patch](../03-issue-to-pr/candidate.patch).

## Contents

- [Prepare the exercise](#prepare)
- [Checks and limits](#checks)
- [References](#references)

## Prepare the exercise {:#prepare}

From a clean companion repository root, inspect and apply the Part 03 patch if you want its new status-transition specs. In `caseflow/` on a Mac with Ruby 3.3 or a compatible version:

```bash
git apply --check parts/03-issue-to-pr/candidate.patch
git apply parts/03-issue-to-pr/candidate.patch
cd caseflow
bundle install
RAILS_ENV=test bin/rails db:prepare
bundle exec rspec spec/requests/api/requests_spec.rb
```

Review and commit the resulting `caseflow/Gemfile.lock` *before* copying [`rails-pr.yml`](rails-pr.yml) to `.github/workflows/rails-pr.yml`. This sample enforces frozen dependencies, has read-only content permission, and uses a PR trigger. Verify action version/pinning and branch rules before use. If setup fails, capture the first error; do not claim a test passed. The sample does not activate itself.

## Checks and limits {:#checks}

Use [REVIEW-GATES.md](REVIEW-GATES.md) to distinguish the proposed workflow from observed runner results and unresolved production identity policy. Brakeman, CodeQL and dependency review are proposed layered controls, not installed or executed by this lab. No lockfile, CI result, release approval or live PR exists in this package.

## References {:#references}

- [Series map](../../docs/series-map.md)
- [GitHub Docs: Ruby CI](https://docs.github.com/en/actions/tutorials/build-and-test-code/ruby)
- [GitHub Docs: dependency review](https://docs.github.com/en/code-security/how-tos/secure-your-supply-chain/manage-your-dependency-security/configure-dependency-review-action)

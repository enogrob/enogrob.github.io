# Part 04 · Review gates and evidence worksheet

## Contents

- [Run record](#record)
- [Gate decisions](#decisions)
- [Failure examples](#examples)
- [References](#references)

## Run record {:#record}

| Field | Your observed value |
|---|---|
| Commit SHA / branch | **Not run in authoring environment**; replace after real run |
| Mac Ruby / Bundler versions | Record `ruby -v` and `bundle -v` |
| Lockfile included and reviewed? | Baseline has no `caseflow/Gemfile.lock` |
| Candidate patch applied? | Record `git apply --check` and local diff; baseline unmodified |
| Focused RSpec command and exit status | Record exact command, output and exit; pending |
| CI run URL + status | Pending; sample is staged outside `.github/workflows/` |
| Security controls configured + results | Pending; do not infer a pass |
| Reviewer decision + reason | Pending human review |

## Gate decisions {:#decisions}

1. Confirm issue scope and authorization policy. The shared operator token is a lab assumption; name the owner of a production actor/rotation/audit decision.
2. Compare proposed specs to positive and negative authorization, invalid transition, and error cases. Do not conflate assertions with observed results.
3. Run focused RSpec after app setup and record exact commit/exit/log. If setup blocks, stop and document the first blocker.
4. For dependency review: confirm repository support, PR trigger and what new dependency was introduced. Review lockfile diff.
5. For Brakeman: add it as a reviewed dependency, commit a new lockfile, run on the Rails app and capture output/limits. For CodeQL: configure repository scanning separately where available and review actual alerts.
6. Review workflow token scope (`contents: read`) and avoid checkout of untrusted PR code with privileged secrets.
7. Make a human approval/request-changes/escalation decision based on observed evidence and product policy.

## Failure examples {:#examples}

The following are **hypothetical classification examples**, not captured CaseFlow results.

| Observed later, if it occurs | Classification | Next action |
|---|---|---|
| `bundle install` cannot resolve a reviewed lockfile | Setup blocker | Record first error, check Ruby/Bundler and lockfile; no spec result |
| RSpec reports an unauthorized request returned 200 | Behavioral failure | Inspect guard, params and negative spec; request changes |
| Static scan reports a warning | Finding requiring triage | Read source and severity; do not suppress without rationale |
| Every configured job passes, actor policy undecided | Policy gap | Escalate decision; green CI alone cannot authorize release |

## References {:#references}

- [Full article](../../docs/posts/04-ci-and-devsecops/article.md)
- [Staged workflow](rails-pr.yml)
- [GitHub Docs: Ruby in GitHub Actions](https://docs.github.com/en/actions/tutorials/build-and-test-code/ruby)
- [GitHub Docs: secure use of Actions](https://docs.github.com/en/actions/reference/security/secure-use)

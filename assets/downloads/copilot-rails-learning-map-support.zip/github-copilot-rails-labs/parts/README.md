# Series parts

Each part owns an entrypoint and its own reviewable evidence. The shared [`caseflow/` Rails app](../caseflow/README.md) evolves through the series; content assets remain linked by part.

- [Series guide · start here](series-guide/README.md)
- [Part 01](01-first-30-minutes/README.md)
- [Part 02](02-context-and-instructions/README.md)
- [Part 03 · Reviewable PR candidate](03-issue-to-pr/README.md)
- [Part 04 · Rails CI, security and review](04-ci-and-devsecops/README.md)
- [Part 05 · Measurable adoption pilot](05-adoption-and-governance/README.md)
- [Part 06 · Client workshop and roadmap](06-client-workshop/README.md)
- [Part 07 · Copilot CLI and a reviewable Rails change](07-cli-rails-change/README.md)
- [Part 08 · Repeatable Rails Copilot workflow](08-repeatable-rails-workflow/README.md)

## References

- [Series map](../docs/series-map.md)

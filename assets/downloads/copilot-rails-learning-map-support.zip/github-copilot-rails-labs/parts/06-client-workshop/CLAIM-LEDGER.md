# CaseFlow workshop · claim ledger template

## Contents

- [Claims](#claims)
- [Decision prompts](#prompts)
- [References](#references)

## Claims {:#claims}

| Claim or proposal | Source or document | Evidence status | Verification needed | Owner |
|---|---|---|---|---|
| `POST /api/requests` is declared in the route file | `caseflow/config/routes.rb` | Source declaration | Run request spec for runtime contract | Rails maintainer |
| `ServiceRequest` validates presence and length of title | `caseflow/app/models/service_request.rb` | Source declaration | Run focused request spec and inspect output | Rails maintainer |
| Status transition API is available in baseline | `caseflow/config/routes.rb` | **Unsupported**: no status route in baseline | Inspect Part 03 candidate patch before proposing change | Rails maintainer |
| Candidate status PR passed review | `parts/03-issue-to-pr/candidate.patch` supports only a proposed diff | **Unknown**; no review result is supplied | Obtain actual diff review and CI run | Engineering owner |
| Copilot trial improved delivery | Header-only CSV in Part 05 | **Unknown**; no trial data | Get permission, collect baseline and comparable outcomes | Pilot owner |

Replace this worked teaching example with links to the *actual* reviewed branch and outputs when the workshop is run. The fourth row deliberately distinguishes an existing candidate artifact from a missing review result.

## Decision prompts {:#prompts}

- Which claims are source declarations, proposed artifacts, observations, or unknowns?
- What is the smallest approved check that would change each unknown?
- Who can accept a risk, and what is their recorded decision?

## References {:#references}

- [Part 03 candidate](../03-issue-to-pr/candidate.patch) · [Part 04 planned workflow](../04-ci-and-devsecops/rails-pr.yml) · [Part 05 charter](../05-adoption-and-governance/PILOT-CHARTER.md)

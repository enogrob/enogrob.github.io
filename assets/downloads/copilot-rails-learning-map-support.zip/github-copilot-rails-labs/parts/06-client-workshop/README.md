# Part 06 · From Rails Evidence to Client Roadmap

The [complete post](../../docs/posts/06-client-workshop/article.md) shows how to facilitate a hypothetical 90-minute client session around CaseFlow. There is no real client approval or measured Copilot outcome.

## Contents

- [Prepare](#prepare)
- [Run the exercise](#exercise)
- [Artifacts](#artifacts)
- [References](#references)

## Prepare {:#prepare}

Read the [facilitator agenda](WORKSHOP-AGENDA.md) and [claim ledger](CLAIM-LEDGER.md). Open the [complete CaseFlow app](../../caseflow/README.md), [candidate patch](../03-issue-to-pr/candidate.patch), [staged workflow](../04-ci-and-devsecops/rails-pr.yml) and [empty Part 05 pilot charter](../05-adoption-and-governance/PILOT-CHARTER.md). Do not present proposals as passed runs.

## Run the exercise {:#exercise}

1. Choose a bounded client question and identify source declarations.
2. Challenge an unsupported performance or review claim. Name the next check.
3. Facilitate the agenda with engineering and security roles; log unresolved authorization.
4. Fill the [roadmap](ROADMAP.md) and [decision record](DECISION-RECORD.md) with hypothetical placeholders only.
5. Attempt the [workbook and answer key](../../docs/labs/06-workshop-workbook.md), then rehearse the two-minute recommendation.

Ruby and Rails application code stays in `caseflow/`. The workshop adds Markdown and Mermaid learning material, no new application code.

## Artifacts {:#artifacts}

- [Post source](../../docs/posts/06-client-workshop/article.md) · [workbook and answers](../../docs/labs/06-workshop-workbook.md)
- [Agenda](WORKSHOP-AGENDA.md) · [claim ledger](CLAIM-LEDGER.md) · [roadmap](ROADMAP.md) · [decision record](DECISION-RECORD.md)
- [Editable diagram](../../docs/diagrams/06-workshop-decision.mmd) · [visual manifest and PNG masters](../../docs/posts/06-client-workshop/post-manifest.md)

## References {:#references}

- [GitHub Copilot rollout](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale) · [trial measurement](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success)
- [Series map](../../docs/series-map.md)

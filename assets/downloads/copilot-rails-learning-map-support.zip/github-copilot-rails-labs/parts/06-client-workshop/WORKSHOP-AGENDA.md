# Part 06 · 90-minute client workshop (proposed)

## Contents

- [Preparation](#preparation)
- [Agenda](#agenda)
- [Facilitation prompts](#facilitation)
- [Output and limits](#output)
- [References](#references)

## Preparation {:#preparation}

Invite the engineering owner, Rails maintainer, security reviewer and a representative developer; ask the client who has authority to approve access and a pilot. Bring [the CaseFlow source atlas](../../docs/architecture/README.md), the [candidate patch](../03-issue-to-pr/candidate.patch), [staged CI plan](../04-ci-and-devsecops/rails-pr.yml) and [empty pilot charter](../05-adoption-and-governance/PILOT-CHARTER.md). These are synthetic teaching artifacts; do not claim the patch passed, the workflow ran, or the pilot happened. Do not share customer code or private telemetry without authorization.

## Agenda {:#agenda}

| Minutes | Activity | Artifact to produce | Decision owner |
|---|---|---|---|
| 0–10 | State one business constraint and a bounded Rails task | Agreed question and scope | Engineering owner |
| 10–25 | Walk the route → controller → model evidence, and mark unknowns | [Claim ledger](CLAIM-LEDGER.md) | Rails maintainer |
| 25–45 | Inspect candidate diff and planned CI/security gates | Verification backlog, no fictional pass | Maintainer + security |
| 45–60 | Discuss Copilot surfaces, prompt data and pilot baseline | Scope/guardrail decisions | Security + engineering |
| 60–80 | Select next experiment, owners and stop rule | [Roadmap](ROADMAP.md) | Engineering owner |
| 80–90 | Replay risks and next checkpoint aloud | [Decision record](DECISION-RECORD.md) | Sponsor or delegate |

This is a facilitator's *example*, not a prescribed enterprise policy or a completed meeting. Adapt timeboxes to the team's actual authority and available evidence.

## Facilitation prompts {:#facilitation}

1. “Point to a source file for that behavior. What would require a run?”
2. “The PR is proposed. Which review and CI evidence would change your decision?”
3. “Which Copilot surface are we approving, for which data and repository?”
4. “What would make us pause even if activity increased?”
5. “Who owns the next check, by when, and who can approve the next cohort?”

## Output and limits {:#output}

Produce a short claim ledger, scoped roadmap and decision record, each with source, unknowns, owner and explicit acceptance evidence. If access or policy facts are absent, record them as open questions. Refer to [the Part 05 charter](../05-adoption-and-governance/PILOT-CHARTER.md) for any future actual trial; its CSV remains blank.

## References {:#references}

- [Complete article](../../docs/posts/06-client-workshop/article.md) · [lab and answers](../../docs/labs/06-workshop-workbook.md)
- [GitHub's Copilot rollout guide](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale) · [trial measurement guide](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success)

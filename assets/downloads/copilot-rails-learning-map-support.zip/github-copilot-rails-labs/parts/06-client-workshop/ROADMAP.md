# One-page roadmap · proposed, unapproved

## Contents

- [Decision frame](#frame)
- [Work slices](#slices)
- [Exit criteria](#exit)
- [References](#references)

## Decision frame {:#frame}

**Client question:** Can a consenting Rails team use Copilot to orient in CaseFlow-like code and propose a small, reviewable change under existing review and data boundaries? This template carries no client approval, observed schedule or realized benefit.

**Sponsor:** to be assigned. **Security reviewer:** to be assigned. **Pilot participants and approved surfaces:** to be agreed. **Checkpoint date:** to be agreed.

## Work slices {:#slices}

| Order | Small deliverable | Evidence required before claiming completion | Owner | Stop or revise trigger |
|---|---|---|---|---|
| 1 · Orient | Validate route, model, test and unknown map | File citations plus actual test output or reproducible blocker | Rails maintainer (assign) | Source claim disagrees with observed behavior |
| 2 · Review | Inspect Part 03 candidate diff, choose applicable CI gates | Human review, test output and security decision | Engineering + security (assign) | Unsafe prompt data or failed control |
| 3 · Pilot design | Agree cohort, surfaces, baseline, retention and criteria | Approved charter and permission record; **no collected metrics supplied** | Sponsor + pilot owner (assign) | Consent/policy gap, missing baseline or confounded work |
| 4 · Checkpoint | Review comparable adoption, quality and safety evidence if collected | Decision record with limitations and named approver | Sponsor (assign) | Insufficient evidence → revise; breach → pause |

Suggested slices are sequential dependencies, **not elapsed-day promises**. During a real engagement the client assigns names, dates, budgets and permissions.

## Exit criteria {:#exit}

- [ ] Scope and allowed Copilot surfaces signed off by authorized owner.
- [ ] Critical source claims verified by human review or observed run.
- [ ] Pilot criteria set before measurement and privacy/retention approved.
- [ ] Checkpoint records one of try another slice, revise, pause, with actual evidence.

## References {:#references}

- [Workshop agenda](WORKSHOP-AGENDA.md) · [claim ledger](CLAIM-LEDGER.md) · [decision record](DECISION-RECORD.md) · [Part 05 charter](../05-adoption-and-governance/PILOT-CHARTER.md)

# Workshop decision record · blank template

## Contents

- [Decision](#decision)
- [Evidence](#evidence)
- [Follow-up](#follow-up)
- [References](#references)

## Decision {:#decision}

| Field | Record in a real session |
|---|---|
| Date, participants and authority | — |
| Bounded question | — |
| Chosen next step: try / revise / pause | — |
| Why this next step and which alternatives were considered | — |
| Approver and security concurrence, if required | — |

## Evidence {:#evidence}

| Source-backed fact or observed result | Link to exact file/run | Limit or open question |
|---|---|---|
| — | — | — |

## Follow-up {:#follow-up}

| Check or risk | Owner | Due date or checkpoint | Stop condition |
|---|---|---|---|
| — | — | — | — |

Do not write “approved”, “passed” or a rollout recommendation until evidence and accountable approval are present. A meeting that cannot resolve a privacy boundary may still produce a useful *pause* and escalation record.

## References {:#references}

- [Workshop agenda](WORKSHOP-AGENDA.md) · [roadmap](ROADMAP.md) · [Part 05 decision form](../05-adoption-and-governance/DECISION-RECORD.md)

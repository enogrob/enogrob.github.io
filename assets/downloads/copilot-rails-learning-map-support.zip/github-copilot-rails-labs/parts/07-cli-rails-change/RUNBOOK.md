# Copilot CLI with CaseFlow · macOS runbook

## Contents

- [Prepare](#prepare)
- [Plan and inspect](#plan)
- [Verify](#verify)
- [Handoff](#handoff)
- [References](#references)

## Prepare {:#prepare}

On your Mac, install the current Copilot CLI using [GitHub's instructions](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/install-copilot-cli). GitHub currently documents `brew install --cask copilot-cli`; check the page before installing. CLI entitlement and organization policy must allow it. You need a trusted local copy of this educational companion, Ruby/Bundler for tests, and access to authenticate to GitHub. Do not paste a PAT or customer secret into a prompt or this repository.

From the **companion repository root**, use the Ruby preflight to capture source fingerprints and missing prerequisites; it does not contact GitHub or run tests:

```bash
ruby scripts/07_caseflow_cli_preflight.rb
git status --short
cd caseflow
```

Confirm `caseflow/` is the intended working directory. The baseline `config/routes.rb` has only index/show/create. Work on a disposable branch or copy, not an important uncommitted tree. Record branch and first blocker in [EVIDENCE-LEDGER.md](EVIDENCE-LEDGER.md). On first launch, the CLI asks whether you trust the directory and may ask you to authenticate using `/login`. Review the exact directory before trusting it.

## Plan and inspect {:#plan}

```bash
copilot
```

Use `Shift`+`Tab` for plan mode if offered by your installed CLI. Paste **stage 1** from [CLI-PROMPT.md](CLI-PROMPT.md) into the interactive session, replacing paths as needed. `@config/routes.rb` and `@app/models/service_request.rb` are CLI file references; check that your version resolves them. Do not confuse the shell command `copilot` with an instruction to approve all tools. Have the agent identify source facts, unknowns, proposed files and focused negative tests before allowing edits.

After reviewing the plan, paste **stage 2** only if you want a local candidate diff. GitHub documents per-tool approval for tools that can change or execute files. Read each request; avoid blanket approval for a destructive or broad command. In this lab no networked MCP server, custom hook, external directory or cloud agent is needed.

## Verify {:#verify}

Exit the CLI session if necessary. In a second terminal at `caseflow/`, review the actual diff and run after dependencies are installed:

```bash
git diff --check
git diff -- config/routes.rb app/controllers/api/requests_controller.rb app/models/service_request.rb spec/requests/api/requests_spec.rb
bundle install
RAILS_ENV=test bin/rails db:prepare
bundle exec rspec spec/requests/api/requests_spec.rb
```

These are **instructions**, not captured passing results. Compare the candidate with [Part 03's synthetic issue](../03-issue-to-pr/ISSUE.md): correct operator-token behavior and negative cases are expected for that exercise, but auth design and secrets need real client review. If a tool runs or fails, record its command, exit code and output. A missing `Gemfile.lock`, Ruby, gem or SQLite is a blocker to document, not a test result. Do not commit a resolved lockfile or apply the [Part 04 staged workflow](../04-ci-and-devsecops/rails-pr.yml) without reviewing versions and target repo policy.

## Handoff {:#handoff}

Complete [EVIDENCE-LEDGER.md](EVIDENCE-LEDGER.md) with files changed, observed runs, unknowns and human decision. Review the exact diff, especially auth and failure paths, before opening any PR. The result of a successful learning session may be a rejected candidate plus a better spec.

## References {:#references}

- [GitHub CLI overview and approvals](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/overview)
- [Part 03 issue](../03-issue-to-pr/ISSUE.md) · [CaseFlow setup](../../caseflow/README.md)

# Post 07 · Discovery brief

## Contents

- [Editorial promise](#promise)
- [Learning outcomes](#outcomes)
- [Source boundaries](#boundaries)
- [Visual script](#visual)
- [References](#references)

## Editorial promise {:#promise}

**GitHub Copilot for Rails Engineers · Part 07 — A Rails Change You Can Audit with Copilot CLI.** A Mac/VS Code Rails engineer rehearses a terminal workflow that uses Copilot CLI to inspect CaseFlow, proposes the Part 03 status-change task, and collects *real* evidence before accepting any output. This is an educational, unexecuted lab; the user runs the commands on their Mac.

## Learning outcomes {:#outcomes}

1. Enter only a trusted `caseflow/` directory and understand CLI tool-approval prompts.
2. Inspect the baseline route and propose a scoped change without claiming it exists already.
3. Distinguish tool suggestions, candidate diff, test assertions, observed runs and review decisions.
4. Produce a reviewable evidence ledger and decide whether to stop, revise or open a PR.

## Source boundaries {:#boundaries}

- GitHub documentation: installation, login, interactive CLI, file context, trusted directories, per-tool approvals, plan mode and custom instructions.
- CaseFlow baseline: `config/routes.rb` declares only `index`, `show`, `create`; the `PATCH /api/requests/:id/resolve` route belongs to a separate Part 03 candidate patch.
- CLI, Ruby gems, database and CI are not run in authoring; no fabricated output, screen capture or pass marks.
- Do not insert client secrets, tokens or private data into prompts or examples.

## Visual script {:#visual}

- Cover: series typography scaled to the approved *Inside GitHub Copilot's Agentic Engine* cover; digitized profile facing a **recognizable terminal working on Rails**, colorful Holoflux carries a source map into a candidate diff and human review. No fabricated code or success checks.
- Internal: close-up illustrated **tool permission boundary** for the CLI within a trusted project folder; reading source, edit/command request and human choice remain distinct. Not a repeat of the cover, no terminal transcript text.
- Exact process goes in a Mermaid diagram, not generative art.

## References {:#references}

- [GitHub CLI installation](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/install-copilot-cli)
- [GitHub CLI use and approvals](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/overview)
- [GitHub CLI customization comparison](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features)
- [Series map](../../docs/series-map.md)

# Part 07 · A Rails Change You Can Audit with Copilot CLI

## Contents

- [What is included](#included)
- [Run locally](#run)
- [Evidence and limits](#evidence)
- [References](#references)

## What is included {:#included}

- [Complete post](../../docs/posts/07-cli-rails-change/article.md) and [workbook with answers](../../docs/labs/07-cli-workbook.md).
- [Mac runbook](RUNBOOK.md), [two-stage CLI prompt](CLI-PROMPT.md), [blank evidence ledger](EVIDENCE-LEDGER.md) and [Ruby preflight](../../scripts/07_caseflow_cli_preflight.rb).
- [Editable Mermaid flow](../../docs/diagrams/07-cli-evidence-gates.mmd) and [visual source manifest](../../docs/posts/07-cli-rails-change/post-manifest.md).

## Run locally {:#run}

Read [RUNBOOK.md](RUNBOOK.md) before starting Copilot CLI. Open `caseflow/` as the VS Code workspace and as the CLI current directory; keep the [Part 03 candidate patch](../03-issue-to-pr/candidate.patch) available for comparison. The CLI exercise asks for a *new proposal*, not automatic application of the old patch. When a tool requests execution or write access, decide case by case.

## Evidence and limits {:#evidence}

The baseline app still exposes only create, list and show. The status transition is a *candidate* change and Part 04's workflow is *staged*. The CLI and Rails commands were not executed while producing this package. Fill the evidence ledger with your **actual** command outputs, first blocker, diff and human review decision; never treat an answer or an assertion in source as a passing run.

## References {:#references}

- [GitHub Copilot CLI install](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/install-copilot-cli) · [Using CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/overview)
- [Series map](../../docs/series-map.md)

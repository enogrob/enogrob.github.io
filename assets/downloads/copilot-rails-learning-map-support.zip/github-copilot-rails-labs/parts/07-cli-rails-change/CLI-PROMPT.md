# Two-stage prompt for Copilot CLI

## Contents

- [Stage 1 · plan only](#plan)
- [Stage 2 · candidate diff](#diff)
- [Audit questions](#audit)
- [References](#references)

## Stage 1 · plan only {:#plan}

Open Copilot CLI in `caseflow/`; activate plan mode if available. Paste this as an interactive prompt; the `@` paths are relative to that directory.

```text
Inspect @config/routes.rb @app/controllers/api/requests_controller.rb
@app/models/service_request.rb @spec/requests/api/requests_spec.rb
and @.github/copilot-instructions.md.

Our synthetic issue proposes resolving an open service request by an operator.
Do not edit files or run commands yet. First cite exact source paths for the
baseline route, validation and test assertions. State explicitly that no
status-update API exists in the baseline. Propose the smallest change set,
including a PATCH route for resolving one request, token authorization,
negative request specs, and no generic status mass assignment. List what
you cannot know without running tests or client security review. Give a
review and rollback plan before you request any tool that writes files.
```

If the CLI cannot find a path, inspect it manually and correct the prompt. A file reference does not make an untrusted folder safe.

## Stage 2 · candidate diff {:#diff}

Only after you review the plan and local branch, use a second prompt:

```text
Implement only the approved synthetic CaseFlow status-resolution task in
this local branch. Keep the existing create/index/show behavior. Require
an operator token; deny missing, wrong and unconfigured credentials.
Add focused positive and negative request specs. Before every requested
tool operation, describe the files or commands it affects. Do not run
networked commands, change GitHub settings, push a branch, open a PR or
declare success. At the end show the diff, list the exact tests you asked
to run, and separate observed output from tests still pending.
```

The token design is a **synthetic lab assumption** from Part 03; it is not a production authorization recommendation. Review the candidate patch and test output as a human.

## Audit questions {:#audit}

1. Does the agent cite source files rather than describe imagined behavior?
2. Did it distinguish proposed changes from existing routes?
3. What precise file or shell command does each permission request touch?
4. Which negative path was tested, and where is the observed output?
5. Is the changed auth approach suitable for the real client's policy, or only for this teaching issue?

## References {:#references}

- [CaseFlow source](../../caseflow/README.md) · [Part 03 issue](../03-issue-to-pr/ISSUE.md)
- [GitHub CLI file references and approvals](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/overview)

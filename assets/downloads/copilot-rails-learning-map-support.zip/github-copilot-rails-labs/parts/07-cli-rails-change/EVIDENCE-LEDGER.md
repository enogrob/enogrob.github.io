# CLI lab evidence ledger · intentionally blank

## Contents

- [Environment](#environment)
- [Claims and observations](#claims)
- [Review decision](#review)
- [References](#references)

## Environment {:#environment}

| Field | Record after a real local session |
|---|---|
| Date, macOS, Ruby/Bundler and Copilot CLI version | — |
| Local branch and starting `git status --short` | — |
| Trusted directory and CLI policy/entitlement check | — |
| Any installed gems, lockfile and database preparation | — |

## Claims and observations {:#claims}

| Claim | File or exact command | Classification: source / proposal / observed / blocker | Output or first failure | Reviewer |
|---|---|---|---|---|
| Baseline routes | — | — | — | — |
| Candidate diff | — | — | — | — |
| Valid transition spec | — | — | — | — |
| Missing/wrong/unconfigured token specs | — | — | — | — |
| `git diff --check` | — | — | — | — |
| Focused RSpec run | — | — | — | — |

## Review decision {:#review}

| Field | Value |
|---|---|
| Human reviewer and requested changes | — |
| PR-ready / revise / stop, with justification | — |
| Open security and auth questions | — |
| Next owner and checkpoint | — |

Never fill a pass based on source assertions or an AI summary. If no run occurs, say **not run** and record the blocker.

## References {:#references}

- [Mac runbook](RUNBOOK.md) · [two-stage prompt](CLI-PROMPT.md) · [post](../../docs/posts/07-cli-rails-change/article.md)

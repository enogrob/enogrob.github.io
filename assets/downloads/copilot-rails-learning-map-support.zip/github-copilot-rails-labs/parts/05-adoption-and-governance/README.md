# Part 05 · A responsible Copilot adoption pilot

This part contains the complete [article](../../docs/posts/05-adoption-and-governance/article.md), [blank charter](PILOT-CHARTER.md), [blank decision record](DECISION-RECORD.md), [header-only aggregate CSV](pilot-observations.csv), [Ruby summarizer](../../scripts/summarize_pilot.rb), [editable diagram](../../docs/diagrams/05-pilot-decision.mmd) and [study workbook and answers](../../docs/labs/05-pilot-workbook.md). Parts 01–04 and the full CaseFlow app remain in this repository.

## Contents

- [Practice path](#practice)
- [Aggregate reporting](#reporting)
- [Limits](#limits)
- [References](#references)

## Practice path {:#practice}

Read the article and attempt the workbook before its answers. Fill the charter with actual decision makers, consent and scope if you adapt this lab to a real organization; the exercise does not configure Copilot on a real repository.

## Aggregate reporting {:#reporting}

The provided CSV is **empty**. After approval to collect and report aggregate metrics, use one row per period/cohort with nonnegative integer counts and no personal identifiers. Do not publish tiny cohorts. The script requires explicit operator attestation:

```bash
PILOT_AGGREGATE_REPORT_APPROVED=yes ruby scripts/summarize_pilot.rb parts/05-adoption-and-governance/pilot-observations.csv
```

Run from the **companion repository root**. With the shipped empty template the command exits without reporting numbers. A populated file can produce reach (active ÷ eligible); it cannot establish causality or grant data-use permission.

## Limits {:#limits}

No organization policy has been configured, no real pilot has occurred, and the authoring environment did not execute Ruby. The support diagram and illustrations are conceptual; all fields for data and decisions are intentionally blank.

## References {:#references}

- [GitHub trial measurement guide](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success)
- [GitHub Copilot usage metrics](https://docs.github.com/en/copilot/reference/copilot-usage-metrics)
- [GitHub content exclusion](https://docs.github.com/en/copilot/concepts/security-governance-and-network-settings/content-exclusion)

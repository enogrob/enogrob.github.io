# Part 05 · Pilot charter (blank, for client review)

## Contents

- [Question and boundaries](#question)
- [Evidence plan](#evidence)
- [Safety and consent](#safety)
- [Decision rules](#decision)
- [References](#references)

## Question and boundaries {:#question}

**Hypothesis:** For a consenting Rails cohort, can Copilot assist repository orientation and bounded PR drafting while maintaining acceptable review quality and privacy? This is a template; fill the owner's actual success criteria before starting.

| Field | Decision to fill before launch |
|---|---|
| Sponsor / engineering owner / security reviewer | — |
| Approved repository, task types, allowed Copilot surfaces | — |
| Participants and opt-in/communication | — |
| Baseline window / pilot window (suggestion: 2–4 weeks) | — |
| Comparison limitations and concurrent changes | — |
| Exit route and contact for incidents | — |

## Evidence plan {:#evidence}

| Signal | Precise source, time window, denominator, owner and retention |
|---|---|
| Eligible and active users, aggregated | — |
| Voluntary qualitative feedback | — |
| Comparable PR turnaround / review rework | — |
| Tests, escaped defects and security findings | — |
| Policy incidents or blocked work | — |

Use the [header-only aggregate template](pilot-observations.csv) and [Ruby validator](../../scripts/summarize_pilot.rb) only after this evidence plan is approved. Never paste raw Copilot API user metrics into the template. GitHub usage metrics show activity, not a controlled productivity experiment.

## Safety and consent {:#safety}

- Define permissible prompt input, repositories, file paths, retention and access. Ban secrets, customer records and tokens from examples.
- Verify actual admin policy settings and content exclusion *per feature and client*. Exclusion has documented limitations in editor Edit/Agent modes; do not treat a configured path as a comprehensive data firewall.
- Keep agent proposals on reviewed branches with tests and PR review. Record who approves expansion and who can stop the trial.
- Choose reporting granularity that protects participants; suppress small-cohort public reports where re-identification is plausible.

## Decision rules {:#decision}

Document numerical or qualitative **criteria before data collection** with the sponsor. Precommit to pause for a serious boundary breach even if usage is high. If there is no baseline, insufficient sample or inconsistent definitions, mark evidence insufficient. Record results and sign-off in [DECISION-RECORD.md](DECISION-RECORD.md); do not insert fictional outcomes.

## References {:#references}

- [Complete post](../../docs/posts/05-adoption-and-governance/article.md)
- [GitHub measurement path](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-copilot-impact)
- [GitHub content exclusion limitations](https://docs.github.com/en/copilot/concepts/security-governance-and-network-settings/content-exclusion)

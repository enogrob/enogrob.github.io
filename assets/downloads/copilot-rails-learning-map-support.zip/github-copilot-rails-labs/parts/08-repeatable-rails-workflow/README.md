# Part 08 · A Repeatable Rails Copilot Workflow

## Contents

- [What to study](#study)
- [Run the structural check](#check)
- [Limits](#limits)
- [References](#references)

## What to study {:#study}

Read the [complete Part 08 article](../../docs/posts/08-repeatable-rails-workflow/article.md), then the [workflow blueprint](WORKFLOW-BLUEPRINT.md). The [workbook](../../docs/labs/08-workflow-workbook.md) includes theory, seven varied exercises and answers. The [editable Mermaid](../../docs/diagrams/08-workflow-boundaries.mmd) and [illustrated image manifest](../../docs/posts/08-repeatable-rails-workflow/post-manifest.md) travel with the article. For a real CLI session, first use the [Part 07 runbook](../07-cli-rails-change/RUNBOOK.md).

## Run the structural check {:#check}

The [Ruby validator](../../scripts/08_validate_evidence.rb) reads only a JSON record and referenced local files; it does not run Copilot, Rails, tests or a hook. From this repository root:

```bash
ruby scripts/08_validate_evidence.rb parts/08-repeatable-rails-workflow/EVIDENCE.json
```

The shipped [record](EVIDENCE.json) is blank where real evidence is required, so a nonzero result is expected. Supply only authentic local log/diff paths, command, exit code, reviewer and decision after running the Part 07 lab on your Mac.

## Limits {:#limits}

No skill, hook, MCP server, desktop session or SDK integration is installed by this final chapter. The blueprint shows when each mechanism is appropriate. A structurally complete evidence record still needs a human to verify provenance, relevance, privacy and approval.

## References {:#references}

- [Skills](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills) · [hooks](https://docs.github.com/en/copilot/reference/hooks-reference) · [comparison](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features)
- [Series map](../../docs/series-map.md)

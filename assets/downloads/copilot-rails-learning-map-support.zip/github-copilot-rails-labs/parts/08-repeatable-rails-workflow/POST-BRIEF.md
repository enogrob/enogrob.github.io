# Part 08 · Discovery brief

## Contents

- [Promise](#promise)
- [Scope and teaching artifact](#scope)
- [Visual script](#visual)
- [References](#references)

## Promise {:#promise}

**A Repeatable Rails Copilot Workflow: Skills, Hooks, MCP, and Evidence.** The final post uses CaseFlow to decide which Copilot customization belongs where and turns the previous seven lessons into a reviewable, human-owned workflow. It teaches one small executable Ruby evidence validator, without activating a new hook, external MCP connection, agent or production deployment.

## Scope and teaching artifact {:#scope}

- Existing `.github/copilot-instructions.md` contains always-on conventions; a proposed skill recipe describes an on-demand procedure, but this package does **not** install a `SKILL.md` or alter permissions.
- Tools are operations requested by the CLI; an optional hook would run Ruby at a defined lifecycle boundary only after its payload and blast radius are reviewed. MCP is for a genuine external system requirement, not for basic repository reading.
- The included Ruby checker validates the *completeness* of a local evidence JSON record and the presence of referenced local files. It cannot prove that a test actually ran or passed. The provided blank record should fail validation.
- Copilot SDK language support and desktop app availability must be checked in their current official documentation; neither is required for this Rails/CLI lab. HydraFusion is a visual concept in the blog reference, not an assumed product dependency.

## Visual script {:#visual}

- Cover: reference-sized three-tier typography; a digitized side-profile Copilot guide faces a realistic Rails workbench at the **center**, with instructions/skill/tool/hook/MCP as visually distinct influences and a real human review checkpoint. Avoid a wheel, repeating tiles and fabricated green results.
- Internal: **cross-section of one tool request** that shows persistent instruction, loaded task recipe, internal tool, optional external bridge, unarmed guard, Ruby evidence sheet and human decision. Short labels only and no false guarantee.
- The actual order and decision alternatives are expressed precisely in Mermaid and a text table.

## References {:#references}

- [GitHub CLI customization comparison](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features) · [skills](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills) · [hooks](https://docs.github.com/en/copilot/reference/hooks-reference)
- [Series map](../../docs/series-map.md)

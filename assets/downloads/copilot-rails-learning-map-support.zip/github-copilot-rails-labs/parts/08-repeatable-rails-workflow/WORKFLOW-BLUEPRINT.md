# CaseFlow · repeatable workflow blueprint

## Contents

- [Trigger and owner](#trigger)
- [Choose the right mechanism](#mechanisms)
- [Human gates](#gates)
- [Evidence data](#evidence)
- [Next step](#next)
- [References](#references)

## Trigger and owner {:#trigger}

**Trigger:** a Rails engineer proposes a bounded status-resolution change in CaseFlow and wants a reviewable candidate without claiming unobserved success. **Human owner:** engineer who operates the CLI; security/reviewer assigns actual authorization. This is a *blueprint*, not an installed agent skill or active hook.

## Choose the right mechanism {:#mechanisms}

| Need in this lab | Minimal mechanism | Why |
|---|---|---|
| Always follow CaseFlow conventions | Existing `caseflow/.github/copilot-instructions.md` | Persistent repository guidance |
| Repeat the evidence procedure across tasks | Proposed task-scoped skill recipe; author/review/install later | On-demand reusable instructions, no blanket shell approval |
| Read/edit a local file and request tests | CLI built-in tools with explicit user approval | Tools do the operation; text alone cannot run it |
| Integrate an external ticket or knowledge source | MCP only after client authorization and scope review | Extends access beyond local repo; not required here |
| Enforce a deterministic check at a lifecycle boundary | Optional hook design after payload tests | A hook runs code; incorrect configuration can affect every relevant request |
| Validate that evidence fields and local references exist | `ruby scripts/08_validate_evidence.rb ...` | Standard-library Ruby structural check; not proof of authentic output |
| Decide whether to open a PR or share across team | Human reviewer | Tests and tooling cannot grant organizational approval |

GitHub's [comparison guide](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features) is the source for these mechanism roles. Copilot SDK is an application integration route, not a required CLI customization; [current SDK language guides](https://docs.github.com/en/copilot/how-tos/copilot-sdk) do not list Ruby among their examples. `gh` is GitHub's CLI for repository operations, separate from the `copilot` executable. The Copilot desktop app is another surface; this lab deliberately stays on a single local Rails workspace. HydraFusion informs the blog's visual language, and is not an extra dependency of CaseFlow.

## Human gates {:#gates}

1. Verify the baseline route (`index`, `show`, `create`) and the proposed patch are separate.
2. Review each CLI tool request and its directory; deny unexpected network access or modifications.
3. If a team later authors a skill, omit `allowed-tools: shell` until its scripts and sources are reviewed; skill guidance is not itself a runtime policy.
4. If a team later prototypes a hook, test against the installed CLI's actual `preToolUse` payload and decision schema before adding `.github/hooks/*.json`. No hook is active in this companion.
5. Collect observed test output and human authorization, then decide share, revise or stop.

## Evidence data {:#evidence}

The supplied [EVIDENCE.json](EVIDENCE.json) is intentionally incomplete. After a genuine local run, provide repository-relative paths to an actual candidate diff and saved test output, the exact command, exit code and named reviewer/decision. From the companion root:

```bash
ruby scripts/08_validate_evidence.rb parts/08-repeatable-rails-workflow/EVIDENCE.json
```

**Expected for the shipped blank template:** nonzero exit and a list of missing fields. A zero exit only means the fields are present and the local paths exist, not that the result was genuine, safe, approved or passing. Do not put secrets or private customer data in the JSON/logs.

## Next step {:#next}

After several real sessions produce stable, reviewed evidence, decide whether the procedure deserves an installable project skill. If a hard guardrail is necessary, design and test a hook separately; if an external system is essential, review one MCP connection. Promotion is a client/team governance decision. Keep recorded counterexamples and stopped changes as learning material.

## References {:#references}

- [Post 08](../../docs/posts/08-repeatable-rails-workflow/article.md) · [workbook](../../docs/labs/08-workflow-workbook.md)
- [Official skills guide](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills) · [hooks reference](https://docs.github.com/en/copilot/reference/hooks-reference) · [MCP and tool comparison](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features)

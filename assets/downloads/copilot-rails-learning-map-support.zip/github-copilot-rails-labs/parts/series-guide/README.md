# Start here · GitHub Copilot for Rails Engineers

This guide indexes eight chapters without becoming Part 09.

## Contents

- [The complete series guide](../../docs/posts/series-guide/article.md)
- [Optional conceptual prologue: Inside GitHub Copilot’s Agentic Engine](https://enogrob.github.io/artificial-intelligence/software-engineering/agentic-ai/github-copilot/2026/09/23/inside-github-copilot-agentic-engine.html)
- [Eight chapters and companion outputs](../../docs/series-map.md)
- [Synthesis workbook and answer key](../../docs/labs/series-guide-workbook.md)
- [Editable learning map](../../docs/diagrams/series-learning-map.mmd)
- [CaseFlow app and setup](../../caseflow/README.md)
- [Illustrated asset masters](../../docs/posts/series-guide/post-manifest.md)

## Suggested paths

**Interview:** optionally read the Copilot architecture prologue, then inspect the source in 01, context in 02, candidate review in 03, gates in 04, client recommendation in 06 and reusable boundaries in 08. Rehearse the workbook without inventing test or pilot results. The prologue is outside the eight-chapter count.

**Hands-on:** follow 01–08 in order, opening each part’s `README.md`, workbook and diagram. Run the Rails checks only on your configured Mac, recording the actual output. The companion includes a synthetic baseline app, candidate diff and blank templates.

## References

- [All chapters on the blog](../../docs/posts/series-guide/article.md#chapters).
- [GitHub Copilot documentation](https://docs.github.com/en/copilot).
- [Rails guides](https://guides.rubyonrails.org/).

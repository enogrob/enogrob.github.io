# Series guide · synthesis workbook

Use the [complete guide](../posts/series-guide/article.md), [eight-part map](../series-map.md), and [CaseFlow app](../../caseflow/README.md). Answer before scrolling to the key. This index is not a ninth lab chapter.

## Learning goals

1. Choose the relevant chapter for a concrete engineering or client question.
2. Distinguish source declarations, proposed changes, observed runs and authorized decisions.
3. Build a short, defensible prescreening answer connecting Rails, Copilot, DevSecOps and consultation.

## Exercises

### 1 · Match the question to a chapter

Select one or two parts for each: (a) Which file declares the POST route? (b) How do we restrict guidance for the model? (c) Did a proposed status patch pass CI? (d) How do we tell tool usage from engineering improvement? (e) Should the organization activate an MCP server for this task?

### 2 · Repair a confident answer

A consultant says: “Part 03 delivered a production endpoint, Part 04 verified it, and Part 05 proved we work faster.” Rewrite the sentence using only supplied evidence and name three missing observations.

### 3 · Make two study routes

You have 90 minutes before a prescreening call: which chapters do you prioritize, what source-backed story can you tell, and which behavior do you avoid claiming? Then plan a full local session on a Mac: name the app README, one focused Rails check, the place for actual results, and who decides whether to proceed.

### 4 · Explain the client decision

A security reviewer has not approved a Copilot surface, the pilot CSV is header-only, and the Part 03 patch is a candidate. Deliver a two-minute recommendation: one bounded next step, its owner, needed evidence and a stop condition. Your answer may recommend a pause.

### 5 · Reflect on the diagram

In the [editable learning map](../diagrams/series-learning-map.mmd), why do 04 and 06 both feed the later workflow discussion? Explain which arrows represent a learning dependency rather than a running automated pipeline.

---

## Answer key · compare after attempting

**1.** (a) 01 and `caseflow/config/routes.rb`; (b) 02; (c) 03 + 04, but there is no supplied passing CI result; (d) 05; (e) 08, where MCP is optional and external access needs a real authorized need.

**2.** A bounded status-update candidate patch and proposed specs are supplied by Part 03. Part 04 contains a staged workflow, not a recorded pass. Part 05 supplies a charter and empty measurement template, not observed productivity. Missing: actual applied diff and focused test log; a CI run tied to the branch; an authorized pilot with baseline, cohort and quality measures.

**3.** Interview: skim 01, 02, 03, 04, 06, 08 and explain the source-to-client decision with a stated unknown. Do not say that the proposed endpoint exists in the baseline. Local practice: follow `caseflow/README.md`, run an actual focused RSpec command after installing dependencies, store command, exit status and output in a local evidence note or Part 07 ledger, and ask the responsible engineer to review diff and checks. The companion cannot vouch for a run it did not observe.

**4.** Example: “I would ask the security owner to define an allowed repository and Copilot surface, have a Rails maintainer reproduce the source map and review the candidate patch, then propose a small consenting trial after a baseline is approved. The sponsor owns the pilot decision. We pause before activation if policy, test evidence or an accountable reviewer is absent.” Other solutions are valid if they identify the same gaps and responsibilities.

**5.** Part 04 establishes what check results a workflow would need; Part 06 establishes who makes and records a consequential decision. Their arrows into 08 connect lessons, not execution events. The Part 05 → 06 line also signals a planning dependency, not a completed pilot.

## References

- [All eight published chapter links and outcomes](../posts/series-guide/article.md#chapters).
- [CaseFlow startup and test guide](../../caseflow/README.md).
- [Visual and Mermaid standard](../visual-standard.md).

# Part 07 · Copilot CLI and reviewable Rails evidence

## Contents

- [Theory](#theory)
- [Exercises](#exercises)
- [Answer key](#answers)
- [References](#references)

## Theory {:#theory}

Copilot CLI can navigate a trusted local repository and ask to use tools, but these stages remain distinct: **source statement → proposed plan → requested operation → actual command result → human decision**. A plan can be useful without any file edit. An RSpec assertion is evidence about an intended contract, while a test log reports an observed run in one environment. Repository instructions guide the assistant; user authorization, command scope and client policy still need human attention.

The [visualized flow](../diagrams/07-cli-evidence-gates.mmd) is a proposed workflow. Attempt the exercises before the key; any real commands/results belong in the [blank ledger](../../parts/07-cli-rails-change/EVIDENCE-LEDGER.md).

## Exercises {:#exercises}

1. **Prediction:** You start CLI in the companion root instead of `caseflow/`. Which `@` path from [CLI-PROMPT.md](../../parts/07-cli-rails-change/CLI-PROMPT.md) will be wrong? What scope will the trust prompt cover? Correct the working directory before continuing.
2. **Source or conjecture:** An agent says “the model's `resolved` enum means `PATCH /api/requests/:id/resolve` already works.” Cite the file that refutes the endpoint claim. Explain what the model alone supports.
3. **Permission boundary:** Copilot wants to run `bundle exec rspec spec/requests/api/requests_spec.rb`. What directory, operation, environment and side effects would you check? How does “allow once” differ from “approve this tool for the session” in GitHub's documented dialog?
4. **Critique the diff:** The proposed patch adds an update route that permits `status` from request params and a spec for only the happy path. State at least three review findings against the [Part 03 issue](../../parts/03-issue-to-pr/ISSUE.md).
5. **Sort the evidence:** Label each: (a) route declaration in baseline, (b) generated spec with expected `401`, (c) terminal output showing a focused spec exit code, (d) `bundle: command not found`, (e) security review approval. Which can justify “the tests passed”?
6. **Choose next action:** A CLI summary reports “all tests pass” but the developer saved no output and `Gemfile.lock` is absent. Write a two-sentence handoff to a reviewer, listing a next check and what remains unknown.
7. **Transfer:** When would you add a skill, custom instruction or hook to this workflow? Give one example for each, and identify which is unnecessary for this one-off learning lab.

## Answer key {:#answers}

1. `@config/routes.rb` resolves relative to the wrong working directory if started at the companion root; there the app file is `caseflow/config/routes.rb`. The trust prompt concerns the folder where CLI was launched and its descendants, a broader scope than the lab intends. Start a new session in `caseflow/`, check the actual prompt, and reference paths from there.
2. `caseflow/config/routes.rb` declares `resources :requests, only: %i[index show create]`; no update or resolve route is in baseline. `caseflow/app/models/service_request.rb` describes allowed stored states, not an HTTP endpoint. The Part 03 patch proposes a separate change that must be inspected and run.
3. Check that the tool will run in the expected `caseflow/` directory, that the command only runs focused specs, that dependencies and test database are prepared, and that it will not hit a real service. GitHub describes per-operation approval and an option to approve a tool for the rest of the session; the latter may allow later uses of that tool without asking each time. Log the actual command and output; these questions do not claim a run happened.
4. A generic update route expands scope, permitting `status` risks mass assignment, and missing negative specs leave missing/wrong/unconfigured token behavior untested. Also require no change to create/list/show and consider concurrency/identity policy. Compare a real candidate against the synthetic issue, not against an invented production policy.
5. (a) source declaration; (b) test assertion/proposal; (c) observed run only if the command, exit and output are authentic and attributable to the environment; (d) blocker; (e) human decision. A real successful output for the relevant command can support a bounded pass claim; approval cannot replace it.
6. Example: “The agent proposed a diff and reported a passing spec, but I have no captured command output; I cannot mark tests passed. Please review the diff while I resolve dependencies, run the focused RSpec command and attach its exit status and output.” The missing lockfile alone does not prove failure or success; it signals unresolved versions.
7. Custom instruction: persistent Rails conventions in `.github/copilot-instructions.md`; skill: a reusable, task-specific PR evidence procedure loaded when relevant; hook: an enforced shell guard that checks a tool request at a lifecycle boundary, only if the team actually needs executable control. None needs to be added to this one-off lab; tool approvals and a reviewed prompt suffice. GitHub's [comparison guide](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features) explains these distinctions.

## References {:#references}

- [Post 07](../posts/07-cli-rails-change/article.md) · [Mac runbook](../../parts/07-cli-rails-change/RUNBOOK.md) · [prompt](../../parts/07-cli-rails-change/CLI-PROMPT.md)
- [GitHub Copilot CLI usage and approvals](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/overview)

# Part 08 · Design a repeatable Rails Copilot workflow

## Contents

- [Theory](#theory)
- [Exercises](#exercises)
- [Answer key](#answers)
- [References](#references)

## Theory {:#theory}

Persistent instructions answer **how we normally work here**. A skill describes **how to perform a recurring task** when relevant. A tool reads, writes or runs something; MCP makes new external tools available. A hook runs a configured command at a lifecycle event and needs runtime review. A human decides whether the outcome is acceptable. These mechanisms have different permissions and failure modes; adding all of them to a one-off Rails task increases complexity without adding evidence.

The bundled Ruby script checks JSON structure and local file existence. It is a **structural gate**, not an attestation. Even a complete JSON document can contain a stale test log, a mislabeled exit code or an unauthorized change. Work through the exercises before comparing with the key.

## Exercises {:#exercises}

1. **Match the mechanism:** For (a) always use RSpec for a Rails route change, (b) teach a reusable evidence procedure when requested, (c) look up an authorized external ticket, (d) inspect a command before it runs, (e) actually read `config/routes.rb`, choose from instruction, skill, MCP, hook, built-in tool. Explain when a simple CLI prompt remains sufficient.
2. **Predict failure:** The shipped `parts/08-repeatable-rails-workflow/EVIDENCE.json` has valid source paths but empty diff, test log, reviewer, command and decision. Predict the Ruby validator's exit status and at least three findings. Why would “the agent said green” not fix it?
3. **Audit an apparent pass:** A teammate fills `test_exit_code: 0` and points `test_log` at any existing text file. The script exits zero. What *five* checks must a human still perform before declaring the change ready?
4. **Pick a boundary:** A team proposes adding an MCP server to read customer tickets for this synthetic CaseFlow task. Explain why it adds no value here; describe a real condition that would justify the access and a least-privilege question to ask.
5. **Challenge a skill:** A proposed skill says `allowed-tools: shell` and runs `bundle install` automatically on every trigger. Identify two risks and revise its design for the macOS teaching lab.
6. **Design a hook without activating it:** Define one narrow `preToolUse` decision you might want for a reviewed corporate workflow. List input schema, matching, allowed/denied cases and failure behavior that need tests before installing `.github/hooks/*.json`.
7. **Interview transfer:** In two minutes, explain how Parts 01–08 lead from unfamiliar Rails code to a reusable team procedure without claiming any benchmark or customer rollout. Name one stop condition and one artifact a client can inspect.

## Answer key {:#answers}

1. (a) instruction for persistent convention; (b) skill for repeatable on-demand process; (c) authorized MCP connection; (d) optional hook only if deterministic enforcement is warranted, while CLI's interactive permission prompt already provides a human gate; (e) built-in read tool. For a one-off exercise, prompt plus direct review and permission prompts are enough. Read [GitHub's comparison](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features).
2. Expected exit **1** with missing `candidate_diff`, `test_command`, `test_exit_code`, `test_log`, `reviewer` and `decision`. A chat claim does not create authentic local output or authorization. The source paths may be valid, but they do not prove the proposed patch or test.
3. Inspect whether the diff is the intended change, confirm the command and log belong to the same run/branch, check relevant negative specs and actual output rather than exit code alone, review security/privacy and token behavior, and obtain an accountable human review decision. The validator cannot authenticate provenance or enforce policy.
4. Synthetic CaseFlow has no external ticket system; adding one expands access and review without improving this exercise. A legitimate client task requiring a ticket system could justify an MCP server after identifying the authorized organization, exact resources, read/write scope, owner, retention and revocation path. Start with read-only access if sufficient.
5. `allowed-tools: shell` can bypass per-tool confirmation; an installer on every task may change dependencies, touch network or fail unpredictably. Define a task-specific procedure that requests permission for shell commands, separates plan from execution, and runs bundle/test only when the user and environment are ready. No installed skill is required here.
6. Example: inspect a proposed tool request before a command affects a protected path. Test payload fields from the [current hooks reference](https://docs.github.com/en/copilot/reference/hooks-reference), exact tool names and path normalization, allowed and denied examples, JSON output and error policy, and whether the hook runs on CLI or cloud agent. Do not claim a sketch is an active security control.
7. Example: “We mapped the source and unknowns, bounded Copilot's context, reviewed a candidate PR and CI plan, defined a pilot, rehearsed a client workshop, and used the CLI to propose a local Rails change. I would standardize the stable procedure as a skill only after repeated real sessions; a Ruby ledger check catches missing fields and a human reviews actual outputs. A missing baseline or credential breach pauses the work; the client can inspect the diff and evidence record.” No performance number is asserted.

## References {:#references}

- [Article](../posts/08-repeatable-rails-workflow/article.md) · [workflow blueprint](../../parts/08-repeatable-rails-workflow/WORKFLOW-BLUEPRINT.md) · [blank JSON](../../parts/08-repeatable-rails-workflow/EVIDENCE.json)
- [Official GitHub Copilot CLI customization comparison](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features)

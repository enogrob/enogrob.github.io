# Part 06 · Facilitate the client decision

## Contents

- [Theory in five minutes](#theory)
- [Exercises](#exercises)
- [Answer key](#answers)
- [References](#references)

## Theory in five minutes {:#theory}

A useful workshop distinguishes **source-backed facts**, **proposed changes**, **observed results** and **unknowns**. The CaseFlow route/model map is supported by source. The Part 03 patch and Part 04 workflow are proposals; their presence does not prove a passing run. The Part 05 pilot sheet is empty. A good decision names a next check and an owner, not a productivity result that was never measured.

The diagram shows the proposed decision logic. Its editable source is [06-workshop-decision.mmd](../diagrams/06-workshop-decision.mmd).

```mermaid
%%{init: {'theme':'base','themeVariables':{'background':'#FFFFFF','primaryTextColor':'#3E342C','lineColor':'#6F7377'}}}%%
flowchart TB
    subgraph evidence["📚 Inputs"]
      A["🧭 Source map"] --> C["🗂️ Claim ledger"]
      B["🧪 Candidate patch"] --> C
    end
    subgraph decision["👥 Human checkpoint"]
      C --> V["🔍 Verify / unknown"] --> O["👤 Owner + stop rule"]
    end
    O --> T["🧪 Try a slice"]
    O --> R["🔁 Revise scope"]
    O --> S["⛔ Pause"]
    classDef src fill:#D9EAF7,stroke:#7AA6C2,color:#3E342C;
    classDef review fill:#FFF1BF,stroke:#BA9C43,color:#3E342C;
    classDef owner fill:#E8DDF5,stroke:#A68BC4,color:#3E342C;
    classDef opt fill:#DCEFD6,stroke:#86A878,color:#3E342C;
    class A,B src;
    class C,V review;
    class O owner;
    class T,R,S opt;
```

## Exercises {:#exercises}

Attempt these before opening the key.

1. **Prediction:** A sponsor says “the sample PR is already safe because the workflow file exists.” Classify each claim, cite the relevant companion file, and give the next check.
2. **Spot the gap:** In the [claim ledger](../../parts/06-client-workshop/CLAIM-LEDGER.md), what does the Part 03 patch actually prove? Write one sentence you would say aloud to the client.
3. **Fix the agenda:** Your security reviewer can attend only the first 40 minutes. Reorder the [agenda](../../parts/06-client-workshop/WORKSHOP-AGENDA.md) so prompt-data and policy boundaries get reviewed before a pilot is recommended. Identify what must wait if authority is absent.
4. **Choose a branch:** A willing cohort is proposed, but nobody can name permissible prompt data, the baseline or the stop authority. Try, revise or pause? Name the smallest conditions that would change your answer.
5. **Make it testable:** Turn “Copilot will accelerate the team” into a question for two bounded Rails tasks. Supply one usage signal, one quality signal, one safety signal, sources, owners and a comparison limit. Leave values empty.
6. **Transfer in two minutes:** Explain to an engineering lead and a security lead how you would leave a 90-minute workshop with something useful even if tests cannot run. Use [ROADMAP.md](../../parts/06-client-workshop/ROADMAP.md) and [DECISION-RECORD.md](../../parts/06-client-workshop/DECISION-RECORD.md). Record your own response before reading the example.

## Answer key {:#answers}

1. `parts/04-ci-and-devsecops/rails-pr.yml` is a **staged plan**, not a run result; `parts/03-issue-to-pr/candidate.patch` is a **proposed change**, not an approved PR. Inspect the diff with a human reviewer, install dependencies in the target environment, run the relevant RSpec and CI checks, save their real output and obtain the security decision. Missing Ruby or a lockfile is a documented blocker, not a pass.
2. It proves that an inspectable candidate patch exists. It does not prove it applies cleanly, passes tests, passed review or was merged. Say: “We can review this concrete diff today and specify the checks needed; we cannot report it as deployed.”
3. Move prompt-data, approved surface and repository access review into minutes 10–25; then source map and candidate change into 25–40 with the reviewer present. Defer any pilot scope/activation requiring security approval if the reviewer cannot decide. The facilitator may rearrange the example timeboxes; record unfinished decisions and owner.
4. **Pause an actual pilot launch** while still using the session to revise the design. Name an authorized security owner, acceptable data types and enabled surfaces, agree baseline and incident authority, then reconsider a bounded try. Do not quietly infer approval from cohort interest.
5. Example: “For consenting Rails developers using Copilot for source orientation and a small status-change proposal, do comparable PR review rework and recorded safety exceptions stay within criteria agreed *before* the pilot?” Reach = active/eligible cohort from permitted aggregate Copilot usage data; quality = review rework and test failures from PR/CI records; safety = policy incident log from security. Owners: pilot owner, engineering lead, security. Two tasks and 2–4 weeks cannot establish causality; compare like work and document concurrent changes. No numbers are supplied.
6. Sample answer: “We leave with a claim ledger separating what the CaseFlow source says, what the candidate patch proposes and which runs are still unknown. We agree one small next check, an owner, data boundaries and the stop rule; the decision record marks approval as pending until the responsible people decide. That gives the team a usable roadmap even if local dependencies block the test today.” Adapt to observed evidence, and avoid implying a client approved anything.

## References {:#references}

- [Post 06](../posts/06-client-workshop/article.md) · [workshop agenda](../../parts/06-client-workshop/WORKSHOP-AGENDA.md) · [roadmap](../../parts/06-client-workshop/ROADMAP.md)
- [GitHub trial measurement](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success) · [GitHub governance overview](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale)

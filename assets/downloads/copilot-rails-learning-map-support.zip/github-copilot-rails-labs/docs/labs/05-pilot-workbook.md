# Study workbook 05 · A responsible Copilot pilot for Rails

*Predict → bound → measure → challenge → decide.* Allow 50–70 minutes. Work from the [complete post](../posts/05-adoption-and-governance/article.md), then check the [answer key](#answers). The exercise cases below are **hypothetical**, not actual client data.

## Contents

- [Learning outcomes](#outcomes)
- [Mental model](#model)
- [Exercises](#exercises)
- [Answer key](#answers)
- [Transfer and references](#transfer)

## Learning outcomes {:#outcomes}

Design a bounded pilot, distinguish engagement from engineering outcomes, name coverage gaps in content exclusion, choose minimal aggregated evidence, and make a defensible expand/revise/pause decision without inventing experience or gains.

## Mental model {:#model}

A Copilot trial needs *permission and scope*, *baseline*, *usage and experience*, *quality and safety evidence*, and an *accountable decision*. The [pilot decision diagram](../diagrams/05-pilot-decision.mmd) separates a safety pause, insufficient evidence and a justified next cohort.

## Exercises {:#exercises}

### 1 · Predict an easy but misleading answer (6 min)

A leader asks, “If half the team uses Copilot, did we gain 50% productivity?” Write a two-sentence answer specifying denominator, task mix and the distinction between activity and impact.

### 2 · Restrict the scope (8 min)

Draft a four-line mini charter: volunteer cohort, one CaseFlow task, approved client surface, and one sensitive input that stays out of prompts. Who can halt the pilot?

### 3 · Audit a policy assumption (8 min)

A team excludes `secrets/` from Copilot and assumes that solves exposure in VS Code Agent mode. Identify the faulty assumption, one verification step and one defense that does not depend on content exclusion.

### 4 · Distinguish evidence sources (10 min)

Match each to its source: eligible developers, active tool users, PR rework, escaped defects, developer friction, data incidents. Which come from GitHub usage telemetry, which from internal engineering systems, and which require separate interview or reporting?

### 5 · Work a **hypothetical** decision (10 min)

Assume a scenario with anonymized, invented numbers solely for arithmetic: 8 eligible volunteers, 6 active, 5 comparable PRs, 1 rework event, 0 recorded incidents, and **no** baseline PR sample. Calculate reach; then choose expand, revise or pause. Could you state Copilot improved quality or speed?

### 6 · Inspect Ruby and CSV (8 min)

Open [`pilot-observations.csv`](../../parts/05-adoption-and-governance/pilot-observations.csv) and [`summarize_pilot.rb`](../../scripts/summarize_pilot.rb). Why should running it on the shipped CSV stop? Why is `PILOT_AGGREGATE_REPORT_APPROVED=yes` required to print filled aggregate rows? Explain what it **does not** verify.

### 7 · Interview transfer (5 min)

Give a two-minute proposal to a client engineering lead: outcomes, privacy boundary, what you measure and your stop criterion. Name the CaseFlow artifacts you can demonstrate without claiming a live customer result.

## Answer key {:#answers}

1. “Six active out of twelve eligible would be 50% *reach* in the same window, not a 50% productivity gain. Compare similar tasks, review and defect evidence, and developer feedback against a documented baseline before drawing a guarded conclusion.”
2. Example: consenting Rails team; synthetic `CaseFlow` repository and scoped status-transition review; approved IDE mode only; no customer records, secrets or tokens; engineering/security owner can halt. Actual client choice must replace this exercise example.
3. GitHub documents content-exclusion limitations for Edit/Agent modes in editors. Check the current support matrix for the client's exact feature; prohibit sensitive data in prompts, limit repository access and review requests even when an exclusion is configured.
4. Eligible cohort comes from the pilot charter/license roster with consent; active users from authorized Copilot usage reporting; PR rework and defects from engineering/incident systems; friction from voluntary feedback; incidents from security reporting. Some telemetry requires role permissions and aggregation.
5. Reach is **6 ÷ 8 = 75%** in this invented example. With no comparable baseline and only five PRs, a prudent response is **revise/extend measurement** (assuming no other guardrail concerns); no quality or speed gain is demonstrated. An actual incident would prompt pause regardless of adoption.
6. The template has headers only, so no observation exists. Approval flag is an operator attestation that reporting has been reviewed, not proof of consent, source validity, small-cohort anonymity or causal impact. The script rejects negative/invalid counts and active > eligible but cannot verify true source data.
7. A strong answer proposes a short, opt-in cohort; CaseFlow orientation + bounded PR; exact permissions and prompt hygiene; use/activity plus PR quality and safety; and an owner who can stop. Refer to the source-reviewed CaseFlow map, local candidate patch and staged CI without pretending they ran in a production organization.

## Transfer and references {:#transfer}

Repeat the exercise using a different task (e.g., Rails service object modernization), then ask which confounders changed. See the [article](../posts/05-adoption-and-governance/article.md), [charter](../../parts/05-adoption-and-governance/PILOT-CHARTER.md), [GitHub trial measurement guide](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success) and [content exclusion limitations](https://docs.github.com/en/copilot/concepts/security-governance-and-network-settings/content-exclusion).

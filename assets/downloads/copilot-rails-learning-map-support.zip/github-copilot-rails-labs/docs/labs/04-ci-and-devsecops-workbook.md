# Study workbook 04 · From agent patch to review evidence

*Predict → prepare → observe → diagnose → decide.* Allow 45–65 minutes with a working Ruby environment, or complete the source-only track without one. Read the [article](../posts/04-ci-and-devsecops/article.md) and attempt the exercises before the [answer key](#answers).

## Contents

- [Learning outcomes](#outcomes)
- [Evidence model](#model)
- [Exercises](#exercises)
- [Answer key](#answers)
- [Transfer and references](#transfer)

## Learning outcomes {:#outcomes}

Distinguish an assertion, a proposed CI command, an observed runner result and a human approval; build a lockfile prerequisite for repeatable Rails CI; classify setup, test and policy blockers; explain the coverage and limits of RSpec, dependency review, static analysis and code scanning.

## Evidence model {:#model}

| Claim | Inspect | Mark as |
|---|---|---|
| A spec asserts wrong token → 401 | Candidate patch | Source assertion; no run implied |
| CI would run RSpec | `rails-pr.yml` | Proposed workflow |
| RSpec returned 0 or failed | Your local terminal or GitHub job log | Observed result tied to commit |
| Token policy is suitable for a client | Reviewed requirements and decision maker | Human product/security judgment |

The [Mermaid source](../diagrams/04-ci-evidence.mmd) keeps the blocker branch visible.

## Exercises {:#exercises}

### 1 · Two failures before specs (5 min)

Without running anything, predict two reasons `rails-pr.yml` could fail before its RSpec step on the supplied baseline. Name the exact source artifact for each prediction.

### 2 · Trace the setup dependency (10 min)

Find the app `Gemfile`, absence or presence of `Gemfile.lock`, `database.yml` and the staged workflow. Explain what `bundle config set frozen true` changes. If you have Ruby on your Mac, generate the lockfile with `bundle install`, inspect it, then run `RAILS_ENV=test bin/rails db:prepare`. Record your versions and actual output in your copy of [`REVIEW-GATES.md`](../../parts/04-ci-and-devsecops/REVIEW-GATES.md). If Ruby is absent, state the blocker and continue with source review.

### 3 · A negative spec, not a green badge (10 min)

Inspect [Part 03's candidate patch](../../parts/03-issue-to-pr/candidate.patch). Identify the behavior expected for a wrong/missing operator token. Then choose the *run command* needed to observe it. What can you say about the outcome before running the command?

### 4 · Choose and limit two controls (8 min)

A PR changes `Gemfile` and the resolve action. Pair (A) dependency review and (B) Brakeman with the question each can help answer. Name a business-policy question neither answers. Under what conditions can CodeQL give you an actual alert?

### 5 · Classify a failed job (7 min)

**Hypothetical scenario:** `bundle install` stops because the lockfile is absent; no later step runs. Write a one-sentence PR note that uses *blocked*, *not run* and a next action. Should the failing or skipped spec be described as a failed assertion?

### 6 · Transfer (5 min)

For a Rails change involving a background job retry, propose one negative RSpec example, one CI/security check and one human judgment a green check cannot replace.

## Answer key {:#answers}

1. The baseline contains `caseflow/Gemfile` but **no** `caseflow/Gemfile.lock`: frozen Bundler can block install. Ruby/Bundler compatibility or gem resolution may also block install. The workflow is in `parts/04-ci-and-devsecops/rails-pr.yml`, not an activated `.github/workflows/` directory; that prevents any GitHub job from starting until installed. These are predictions, not logs.
2. `Gemfile` bounds gem families; `database.yml` uses SQLite files, including `storage/test.sqlite3`; a reviewed lockfile pins resolved versions. Frozen mode refuses changes to dependency resolution. `db:prepare` is the proposed database setup. Record the real result, including errors; none is supplied here.
3. The candidate spec expects unauthorized responses for missing/wrong token and no persisted transition. Apply the candidate patch in a clean checkout, then run `bundle exec rspec spec/requests/api/requests_spec.rb` in `caseflow/`. Before the run, only the source assertion can be reported, not a passing test.
4. Dependency review compares newly introduced dependency versions in a PR, subject to repository configuration. Brakeman scans Rails source for recognized risky patterns once added as a dependency/tool; it cannot decide who *should* resolve a customer request. CodeQL alerts require actual configuration, eligibility and a completed scan; no alert is claimed here.
5. Example: “CI setup is **blocked** by a missing lockfile; request specs were **not run**; generate, review and commit `caseflow/Gemfile.lock`, then rerun this commit.” No assertion failed because RSpec never executed.
6. Example: RSpec asserts repeated delivery does not double-send; CI runs it on the locked bundle; a human chooses retry windows and externally acceptable duplicate handling. Other evidence-backed answers are valid.

## Transfer and references {:#transfer}

Revisit this worksheet after your first real GitHub Actions run. Compare the actual run URL, commit SHA, exit status and reviewer decision with the predictions above. See [Part 04 article](../posts/04-ci-and-devsecops/article.md), [GitHub Ruby CI guide](https://docs.github.com/en/actions/tutorials/build-and-test-code/ruby), [dependency review](https://docs.github.com/en/code-security/how-tos/secure-your-supply-chain/manage-your-dependency-security/configure-dependency-review-action) and [secure use](https://docs.github.com/en/actions/reference/security/secure-use).

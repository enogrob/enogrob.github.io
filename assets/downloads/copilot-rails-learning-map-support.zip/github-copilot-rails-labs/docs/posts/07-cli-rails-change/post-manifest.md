# Part 07 · Production and visual manifest

## Contents

- [Teaching goal](#goal)
- [Visual script](#visual)
- [Checks and limits](#checks)
- [References](#references)

## Teaching goal {:#goal}

An English blog post and cumulative Rails lab teach a bounded Copilot CLI session on a Mac: scoped directory → source-grounded plan → tool approval → candidate diff → observed or blocked test → human review. The CLI is not run during authoring. Source declarations, hypothetical candidate actions and unobserved runtime behavior are visibly separated.

## Visual script {:#visual}

| Asset | Context and reader question | Boundary |
|---|---|---|
| [Cover](assets/cover.webp) · [PNG master](assets/cover-source.png) | Can a recognizable Rails source, CLI plan and proposed diff form an auditable path to human review? | `TEST ?` is pending. No fictitious transcript, successful run or accepted PR. One digitized side-profile guide faces the technical scene. |
| [Permission illustration](assets/permission-boundary.webp) · [PNG master](assets/permission-boundary-source.png) | How are the trusted project, tool request, human review and unrun console different? | External gray folder remains outside scope; a tool request does not imply automatic authorization; no pass mark. |
| [Mermaid flow](../../diagrams/07-cli-evidence-gates.mmd) | What evidence step follows planning and what happens on a blocked run? | Proposed lab procedure, not an actual CLI transcript. |

Typography reference: [Inside GitHub Copilot's Agentic Engine](https://enogrob.github.io/artificial-intelligence/software-engineering/agentic-ai/github-copilot/2026/09/23/inside-github-copilot-agentic-engine.html); continuity checks: [Part 05 cover](../05-adoption-and-governance/assets/cover.webp) and [Part 06 cover](../06-client-workshop/assets/cover.webp). Cover uses same small overtitle, large two-line condensed headline and subordinate navy subtitle. White canvas, fine emerald network and Holoflux are continuity cues. The terminal focal subject and close-up permission gate are different compositions. No Factory logo, QR or author credit.

## Checks and limits {:#checks}

- Article and companion Markdown identical except for the Mermaid opening fence and image paths (`mermaid!` in Jekyll, `mermaid` in companion Markdown), Mermaid fence equals source `.mmd`, images exported 1600×900, paths and alt text checked statically.
- Ruby preflight is read-only. Ruby, Bundler, Copilot CLI, database, RSpec and Jekyll browser rendering have **not** run here; no results are depicted.
- Check the 1600×900 cover at mobile thumbnail size and inspect the internal illustration in the actual blog before publishing. Confirm current GitHub product settings in the client environment.

## References {:#references}

- [Full article](article.md) · [workbook](../../labs/07-cli-workbook.md) · [runbook](../../../parts/07-cli-rails-change/RUNBOOK.md) · [visual standard](../../visual-standard.md)
- [Official CLI installation](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/install-copilot-cli) · [usage and permissions](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/overview)

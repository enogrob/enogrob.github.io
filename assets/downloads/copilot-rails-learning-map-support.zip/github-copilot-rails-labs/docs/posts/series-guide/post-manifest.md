# Series guide · source and publishing manifest

- Editorial role: unnumbered navigation guide to the eight published posts; future ebook front matter candidate.
- Portable article: `docs/posts/series-guide/article.md` (`mermaid` plus relative `assets/` images); Jekyll edition: `_posts/2026-09-26-the-eight-part-github-copilot-for-rails-learning-map.md` (`mermaid!` plus blog-root image paths). Other article content matches.
- Visual masters and WebP: `docs/posts/series-guide/assets/`; publishing destinations: `/assets/images/posts/copilot-rails-learning-map/`.
- Cover: side-profile digital engineer + tangible CaseFlow Rails desk + eight distinct topic stations, grounded in the approved Agentic Engine cover. Station numbers are conceptual, not links or evidence of completion.
- Section: two intertwined routes through a physical workbench; code-like microtext intentionally removed to avoid fabricating technical details. The exact learning map is Markdown and `docs/diagrams/series-learning-map.mmd`.
- References compared: Inside GitHub Copilot’s Agentic Engine cover, When Ruby Made the Industry Rethink Programming cover, Intelligence in Motion Holoflux cover. The first supplied local approved reference directly; the latter two are linked from the live blog. White field, condensed navy/green hierarchy, green mesh, Holoflux and meaningful ruby accent maintained.
- Visual review (1–5): historical fit 5; canonical background 5; foreground motion/depth 5; content fit 5; cross-image continuity 4; thumbnail clarity 4; semantic color 4; text accuracy 5. Editorial judgment, not an automated measurement. Source diagrams and URLs require site-render verification on publication.
- No application behavior, test execution or measured adoption is asserted by generated art.

# Post 06 · Visual and production manifest

## Contents

- [Visual script](#visual)
- [Source and evidence](#sources)
- [Release checks](#checks)
- [References](#references)

## Visual script {:#visual}

| Asset | What the image teaches | Accuracy boundary |
|---|---|---|
| [Cover WebP](assets/cover.webp) / [PNG master](assets/cover-source.png) | Digitized side-profile guide, an accurate route → controller → model → SQLite conceptual source map and human engineering/security discussion lead to a compass with three possible next steps. | No code screenshot or observed outcome; the source map uses conceptual labels. The small spaced series overtitle, dominant two-line title and subordinate subtitle match the reference cover hierarchy. |
| [Evidence WebP](assets/roadmap-needs-evidence.webp) / [PNG master](assets/roadmap-needs-evidence-source.png) | In an illustrated source inspection, the real baseline Rails route declarations are distinct from the Part 03 proposed PATCH route, which sits beside an empty test log. The magnifier highlights the missing baseline update route. | The source shows GET/POST request routes; PATCH /api/requests/:id/resolve is only on the candidate panel. No test or approval result. Distinct source-inspection scene, not a repeat of the cover. |
| [Mermaid source](../../diagrams/06-workshop-decision.mmd) | Evidence is classified, verified and assigned before selecting the next step. | Proposed process, not a record of a held meeting. |

Primary reference: [Inside GitHub Copilot's Agentic Engine](https://enogrob.github.io/artificial-intelligence/software-engineering/agentic-ai/github-copilot/2026/09/23/inside-github-copilot-agentic-engine.html) cover hierarchy and internal infographic idiom; adjacent [Part 05 cover](../05-adoption-and-governance/assets/cover.webp); [Bohm/Holoflux anchor](https://enogrob.github.io/artificial-intelligence/architecture/agentic-ai/philosophy/2026/09/22/intelligence-in-motion-bohm-holoflux-ai-agents.html). White field, condensed navy type, green emphasis, corner node mesh, flowing multicolor signal. No logo or author in the art. Compare in the target site at desktop/mobile widths before publishing.

## Source and evidence {:#sources}

- Baseline CaseFlow has no status update endpoint; the status change is a candidate Part 03 patch.
- Part 04 Actions sample remains staged. Part 05 CSV remains header-only. Every recommendation and workshop dialog is explicitly hypothetical.
- The blog article and this companion's `article.md` are identical except for the Mermaid opening fence and image paths (`mermaid!` in Jekyll, `mermaid` in companion Markdown); keep exact Mermaid source in the article.

## Release checks {:#checks}

- PNG masters and 1600×900 WebP exports for both visuals; alt text and section placement reviewed.
- ZIP integrity and Markdown link checks are performed locally. Ruby, Bundler, Jekyll and browser rendering are not available/observed in the authoring environment.
- An author/publisher must inspect desktop/mobile rendering and current GitHub policy settings before making this public.

## References {:#references}

- [Article](article.md) · [workbook](../../labs/06-workshop-workbook.md) · [agenda](../../../parts/06-client-workshop/WORKSHOP-AGENDA.md)
- [GitHub's rollout documentation](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale) · [trial guidance](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success)

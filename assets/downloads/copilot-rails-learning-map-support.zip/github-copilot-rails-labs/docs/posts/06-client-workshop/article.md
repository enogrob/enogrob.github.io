---
layout: post
title: "From Rails Evidence to Client Roadmap"
subtitle: "A Workshop That Earns the Next Step"
date: 2026-09-26
categories: [ruby, rails, software-engineering, github-copilot]
tags: [rails, github-copilot, consulting, workshop, engineering-roadmap]
description: "Use a 90-minute client workshop to turn a Rails repository map, proposed PR, CI gates and Copilot pilot design into an evidence-backed roadmap with named owners."
image: assets/cover.webp
mermaid: true
---

<img src="assets/cover.webp" alt="GitHub Copilot for Rails Engineers Part 06: a digital profile follows CaseFlow from a route/controller/model/SQLite map into an engineering and security workshop; a decision compass shows try, revise and pause as possible next steps." style="width:100%;height:auto;">

> **A good Copilot workshop leaves the client with a decision they can defend.** Bring source citations, proposed changes and honest unknowns; leave with a small next experiment, named owners and a stop rule.

*GitHub Copilot for Rails Engineers · Part 06*

This series started by mapping an unfamiliar Rails app. It then added repository instructions, a candidate agent-assisted change, a staged CI/security plan and a blank adoption pilot. These are useful teaching artifacts, but a consultant must not transform a proposed patch into a “successful rollout” by storytelling. This final chapter asks how to run a **90-minute client workshop** that turns those artifacts into a scoped, accountable next step. The client, meeting and roadmap here are hypothetical.

The [cumulative companion download](/assets/downloads/rails-evidence-client-roadmap-support.zip) includes the complete CaseFlow Rails app, Parts 01–06, a facilitator agenda, claim ledger, one-page roadmap, blank decision record, exercises and answers, and the editable Mermaid source. No enterprise settings, run results or customer telemetry were collected for this example.

## Contents

- [Begin with the client's decision](#decision-first)
- [Bring an evidence pack, not a promise](#evidence)
- [Run a workshop that surfaces disagreement](#workshop)
- [Turn unknowns into a bounded roadmap](#roadmap)
- [Close with an accountable decision](#close)
- [Practice the facilitation](#lab)
- [References and supporting material](#references)

## Begin with the client's decision {:#decision-first}

The useful opening question is concrete: *Which Rails workflow should this team test with Copilot, under which data boundaries, and what evidence would justify another step?* Ask the engineering sponsor what costly friction they want to change, the maintainer what repository task is safely bounded, and the security reviewer what permissions and prompt inputs are allowed. If they disagree, record the disagreement. Agreement by the loudest participant is not governance.

Choose a single example: understanding how `POST /api/requests` moves through CaseFlow and proposing a narrow status transition. The baseline app declares create/list/show endpoints but no status-update route. [Part 03's patch](#references) is a candidate, not a deployed endpoint; [Part 04's workflow](#references) is staged, not a passing CI run. The Part 05 CSV has only a header. Present those boundaries during the workshop, before anyone draws a roadmap from imagined performance gains.

GitHub's [rollout guidance](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale) covers enablement, governance and measurement. Its [trial guide](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success) calls for goals, adoption evidence, developer feedback and a later decision about expansion. These resources inform the agenda; the client still decides authorization, scope and success criteria.

## Bring an evidence pack, not a promise {:#evidence}

Before the meeting, make a short ledger with four different statuses. A file's existence establishes what is written there; a test assertion states the expected behavior; a real test run gives environment-specific evidence; an approval belongs to the accountable reviewer. Keep the distinction visible on screen.

| Artifact to show | Defensible statement | Unknown to resolve | Owner to ask |
|---|---|---|---|
| CaseFlow route, controller, model and migration | Source declares a request API and SQLite-backed model | Actual run and chosen deployment behavior | Rails maintainer |
| Part 03 candidate patch | Reviewable status-change proposal exists | Does it apply, pass focused specs and meet review policy? | Engineering reviewer |
| Part 04 staged Actions workflow | Planned Rails test gate with restricted permissions | Resolved lockfile, runner output, applicable security gates | CI/security owners |
| Part 05 charter and header-only CSV | Measurement and privacy questions have templates | Eligible cohort, baseline, approved surfaces, measured outcomes | Sponsor + pilot owner |

The companion [claim ledger](#references) has file references, evidence statuses, checks and suggested roles. Replace role labels with real names only once the client appoints owners. Never copy secrets or customer code into the demonstration repo.

## Run a workshop that surfaces disagreement {:#workshop}

The [90-minute agenda](#references) timeboxes the session: ten minutes for the decision question, fifteen for a source walk, twenty for candidate PR and CI review, fifteen for data and policy boundaries, twenty for the next experiment, and ten to replay the decision. Move security discussion earlier if the reviewer must leave early. A participant with authority to approve access should be identified before proposing activation.

Use one source-backed claim to test the conversation: “The baseline has a status-update API.” Open `caseflow/config/routes.rb` and ask someone to locate it. When it is not there, move the claim into “proposed change” and inspect the Part 03 patch. Then ask: “Which request spec, CI result and reviewer sign-off would make this safe to try?” This turns a disagreement into a verification task, not a contest over confidence.

Do the same for metrics. “Copilot was used” and “the work improved” answer different questions. The Part 05 template requires a cohort denominator and comparable engineering signals; the example contains no observed values. GitHub's [measurement path](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-copilot-impact) distinguishes adoption from engineering outcomes. A small workshop cannot create causal evidence by drawing a rising chart.

<img src="assets/roadmap-needs-evidence.webp" alt="An illustrated CaseFlow Rails source inspector shows only GET and POST request routes in the baseline; a separate proposed PATCH resolve route and an empty test log need verification by a reviewer." style="width:100%;height:auto;">

*The illustration resolves a specific workshop dispute:* the baseline source declares index, show and create; the status transition belongs to the separate candidate patch and still needs a test run and human review. The editable Mermaid below carries the broader workshop decision model.

```mermaid
%%{init: {'theme':'base','themeVariables':{'background':'#FFFFFF','primaryTextColor':'#3E342C','lineColor':'#6F7377'}}}%%
flowchart TB
    subgraph inputs["📚 Bring evidence"]
      A["🧭 Repository map"] --> C["🗂️ Claim ledger"]
      B["🧪 Candidate PR + CI plan"] --> C
      P["📊 Empty pilot template"] --> C
    end
    subgraph workshop["👥 Decide together"]
      C --> V["🔍 Verify or mark unknown"]
      V --> O["👤 Owner + success check"]
    end
    subgraph next["🧭 Record next step"]
      O -->|"bounded, approved"| T["🧪 Try a slice"]
      O -->|"insufficient evidence"| R["🔁 Revise scope"]
      O -->|"guardrail breach"| S["⛔ Pause"]
    end
    classDef source fill:#D9EAF7,stroke:#7AA6C2,color:#3E342C;
    classDef unknown fill:#FFF1BF,stroke:#BA9C43,color:#3E342C;
    classDef human fill:#E8DDF5,stroke:#A68BC4,color:#3E342C;
    classDef try fill:#DCEFD6,stroke:#86A878,color:#3E342C;
    classDef revise fill:#F8DFC4,stroke:#C9986D,color:#3E342C;
    classDef stop fill:#F5D9DC,stroke:#BC8191,color:#3E342C;
    class A,B,P source;
    class C,V unknown;
    class O human;
    class T try;
    class R revise;
    class S stop;
```

This is a **proposed** workshop flow. No branch is selected in the supplied materials; the decision record is blank. The matching editable diagram lives in `docs/diagrams/06-workshop-decision.mmd` inside the download.

## Turn unknowns into a bounded roadmap {:#roadmap}

A useful roadmap is ordered by *evidence dependencies*, not optimistic dates. Validate the Rails source and record an actual RSpec result or blocker. Then review the candidate change with the human engineering owner and determine which CI/security controls apply. Only after the authorized team defines permissible Copilot surfaces and data should it consider a consenting trial with a baseline, comparison criteria and incident path. The [one-page roadmap](#references) supplies these slices with deliberately unassigned names and no fabricated schedule.

Avoid the tempting shortcut “roll out to everyone next sprint.” If an IDE agent, cloud agent and terminal workflow are all proposed, discuss them **separately**: permissions, repository access, data exposure and policy support can differ by surface. The [Copilot cloud agent documentation](https://docs.github.com/en/copilot/concepts/agents/cloud-agent/about-cloud-agent) and [organization policies](https://docs.github.com/en/copilot/how-tos/administer-copilot/manage-for-organization/manage-policies) are starting points for checking current behavior and client settings. A role-specific approval and documented review gate remain client decisions.

Show the client an example of a testable recommendation: “Authorize one consenting Rails cohort to try source orientation on one approved repository for a defined interval, after security checks the allowed surface and prompt data. Compare like-for-like PR rework and test outcomes with a stated baseline; pause on a serious boundary breach.” This is a **proposal**, not a statement that anyone authorized or completed that experiment. Define numerical criteria with the sponsor before data collection; do not invent thresholds in the article.

## Close with an accountable decision {:#close}

The final ten minutes produce a signed or explicitly pending [decision record](#references). It lists the chosen next step, the claims and observations behind it, who owns each unresolved check, the checkpoint, and what would force a pause. It is valid to end with “revise” or “pause” when the baseline, permission or security owner is missing. The engineering team still gets a clear next task and the sponsor can see exactly what is blocking approval.

In an interview, a two-minute version is enough: “I would bring a source-backed CaseFlow map and a candidate PR, separate planned CI from observed results, let the security and engineering owners settle scope, and leave with one bounded experiment and a stop rule. I would not report adoption benefit from an empty CSV.” This demonstrates consultative architecture without inventing a client engagement.

## Practice the facilitation {:#lab}

1. **Before (10 min):** inspect the [agenda and claim ledger](#references). Classify one source fact, one proposed change and one missing run result.
2. **Live (15 min):** pair with a reviewer; challenge the statement “the workflow passed” using the actual staged workflow and the absence of runner logs. Switch roles and repeat.
3. **Decision (15 min):** fill the [roadmap and decision record](#references) for a fictional client who has no approved prompt-data policy. Choose a next step, name the owner, and state what cannot launch.
4. **Debrief (10 min):** deliver a two-minute recommendation, then compare it with the [workbook answers](#references). Rewrite any sentence that confuses a source declaration with an observed result.

The [full workbook](#references) includes a prediction, a misleading-claim challenge, an agenda repair exercise, a safety scenario and sample answers. The companion code is Ruby/Rails; this final workshop is a facilitation exercise and introduces no new runtime code.

## References and supporting material {:#references}

- [Download the cumulative CaseFlow companion and Part 06 workshop materials](/assets/downloads/rails-evidence-client-roadmap-support.zip). Start at `README.md` → `parts/06-client-workshop/README.md` → `docs/posts/06-client-workshop/article.md`.
- Companion files: `parts/06-client-workshop/WORKSHOP-AGENDA.md`, `CLAIM-LEDGER.md`, `ROADMAP.md`, `DECISION-RECORD.md`, `docs/labs/06-workshop-workbook.md`, `docs/diagrams/06-workshop-decision.mmd`, `docs/posts/06-client-workshop/post-manifest.md`.
- Previous chapter artifacts: `parts/03-issue-to-pr/candidate.patch`; `parts/04-ci-and-devsecops/rails-pr.yml`; `parts/05-adoption-and-governance/PILOT-CHARTER.md` and `pilot-observations.csv`.
- [GitHub Docs: rolling out Copilot at scale](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale); [measuring a trial](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success); [connecting adoption with engineering outcomes](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-copilot-impact).
- [GitHub Docs: organization Copilot policies](https://docs.github.com/en/copilot/how-tos/administer-copilot/manage-for-organization/manage-policies); [Copilot cloud agent](https://docs.github.com/en/copilot/concepts/agents/cloud-agent/about-cloud-agent); [content exclusion limits](https://docs.github.com/en/copilot/concepts/security-governance-and-network-settings/content-exclusion).

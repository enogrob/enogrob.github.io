# Post 08 · Production and visual manifest

## Contents

- [Visual script](#visual)
- [Evidence and verification](#checks)
- [References](#references)

## Visual script {:#visual}

| Asset | Context and reader question | Accuracy boundary |
|---|---|---|
| [Cover WebP](assets/cover.webp) / [PNG master](assets/cover-source.png) | A digital side-profile guide faces a CaseFlow Rails app; instructions and an optional skill influence the task, while optional hook/MCP remain distinct and a human fills the final ledger. | Question marks mean optional, ledger blank; no deployed feature or passing result. |
| [One-task illustration](assets/one-request-many-boundaries.webp) / [PNG master](assets/one-request-many-boundaries-source.png) | One local tool action is supported by persistent instructions and an optional recipe; inactive hook and separated external MCP bridge do different jobs; a human evidence sheet stays empty. | No actual service connection, hook configuration, installed skill or executed test is depicted. |
| [Mermaid source](../../diagrams/08-workflow-boundaries.mmd) | Exact roles and optional edge for an external need, followed by a human decision. | A proposed workflow, not runtime output. |

Reference style and typography: [Inside GitHub Copilot's Agentic Engine](https://enogrob.github.io/artificial-intelligence/software-engineering/agentic-ai/github-copilot/2026/09/23/inside-github-copilot-agentic-engine.html), [Part 07 cover](../07-cli-rails-change/assets/cover.webp), [Part 06 cover](../06-client-workshop/assets/cover.webp). Pure white, navy condensed two-line headline with one green keyword, small eyebrow, modest subtitle, emerald mesh and flowing multicolor Holoflux. The internal composition is a cutaway local action and differs from the cover's source-to-review tableau. No Factory/Zoatworks logo, author or QR.

## Evidence and verification {:#checks}

- The article and companion source are identical except for the Mermaid opening fence and image paths (`mermaid!` in Jekyll, `mermaid` in companion Markdown); the Jekyll `mermaid!` block matches the editable `.mmd` exactly. Two 1600×900 WebP exports and original PNG masters accompany it.
- `EVIDENCE.json` intentionally lacks observed values. The Ruby validator checks only local record structure and local path existence; a zero exit cannot prove output authenticity or authorization.
- Ruby, Rails, Copilot CLI, skill loading, hooks, MCP and Jekyll/browser rendering were not run or installed during authoring. Before publication inspect desktop/mobile legibility and current product documentation.

## References {:#references}

- [Full article](article.md) · [workbook with answers](../../labs/08-workflow-workbook.md) · [blueprint](../../../parts/08-repeatable-rails-workflow/WORKFLOW-BLUEPRINT.md)
- [GitHub CLI mechanism comparison](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/comparing-cli-features) · [skills guide](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills) · [hooks reference](https://docs.github.com/en/copilot/reference/hooks-reference)

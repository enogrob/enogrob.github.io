---
layout: post
title: "A Copilot Pilot You Can Measure"
subtitle: "Adoption, Guardrails and Evidence for Rails Teams"
date: 2026-09-26
categories: [ruby, rails, software-engineering, github-copilot]
tags: [rails, github-copilot, adoption, governance, engineering-metrics]
description: "Design a small GitHub Copilot pilot for Rails teams with a baseline, consent and policy guardrails, usage and quality signals, and an honest expansion decision."
image: assets/cover.webp
mermaid: true
---

<img src="assets/cover.webp" alt="GitHub Copilot for Rails Engineers Part 05: a Rails team scopes a pilot around CaseFlow, establishes a baseline, observes usage, quality and safety separately, and reaches an expand, revise or pause decision beside a digital Copilot-inspired profile." style="width:100%;height:auto;">

> **Usage tells you who tried Copilot; it cannot tell you what improved.** Design a small Rails pilot that measures engineering outcomes, protects sensitive context and gives the team a real decision at the end.

*GitHub Copilot for Rails Engineers · Part 05*

The first four parts followed one CaseFlow Rails repository from orientation to a proposed, reviewed patch and a staged CI workflow. None of those artifacts means a team should turn on every Copilot capability overnight. A solutions architect has to ask a different question: **who can safely try which workflow, what would count as improvement, and what would make us stop?** This article lays out a synthetic 2–4 week pilot. It describes a plan, not an engagement that has taken place.

The [cumulative companion package](/assets/downloads/measurable-copilot-rails-pilot-support.zip) includes Parts 01–05, a complete CaseFlow app, a pilot charter, an empty aggregate CSV template, a Ruby summarizer, exercises and answers, and the original Mermaid source. **There are no collected user metrics, measured productivity gains or configured enterprise settings in this package.** The team must obtain consent and validate its actual GitHub plan, product settings and data access before any real pilot.

## Contents

- [Choose one bounded question](#question)
- [Set the safety boundaries first](#guardrails)
- [Separate usage from engineering outcomes](#measures)
- [Collect the smallest useful evidence](#evidence)
- [Decide whether to expand](#decision)
- [Try the 50-minute lab](#lab)
- [References and supporting material](#references)

## Choose one bounded question {:#question}

Here is a useful **hypothesis**, not a promised result: *Can a small Rails team use Copilot to orient in unfamiliar code and draft bounded changes while keeping review quality and sensitive context under control?* Start with a willing cohort, one Rails repository, two narrow tasks and a named engineering owner. CaseFlow's [Part 01](#references) repository map and [Part 03](#references) issue-to-patch exercise are examples of task types; the synthetic app is not customer production code.

Write down before enabling the tool: who may participate; which repo and feature modes are in scope; what data may be sent into prompts; what PR evidence is required; who can pause the pilot; how to collect qualitative feedback; and how long the baseline and pilot windows are. Define comparable work types and any concurrent changes (new reviewer policy, migration, incident) that could affect a comparison. In a 2–4 week pilot, those factors can dominate the signal. Never present a directional association as proof Copilot caused it.

GitHub's [trial measurement guidance](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success) recommends goals, adoption/engagement evidence, developer feedback and a decision about expansion. Treat that guidance as a framework; the appropriate thresholds and governance authority belong to the client.

```mermaid
%%{init: {'theme':'base','themeVariables':{'background':'#FFFFFF','primaryTextColor':'#3E342C','lineColor':'#6F7377'}}}%%
flowchart TB
    subgraph scope["🎯 Define the pilot"]
      Q["📋 Task + cohort"] --> G["🛡️ Consent + boundaries"]
    end
    subgraph evidence["🔍 Observe separately"]
      G --> B["📍 Baseline"]
      B --> U["👥 Usage + feedback"]
      B --> E["🧪 Review + quality"]
    end
    subgraph learn["🧭 Interpret and decide"]
      U --> D["📝 Human evaluation"]
      E --> D
      D -->|"guardrail breach"| S["⛔ Pause + remediate"]
      D -->|"evidence insufficient"| R["🔁 Revise scope"]
      D -->|"criteria met"| X["👤 Approve next cohort"]
    end
    classDef input fill:#D9EAF7,stroke:#7AA6C2,color:#3E342C;
    classDef guard fill:#F5D9DC,stroke:#BC8191,color:#3E342C;
    classDef activity fill:#E8DDF5,stroke:#A68BC4,color:#3E342C;
    classDef quality fill:#DCEFD6,stroke:#86A878,color:#3E342C;
    classDef caution fill:#FFF1BF,stroke:#BA9C43,color:#3E342C;
    classDef decision fill:#F8DFC4,stroke:#C9986D,color:#3E342C;
    class Q,B input;
    class G,S guard;
    class U activity;
    class E quality;
    class R caution;
    class D,X decision;
```

This is a **proposed decision loop**. It does not represent a running customer program. The matching Mermaid source is in `docs/diagrams/05-pilot-decision.mmd` in the download.

## Set the safety boundaries first {:#guardrails}

Make a short, explicit threat and data map. Copilot use in VS Code, GitHub.com and cloud agents is not one uniform surface. The organization chooses which capabilities to allow; repository access, feature policy, data handling and permissible prompt content need to be checked **per surface**. Ask a security owner to decide on customer data, credentials, private repositories and any regulated material before trying realistic tasks.

| Boundary | Pilot choice to document | Verification before launch |
|---|---|---|
| Repository and actor | One approved Rails repo and participant cohort | Access list, least privilege and enrollment record |
| Prompts and context | Synthetic CaseFlow examples; no customer records or tokens | Prompt rules, example review, approved data types |
| Agent actions | Default to draft and human review for any proposed PR | Repository agent settings, allowed tools and review rules |
| Content exclusion | Identify sensitive paths but **verify limits by feature** | Test the exact VS Code/agent surface; do not assume a universal shield |
| Change control | Require source review, CI evidence and owner decision | Branch protections and escalation route in the target repo |
| Measurement | Aggregate only the minimum needed | Permission, retention period and cohort size review |

GitHub documents [organization Copilot policies](https://docs.github.com/en/copilot/how-tos/administer-copilot/manage-for-organization/manage-policies), and its [content exclusion guide](https://docs.github.com/en/copilot/concepts/security-governance-and-network-settings/content-exclusion) warns that exclusions do **not** cover every feature or mode; in particular, Edit and Agent modes in editors have limitations. Verify the current support table and test the exact client before relying on exclusion. A written rule not to put secrets into prompts remains necessary. GitHub's [cloud agent overview](https://docs.github.com/en/copilot/concepts/agents/cloud-agent/about-cloud-agent) describes an agent that can make code changes for review; enabling it requires separate consideration from IDE suggestions.

## Separate usage from engineering outcomes {:#measures}

<img src="assets/usage-is-not-impact.webp" alt="Three proposed evidence lanes from a Rails pilot: reach among eligible developers, quality through rework and defects, and safety through incidents, converging on a baseline comparison marked with a question mark; no measured results are shown." style="width:100%;height:auto;">

*Activity and quality answer different questions.* Usage telemetry tells you whether eligible developers tried the tool and how engagement changes. Code review, CI and defect evidence tell you how work is going. Developer feedback can explain friction that neither number shows. GitHub's [Copilot usage metrics](https://docs.github.com/en/copilot/reference/copilot-usage-metrics) provide usage and engagement fields; GitHub's [measurement path](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-copilot-impact) explicitly moves from adoption to engineering outcomes. The API and dashboards require suitable access and can present different aggregations; check definitions and permissions before collecting.

| Lens | Candidate measure | Source and interpretation guard |
|---|---|---|
| Reach | Active Copilot users ÷ eligible pilot developers per time window | Only within an agreed cohort; do not publish identifiable small-group usage. |
| Experience | Anonymous feedback on usefulness and context switching | Ask task-specific questions; record selection bias and missing responses. |
| Delivery | Comparable PR review turnaround and change size | Compare similar work, not a fast typo fix with an API migration. |
| Quality | Review rework, test failures, escaped defects | Keep denominator and observation period; an early increase can reflect better detection. |
| Safety | Prompt policy incidents, access exceptions, unresolved findings | A serious breach triggers pause regardless of high activity. |

For example, if a report lists *active users*, the ratio needs an **eligible** cohort size for the same time window; assigned licenses alone are not an outcome. Do not calculate a universal “productivity score” by mixing hours, lines of code and review comments. GitHub's [interpretation guide](https://docs.github.com/en/copilot/reference/copilot-usage-metrics/interpret-copilot-metrics) explains how usage metrics should be read, including window definitions. Your pilot's engineering signals come from the team's own PR, CI and incident systems and require careful comparison.

## Collect the smallest useful evidence {:#evidence}

The companion `parts/05-adoption-and-governance/pilot-observations.csv` is intentionally **header-only**. Fill one aggregate row per cohort and period after permission and source checks. No names, emails, prompt content, source code, customer records or raw tokens belong in it. The accompanying `scripts/summarize_pilot.rb` validates integer counts and prints an adoption ratio only where a valid denominator exists; it refuses an empty dataset and makes no causal inference.

```bash
ruby scripts/summarize_pilot.rb parts/05-adoption-and-governance/pilot-observations.csv
```

No script execution or pilot observation was completed in this authoring environment. The [pilot charter](#references) supplies field definitions, privacy review and a decision log. For a real organization with permission, use GitHub's [usage metrics documentation](https://docs.github.com/rest/copilot/copilot-usage-metrics) as the starting point for its *actual* telemetry; this package does not fetch or process user-level API data. Follow the organization's retention and reporting rules.

## Decide whether to expand {:#decision}

At the checkpoint, ask three separate questions. **Was use enabled and helpful?** Check activity and qualitative feedback. **Was engineering quality at least acceptable for this scoped work?** Inspect PR and CI evidence alongside the pre-pilot baseline and note confounders. **Were the boundaries respected?** Review incidents, data handling and policy exceptions. A strong usage graph cannot cancel a sensitive-context breach. An absent baseline or tiny incomparable sample warrants learning more rather than a claim of benefit.

Choose and record *expand to another cohort*, *revise and rerun*, or *pause*. State who owns the decision and what evidence would change it. The reusable [decision worksheet](#references) has blank cells on purpose. In an interview, this framing lets you explain how you would deliver a small client engagement without claiming a deployment or numbers you have not observed.

## Try the 50-minute lab {:#lab}

1. **Scope (10 min):** pick two CaseFlow tasks and write the pilot hypothesis, cohort and one exclusion criterion.
2. **Threat review (10 min):** list three sources of sensitive context and identify one Copilot surface where exclusion coverage needs verification.
3. **Measure (12 min):** distinguish usage, quality and safety signals; label the source and denominator for each. Inspect the empty CSV and Ruby summarizer; do not fabricate a report.
4. **Decision (10 min):** complete a *hypothetical* pause/expand decision using the worked case in the workbook, clearly labeling it hypothetical.
5. **Transfer (8 min):** describe your 2-minute pilot recommendation to a Rails engineering lead and security stakeholder.

The [workbook with answers](#references) contains a prediction exercise, a misleading-metric challenge, a safety scenario and sample interview wording.

## References and supporting material {:#references}

- [Download cumulative companion repository and Part 05 materials](/assets/downloads/measurable-copilot-rails-pilot-support.zip). Start at `README.md` → `parts/05-adoption-and-governance/README.md` → `docs/posts/05-adoption-and-governance/article.md`.
- Companion paths: `parts/05-adoption-and-governance/PILOT-CHARTER.md`, `pilot-observations.csv`, `DECISION-RECORD.md`, `scripts/summarize_pilot.rb`, `docs/labs/05-pilot-workbook.md`, `docs/diagrams/05-pilot-decision.mmd`, `docs/posts/05-adoption-and-governance/post-manifest.md`.
- Prior chapters inside the same companion: `docs/posts/01-first-30-minutes/article.md`, `docs/posts/03-issue-to-pr/article.md`, `docs/posts/04-ci-and-devsecops/article.md`.
- [GitHub Docs: measuring trial success](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success); [usage metrics](https://docs.github.com/en/copilot/reference/copilot-usage-metrics); [interpretation](https://docs.github.com/en/copilot/reference/copilot-usage-metrics/interpret-copilot-metrics); [REST usage metrics](https://docs.github.com/rest/copilot/copilot-usage-metrics).
- [GitHub Docs: content exclusion and its limitations](https://docs.github.com/en/copilot/concepts/security-governance-and-network-settings/content-exclusion); [organization policy settings](https://docs.github.com/en/copilot/how-tos/administer-copilot/manage-for-organization/manage-policies); [cloud agent overview](https://docs.github.com/en/copilot/concepts/agents/cloud-agent/about-cloud-agent).

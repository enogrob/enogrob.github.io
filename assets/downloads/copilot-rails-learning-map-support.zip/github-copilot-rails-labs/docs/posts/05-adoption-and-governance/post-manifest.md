# Post 05 · Production manifest

## Contents

- [Teaching goal and sources](#brief)
- [Visual script](#visual)
- [Verification and limits](#checks)
- [References](#references)

## Teaching goal and sources {:#brief}

Turn Parts 01–04 of the Rails/Copilot series into a responsible **hypothetical** adoption pilot. Use current primary GitHub documentation for trial measurement, usage metric definitions, organization policies and content-exclusion limitations. The pilot CSV and decision form remain empty. No role permission, real telemetry or client rollout was tested.

## Visual script {:#visual}

| Asset | Reader question | Approved series reference and accuracy boundary |
|---|---|---|
| [Cover](assets/cover.webp) / [source PNG](assets/cover-source.png) | How do a cohort, baseline, Rails work, human review and privacy constraints become one bounded pilot? | Staged infographic: Rails cohort → baseline → CaseFlow work → separate usage, quality and safety lanes → expand / revise / pause decision, watched by a digital Copilot-inspired figure in profile. Bright white canvas and flowing Holoflux frame the explanation. No measurements or successful outcomes are depicted. |
| [Usage and quality illustration](assets/usage-is-not-impact.webp) / [source PNG](assets/usage-is-not-impact-source.png) | Why can tool activity not alone establish engineering impact? | Vertical infographic of three distinct lanes (reach among eligible people; rework and defects; safety incidents) converging on a baseline comparison shown as a question, not a result. Placed beside the metric table. No fabricated measurements, pass marks or dashboard screenshot. |
| [Decision Mermaid](../../diagrams/05-pilot-decision.mmd) | Which observations flow into expand, revise and stop decisions? | Pastel semantic classes, subgraphs and identical `.mmd` diagram body in portable companion article. A *proposed* decision loop, not a measured outcome. |

Primary typography and visual explanation reference: [Inside GitHub Copilot’s Agentic Engine](https://enogrob.github.io/artificial-intelligence/software-engineering/agentic-ai/github-copilot/2026/09/23/inside-github-copilot-agentic-engine.html). Keep the series eyebrow, dominant two-line title and smaller subtitle at comparable scales in every cover; vary subject, perspective and diagram composition. Reference covers: [Part 03](../03-issue-to-pr/assets/cover.webp), [Part 04](../04-ci-and-devsecops/assets/cover.webp), [Part 01](../01-first-30-minutes/assets/cover.webp) and [Bohm Holoflux visual anchor](https://enogrob.github.io/artificial-intelligence/architecture/agentic-ai/philosophy/2026/09/22/intelligence-in-motion-bohm-holoflux-ai-agents.html). Factual objects occupy center, identity mesh/streams surround, symbolic character stays in profile and varies gesture. Visual review: compare the final exports at desktop and mobile widths and confirm all labels are legible before publication. Blog rendering and user review remain pending.

## Verification and limits {:#checks}

- Jekyll post and companion article identical except for the Mermaid opening fence and image paths (`mermaid!` in Jekyll, `mermaid` in companion Markdown); cover followed immediately by brief shout-out; Mermaid block equals `.mmd`; both WebP files 1600×900; support links reviewed.
- Ruby summarizer source reviewed and CSV deliberately header-only. Ruby, Jekyll and client GitHub APIs were not run in authoring environment. No pilot result, productivity claim or enterprise configuration is asserted.
- Companion remains cumulative, with blank reusable charter, workbook, decision sheet, diagram and Ruby source.

## References {:#references}

- [Article](article.md), [workbook](../../labs/05-pilot-workbook.md), [pilot charter](../../../parts/05-adoption-and-governance/PILOT-CHARTER.md)
- [GitHub trial guide](https://docs.github.com/en/copilot/tutorials/roll-out-at-scale/measure-success), [usage metrics](https://docs.github.com/en/copilot/reference/copilot-usage-metrics), [content exclusion limitations](https://docs.github.com/en/copilot/concepts/security-governance-and-network-settings/content-exclusion)

# Post 04 · Production manifest

## Contents

- [Purpose and scope](#purpose)
- [Visual script](#visual)
- [Evidence and release checks](#checks)
- [References](#references)

## Purpose and scope {:#purpose}

**Series:** GitHub Copilot for Rails Engineers, Part 04. **Reader:** Rails engineer moving from the Part 03 agent patch toward an accountable PR review. **Target:** source-backed GitHub Actions example, lockfile prerequisite, layered checks and a human policy decision. The optional Part 03 patch is separate from the intact integrated CaseFlow app. Neither CI nor RSpec has run in this authoring environment.

## Visual script {:#visual}

| Asset | Teaches | Visual continuity and limits |
|---|---|---|
| [Cover](assets/cover.webp) / [PNG master](assets/cover-source.png) | A recurring mask-like digitized Copilot-inspired investigator examines a tangible proposed rails-pr.yml sheet, Rails diff, RSpec draft marked pending and unresolved policy note; the Holoflux connects these evidence objects | Exact series eyebrow and Part 04, distinct from Part 03's patch dossier; editorial desk is not a GitHub UI or actual result |
| [Failure illustration](assets/read-the-failure.webp) / [PNG master](assets/read-the-failure-source.png) | Real Gemfile and request-spec manuscripts surround the missing Gemfile.lock slot; fluid Holoflux links possible setup blockage to unrun specs and a human policy question | Illustration states NOT RUN and has no checkmark or observed failure; no repeated metal assembly or actor portrait |
| [Mermaid source](../../diagrams/04-ci-evidence.mmd) | Proposed change → setup branch → result or blocker → human review | Semantic pastel classes; diagram body matches editable source (`mermaid` companion; `mermaid!` Jekyll) |

Reference covers: [Part 01](../01-first-30-minutes/assets/cover.webp), [Part 02](../02-context-and-instructions/assets/cover.webp), [Part 03](../03-issue-to-pr/assets/cover.webp), [Bohm/Holoflux anchor](https://enogrob.github.io/artificial-intelligence/architecture/agentic-ai/philosophy/2026/09/22/intelligence-in-motion-bohm-holoflux-ai-agents.html). Bright white canvas, green network, contextual Holoflux, ruby red for Rails; concrete scenes are chapter-specific. Provisional authoring audit, 1–5: historical fit 4; canonical background 4; motion/depth 4; content fit 4; cross-image continuity 4; thumbnail 4; semantic color 4; text accuracy 4. Human desktop/mobile preview pending.

## Evidence and release checks {:#checks}

- Article identical except for the Mermaid opening fence and image paths (`mermaid!` in Jekyll, `mermaid` in companion Markdown) to Jekyll source; immediately after cover, a brief post-specific shout-out; all exact code remains selectable Markdown.
- Diagram body matches `.mmd` (`mermaid` companion; `mermaid!` Jekyll); direct support links and image paths verified statically; both exports 1600×900.
- `rails-pr.yml` is **staged**, not an active GitHub workflow. No `Gemfile.lock`, captured RSpec run, CodeQL configuration, Brakeman installation or GitHub PR exists in the baseline. Require an actual lockfile/run and product security decision before a publishable claim of CI success.
- Ruby/Jekyll runtime and manual web preview unavailable here; user validation before website publication.

## References {:#references}

- [Article](article.md); [workbook and answers](../../labs/04-ci-and-devsecops-workbook.md); [part instructions](../../../parts/04-ci-and-devsecops/README.md)
- [GitHub Ruby Actions guide](https://docs.github.com/en/actions/tutorials/build-and-test-code/ruby)

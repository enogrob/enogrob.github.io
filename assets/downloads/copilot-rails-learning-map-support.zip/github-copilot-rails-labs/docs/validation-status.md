# Validation status

As of 2026-09-26:

- Overlay files were copied from the source-reviewed CaseFlow chapter 1 starter.
- Source inspection confirms route actions, controller strong parameters, model validations, schema default and request specs for creation, validation, list and show.
- `caseflow/` is an assembled integrated Rails API source application with a Gemfile; it has no resolved Gemfile.lock or observed runtime result.
- Roberto reported `NameError: uninitialized constant ApplicationRecord` while running the integrated app on his machine. The missing `app/models/application_record.rb` has been added; a successful rerun has **not** yet been observed.
- Ruby/Rails/SQLite, database migration, HTTP behavior, focused RSpec and GitHub Actions have **not** been executed in the authoring environment.
- The previous example CI workflow is intentionally excluded until the integrated app dependency versions are tested and its credentials reviewed.
- Part 04 adds a staged workflow under `parts/04-ci-and-devsecops/`, not `.github/workflows/`. It requires a reviewed `caseflow/Gemfile.lock` before activation. No Part 04 CI, RSpec or security scan has been run here; its sample failure illustration is conceptual.
- Part 05 adds a hypothetical adoption pilot with a blank aggregate CSV and Ruby summarizer. Neither the script nor any GitHub Copilot metrics API was run here. No adoption or quality outcomes are reported.
- Part 06 adds a hypothetical client workshop with a blank decision record, agenda, claim ledger and evidence-gated roadmap. No meeting was held, client approval obtained, or new runtime checks performed in authoring.
- Part 07 adds a proposed Copilot CLI exercise with an unexecuted Ruby source preflight, two-stage prompt and blank evidence ledger. No CLI session, tool approval, local test or PR review was observed during authoring.
- Part 08 adds a final workflow blueprint, intentionally incomplete local evidence JSON and a Ruby structural validator. No skill/hook/MCP configuration is installed, and Ruby, CLI or Jekyll execution was not observed during authoring.

When running locally, put version numbers, commands, exit codes and synthetic output in a local `ENVIRONMENT.md`. Keep that file and any credentials outside the public repository. Replace this status only with a verifiable run record.

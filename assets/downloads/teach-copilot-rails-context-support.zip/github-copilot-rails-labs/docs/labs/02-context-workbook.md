# Study workbook 02 · Scope the context, audit the answer

*Read → predict → configure → compare → challenge → teach back.* About 50 minutes plus optional local Rails setup. Use the [full article](../posts/02-context-and-instructions/article.md) and the [integrated CaseFlow app](../../caseflow/README.md). Work through the questions before opening [the answers](#answer-key).

## Contents

- [Learning outcome](#learning-outcome)
- [Theory: instructions are context, not execution](#theory)
- [Context boundary diagram](#diagram)
- [Exercises](#exercises)
- [Answer key](#answer-key)
- [Retention and next step](#retention)
- [References](#references)

## Learning outcome

Decide which guidance belongs at repository, path and task scope; configure those files in a Rails workspace; assess a Copilot proposal through source citations and unresolved risks. The lab does not implement a status transition.

## Theory: instructions are context, not execution {:#theory}

| Layer | Use it for | Example in CaseFlow | Proof it can supply |
|---|---|---|---|
| Repository instruction | Stable app facts and evidence habit | API-only; cite source; report actual test run | A declared preference, not runtime behavior |
| Path instruction | Rules for model edits | Validation is distinct from DB constraint | Applicable guidance when model path matches and feature supports it |
| Task prompt | One deliverable | Table, minimal change surface, unknowns | An auditable response format |
| Rails source/spec | Current contracts and assertions | `only: %i[index show create]` | Declarations and expectations, not passing runs |
| Actual run | Observed result in one environment | Captured RSpec exit status | A bounded observation |

Custom instruction support varies by feature. Open `caseflow/` as your workspace, because instructions under `caseflow/.github/` must be at the Rails repository root for this example. A well-written Copilot answer does not prove which instruction file was loaded; inspect the session, file references and resulting citations.

## Context boundary diagram {:#diagram}

See the reviewed [editable Mermaid source](../diagrams/02-context-boundary.mmd) and the embedded [diagram in the article](../posts/02-context-and-instructions/article.md). Repository rules and one task prompt lead to a **proposal**; they do not cross the observation boundary on their own.

## Exercises

### 1 · Classification (5 minutes)

Put each instruction in repository, model path, task prompt or **not an instruction**: (a) “Keep tests executable as RSpec”; (b) “Before changing `ServiceRequest`, inspect its migration”; (c) “For this investigation output four evidence rows”; (d) “All tests passed.” Explain why (d) is a trap.

### 2 · Source-grounded counterexample (7 minutes)

A response says: “Since `STATUSES` includes `resolved`, the API already supports PATCH `/api/requests/1`.” Find two files that refute the inference. Is it still possible for an internal Ruby call to change status? Which question would that *not* answer?

### 3 · Separate validation from schema (6 minutes)

Identify the title rules declared by the model and migration. Which rule is a database constraint? Does a successful model validation prove that the production DB was migrated?

### 4 · Path scope experiment (8 minutes)

Open `caseflow/` in VS Code, ask Copilot to inspect `app/models/service_request.rb` with the [packaged audit prompt](../../caseflow/.github/prompts/02-context-audit.prompt.md), and save its claims in a table. Check whether it cites both `caseflow/.github/copilot-instructions.md` and `caseflow/.github/instructions/models.instructions.md`. Record whether loading is observed, inferred or unknown. Repeat with the controller as the only explicit file context; compare which guidance applies, keeping in mind feature-dependent support. Do not edit files.

### 5 · Adversarial answer review (8 minutes)

Review: “The model has status `resolved`; therefore we should add `PATCH` with `status` mass-assigned. We already have authorization in `ApplicationPolicy`. The specs pass, so rollout is safe.” Mark at least four unsupported steps. Write a better two-sentence client update.

### 6 · Minimal next issue (10 minutes)

Write an issue for Part 03 with: business decision about who may resolve, proposed route/action boundary, allowed transition, positive and negative specs, and a rule to record actual command outputs. Label all proposed behavior as proposed. Keep database migration changes out unless a sourced need appears.

### 7 · Explain it to a teammate (5 minutes)

In 60 seconds, explain why adding `AGENTS.md` or a skill does not replace the three files used here. Where would a reusable workflow for Mermaid architecture diagrams live in the companion repository?

## Answer key

1. (a) repository; (b) model path; (c) task prompt; (d) not an instruction or observation: without a captured run it is false or unsupported. The [files](../../caseflow/.github/) show the intended placement.
2. [`config/routes.rb`](../../caseflow/config/routes.rb) lacks update, and [`requests_controller.rb`](../../caseflow/app/controllers/api/requests_controller.rb) has no update action. An internal Ruby write might be possible if code invokes it, but that does not establish an external route, policy or accepted transition.
3. [`service_request.rb`](../../caseflow/app/models/service_request.rb) validates title presence and length ≤160. The [migration](../../caseflow/db/migrate/20260925000000_create_service_requests.rb) declares `title` non-null, not a database-level 160-character constraint. Validation does not prove the migration executed.
4. The repository instruction applies to the workspace in supported workflows; the path instruction is scoped by `applyTo: "app/models/**/*.rb"`. Inspect the actual session, feature and file scope. If the run is unavailable, record “not observed” rather than fabricating comparison results.
5. Status membership is not a route; mass assignment and authorization need design; no `ApplicationPolicy` exists in this packaged app; no passing run has been recorded. Better update: “The code permits a stored `resolved` value but provides no public update action. Before implementation, we need an authorization decision and testable allowed/denied transition rules.”
6. One reasonable proposed issue: decide who can resolve; add a narrowly scoped `PATCH /api/requests/:id` action *after approval of semantics*; reject unauthorized or invalid transitions and cover allowed/denied examples; capture RSpec results in the implementation PR. Route and authorization are proposals, not current facts.
7. `AGENTS.md` is another agent guidance mechanism with feature-specific support; a skill encodes a reusable on-demand workflow, while repo/path instructions are scoped standing guidance and a prompt is a one-time task. The reusable Mermaid workflow already exists at [`.github/skills/mermaid-architecture/SKILL.md`](../../.github/skills/mermaid-architecture/SKILL.md). None substitutes for code review or tests.

## Retention and next step {:#retention}

Tomorrow, answer from memory: which file tells Copilot “cite source,” and which file tells the Rails application “this title is required”? Then prepare the Part 03 issue with evidence. Re-run any claims about actual behavior on your own Mac.

## References

- [Complete Part 02 article](../posts/02-context-and-instructions/article.md)
- [GitHub Docs: instruction support matrix](https://docs.github.com/en/copilot/reference/custom-instructions-support)
- [GitHub Docs: repository instructions in IDE](https://docs.github.com/en/copilot/how-tos/configure-custom-instructions-in-your-ide/add-repository-instructions-in-your-ide)
- [Rails Guides: Active Record Validations](https://guides.rubyonrails.org/active_record_validations.html)

# Study workbook 01 · The first 30 minutes in a Rails repository

*Read → predict → trace → challenge → run → teach back.* Estimated time: 60–90 minutes, plus local Rails setup. This companion to [the complete post](../posts/01-first-30-minutes/article.md) uses the [integrated CaseFlow source app](../../caseflow/README.md). Write your answers before opening [the answer key](#answer-key).

## Contents

- [Learning outcomes](#learning-outcomes)
- [The mental model](#the-mental-model)
- [Exercises](#exercises)
- [Answer key](#answer-key)
- [Retention and next step](#retention-and-next-step)
- [References](#references)

## Learning outcomes

By the end, you can generate a source inventory, build and audit a small architecture atlas (capabilities, request path, change impact, evidence), separate source assertions from observations, and describe one testable next step to a customer.

## The mental model

Start with an **evidence ladder**: a guess suggests where to look; source shows what the code says; a test describes expected behavior; a test *run* gives an observation in a specific environment. Keep a failing setup or missing dependency visible as a blocker. A citation to a file establishes where a claim came from, not that the behavior worked at runtime.

| Layer | Look for | What it does *not* prove |
|---|---|---|
| Route | HTTP verb and mapped controller action | Authorization or successful persistence |
| Controller | Parameter filtering, save branch, response shape | Database schema by itself |
| Model | Application validations and allowed status values | Presence of a transition endpoint |
| Migration | Table fields, defaults and index | That migration ran in your database |
| Request spec | Expected status and body | That the spec passed on your machine |

```mermaid
flowchart TB
    subgraph read["🔍 Source inspection"]
        R["🧭 Route"] --> C["⚙️ Controller"] --> M["🧱 Model and schema"]
    end
    subgraph check["🧪 Evidence check"]
        M --> S["📋 Spec assertion"] --> X["❔ Run or blocker"]
    end
    X --> L["📝 Claim with confidence"]
    classDef source fill:#D9EAF7,stroke:#7AA6C2,color:#3E342C;
    classDef process fill:#F8DFC4,stroke:#C9986D,color:#3E342C;
    classDef unknown fill:#FFF1BF,stroke:#BA9C43,color:#3E342C;
    classDef result fill:#DCEFD6,stroke:#86A878,color:#3E342C;
    class R,C,M source;
    class S process;
    class X unknown;
    class L result;
```

**Pause and say it aloud:** “I know the controller calls `save`; I do not yet know whether it succeeds in my environment.” That distinction is the core skill practiced here.

## Exercises

### 1 · Prediction before reading (5 minutes)

Without opening the code, predict the route, the accepted JSON fields, the status of a new record, and the response to a missing title. Mark all four as **hypotheses** in a local `ENVIRONMENT.md`. After reading, circle predictions contradicted by source. The aim is to surface assumptions, not to score a guess.

### 2 · Trace the path (12 minutes)

Inspect [routes](../../caseflow/config/routes.rb), [controller](../../caseflow/app/controllers/api/requests_controller.rb), [model](../../caseflow/app/models/service_request.rb), [migration](../../caseflow/db/migrate/20260925000000_create_service_requests.rb) and [spec](../../caseflow/spec/requests/api/requests_spec.rb). Fill in the blanks and cite the *file* beside each answer:

1. `POST /api/requests` resolves to `Api::RequestsController#_____`.
2. Strong parameters permit `_____` and `_____`; the client cannot set `_____` through this action.
3. The new record starts with status `_____` according to the schema, assuming the migration has run.
4. The response on successful save uses HTTP `_____` and includes fields selected by `_____`.
5. A blank or absent title violates `_____`; the unsuccessful save branch responds with HTTP `_____`.

Sketch the route → controller → model/database → response path on paper. Add a branch for failed validation. Which parts are inferred from source, and which have you observed executing?

### 3 · Catch an overconfident assistant (8 minutes)

Here is a fictional Copilot summary. Classify each sentence as **supported by source**, **contradicted by source**, or **unverified without a run**. Correct every unsupported statement with a file citation or an explicit unknown.

> “CaseFlow accepts title, description and status when creating a request. Its update endpoint moves a request to `resolved`. A dedicated serializer emits the JSON response. All request specs pass, so a missing title is rejected in production.”

Then run [the artifact-producing prompt](../../prompts/01-trace-request.md) in your own Copilot setup. Compare its evidence table and Mermaid draft with [the reviewed request map](../../parts/01-first-30-minutes/request-map.md); mark invented files, unsupported edges and fictional command results. See [the workspace mapping guide](../../parts/01-first-30-minutes/copilot-workspace.md).

### 4 · Match claim to evidence (8 minutes)

For each claim, choose the **minimum evidence** that would support it: **A** = source inspection; **B** = existing spec assertion; **C** = actual local execution/output; **D** = current material cannot establish it. More than one letter may be needed.

| Claim | Your letter(s) |
|---|---|
| The controller permits `description`. | |
| A request spec expects HTTP 201 for a valid create. | |
| The request spec passed on this Mac. | |
| Any user may update status via an API route in this app. | |
| A migration declares a default of `open`. | |

### 5 · A narrow customer conversation (10 minutes)

A stakeholder says: “Great, we can already change status to `resolved` through the API. Please demo it.” Write a **three sentence** response: (1) what the source establishes, (2) what remains to verify, and (3) the smallest proposed next task. Include one acceptance test idea. Avoid presenting a hypothetical endpoint as existing functionality.

### 6 · Build the architecture atlas (12 minutes)

Run `ruby scripts/build_caseflow_inventory.rb` from the companion repository root, then ask Copilot to build the four views in [the atlas prompt](../../prompts/01-trace-request.md). Before reading the reference [atlas](../architecture/README.md), draft: (a) two visible capabilities and one absent one; (b) the source-backed path for `POST /api/requests`; (c) two files a future status transition may affect; (d) one question source inspection cannot answer. Circle each invented edge in Copilot's Mermaid draft and correct it against actual files. The inventory extracts declarations and does not prove runtime behavior.

### 7 · Hands on, with honest evidence (20–45 minutes)

Use the [integrated app setup instructions](../../caseflow/README.md) to install dependencies for the integrated Rails API app on your Mac and run the focused request spec. In your local `ENVIRONMENT.md`, record Ruby/Rails versions, exact commands and either actual output or the **first blocker**. Do not fabricate a green run. If setup is blocked, write what you could establish by source inspection and which runtime claim remains unknown. Finally, explain whether a passing request spec would prove production behavior.

## Answer key

**1 · Prediction.** There is no single correct prediction *before* reading. After inspection: route `POST /api/requests`; permitted `title` and `description`; migration declares default `open`; missing title causes `save` to fail under model validation and the controller's failure branch returns unprocessable entity, assuming a compatible migrated runtime. The included spec expects these outcomes, but no run is supplied. A prediction should never be rewritten as an observation.

**2 · Trace.** (1) `create`, per `config/routes.rb`. (2) `title`, `description`, and excluded `status`, per `app/controllers/api/requests_controller.rb`. (3) `open`, per the migration; schema declarations need a migrated database. (4) `201 Created`; the controller's `serialize` method selects `id`, `title`, `description`, `status`, `created_at`, `updated_at`. (5) `title` presence validation in `app/models/service_request.rb`; `422 Unprocessable Entity` from the controller's failed-save branch. The controller uses a local method named `serialize`; the app has no dedicated serializer file. These are source-backed descriptions, not observed execution.

**3 · Catch the assistant.** Permitted `title` and `description` are supported; acceptance of `status` is contradicted by `request_params` in the controller. An update endpoint is contradicted by `resources :requests, only: %i[index show create]` in routes, and the controller has no `update`; allowed model status values do not create an endpoint. A dedicated serializer is contradicted by the controller-local `serialize` method. The presence of spec *assertions* is supported by `spec/requests/api/requests_spec.rb`; “all pass” is unverified until the suite is run. “In production” cannot be inferred from a local spec. Corrected summary: “Source shows create permits title and description, with model title validation and a local response formatter; the included specs expect successful create and rejection of missing title, but runtime outcomes remain unverified here.”

**4 · Evidence.** Controller permits description: **A**. Spec expects 201: **B** (read the assertion). Spec passed on this Mac: **C**, with command and output; until then it is unknown. Any user may update status via an API route: **D** as a positive claim, and **A** contradicts an update route in the supplied app; authorization for a hypothetical future route is also unknown. Migration declares `open`: **A**. A migration file does not establish that the target database was migrated.

**5 · Example response.** “The supplied route and controller currently expose create, index and show; I cannot point to a status update action. I would check the running deployment and its authorization rules before promising a demo. The next bounded task is to design a permitted status transition with authorization and a request spec that verifies an allowed transition and rejects an unauthorized one.” Adapt to the customer's actual policy; the supplied app defines none.

**6 · Atlas.** The current routes declare `index`, `show`, `create`; a status transition is absent from the API surface. The create path runs through the controller's permitted fields and save branch, subject to model validations; the migration declares the default but is not a per-request call. A future transition would touch route/controller and require authorization and request specs; depending on design, the model/data contract may change. Job and external effects cannot be inferred from the supplied files. The [reviewed atlas](../architecture/README.md) and [declaration inventory](../architecture/generated-inventory.md) show the source citations. A generated Mermaid edge without a supporting file is a hypothesis, not an architecture fact.

**7 · Execution.** Answers depend on your machine. A good record contains exact command, exit status and relevant output or first blocker. A passing local spec supports the behavior in *that* configured environment; it does not establish deployment, production configuration or authorization. The workbook supplies no fabricated output.

## Retention and next step

After a short break, close the files and reconstruct the five-file path in **two minutes** from memory. Reopen source to correct omissions. Tomorrow, explain to a colleague how a model enum-like validation differs from an API transition. Keep the corrected explanation and your evidence log; use them to start the next post or an interview story about safe onboarding.

## References

- [Complete post and its source references](../posts/01-first-30-minutes/article.md)
- [Architecture atlas and generated inventory](../architecture/README.md)
- [Lab 01 field checklist](01-codebase-diagnosis.md)
- [Integrated CaseFlow app and setup](../../caseflow/README.md)
- [Rails Guides: Routing](https://guides.rubyonrails.org/routing.html)
- [Rails Guides: Active Record Validations](https://guides.rubyonrails.org/active_record_validations.html)
- [GitHub Docs: Explore a codebase with Copilot](https://docs.github.com/en/copilot/tutorials/explore-a-codebase)

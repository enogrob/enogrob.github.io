# Post production workflow

The Factory Ebook's production discipline carries over to the blog format: decide the learning outcome and validate exact content before illustrating it. One post is one reviewable release unit.

| Gate | Canonical artifact | Acceptance check |
|---|---|---|
| 1. Discovery | Post brief: audience, engineering question, role competency, lab outcome, source links | A single practical promise with explicit unknowns |
| 2. Technical source | Rails code, commands, prompt, `.mmd` diagram, lab Markdown | Paths exist; examples and claims cite inspected source; runtime results are labeled accurately |
| 3. Editorial draft | Complete Jekyll Markdown article | English explanation, runnable exercise, expected evidence, client takeaway, references |
| 4. Visual script | For each visual: section, learning purpose, source facts, labels, alt text, visual treatment | Every visual teaches a point from the approved draft; no invented metrics or code inside art |
| 5. Visual production | Cover, contextual WebP assets, Mermaid source and rendered preview | Factory Blog typography/background; diagrams match source; layouts vary by topic |
| 6. Integration and QA | Jekyll post with front matter and linked lab files | Build and links checked; code readable; Mermaid and images inspected on desktop and mobile |
| 7. Release | Versioned post and companion paths | Public publication only after approval; private interview card remains outside the public repository |

If source, exercise or wording changes after illustration, revisit affected diagrams and assets before release. Archive the approved brief, draft, visual script and QA notes alongside the post so a later post can reuse the process without repeating its composition.

The blog article's Markdown is the canonical text. Images teach visually; source files and lab instructions remain independently editable, selectable and testable. The workflow preserves the Factory Ebook's staged review while fitting a web publication.

## Deliverable parity with the ebook

| Format | Main publication | Matching support package |
|---|---|---|
| Factory Ebook | Illustrated paginated book | Chapter Markdown/source, runnable code and commands, diagram sources, exercises and answers, references and validation record |
| Factory Blog | Jekyll post with cover, section visuals and native diagrams | Post brief and article Markdown, runnable lab code and commands, diagram sources, prompts, exercise and evidence template, references and validation record |

For the blog, use the post number as the common identifier for the article, lab, prompt and diagrams; link exact paths from the published post. A support file must correspond to material actually taught in that post. Keep interview rehearsal cards separate and private. A blog post is complete only when both its public article and matching support package pass review. The ebook retains its own independent support package; converting a chapter into a post does not silently reuse unverified exercises or assets.

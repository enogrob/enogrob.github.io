# Post 02 production manifest

## Contents

- [Brief](#brief)
- [Assets and visual script](#assets)
- [Validation record](#validation)
- [References](#references)

## Brief {:#brief}

**Reader:** Rails engineer using VS Code on a Mac, preparing for a consultative Copilot role. **Question:** how do we supply narrow, reviewable context before proposing a status transition? **Outcome:** source-cited proposal, not implementation. **Unknowns:** instruction applicability by Copilot surface, authorization requirements and actual test results.

## Assets and visual script {:#assets}

| Asset | Learning purpose | Source / editability |
|---|---|---|
| [`cover.webp`](assets/cover.webp) | Part 02 series eyebrow repeats the Part 01 hierarchy; a digitized side-profile guide faces a conceptual editor while repo, model and task context converge toward a visible unknown | [`cover-source.png`](assets/cover-source.png), visual metaphor, no real UI claim |
| [`context-boundary.webp`](assets/context-boundary.webp) | Repository rules, model scope and task prompt converge through an amber evidence gate toward a cited proposal and an unknown, not a screenshot | [`context-boundary-source.png`](assets/context-boundary-source.png); labels are conceptual |
| [`.mmd` diagram](../../diagrams/02-context-boundary.mmd) | Exact scopes and auditable proposal topology | Editable source is byte-identical to the article's Mermaid block |

Reference covers: [Ruby rethink](https://enogrob.github.io/ruby/rails/software-history/2026/09/23/when-ruby-made-the-industry-rethink-programming.html), [Bohm Holoflux](https://enogrob.github.io/artificial-intelligence/architecture/agentic-ai/philosophy/2026/09/22/intelligence-in-motion-bohm-holoflux-ai-agents.html), [Part 01](https://enogrob.github.io/ruby/rails/software-engineering/github-copilot/2026/09/25/the-first-30-minutes-in-an-unfamiliar-rails-repository.html). These are composition references, not proof that Post 02 was rendered on the site.

## Validation record {:#validation}

- Source inspected: route actions, strong parameters, model validations, migration and request specs. **No status transition is present.**
- This package's post was checked for front matter, image existence, matching diagram, links to support material, and identical support/article Markdown.
- Art was generated in the same white/mesh/Holoflux world as the approved posts. Cover series eyebrow, title and subtitle were compared side by side with approved Part 01; internal typography and semantic labels were likewise compared; semantic image labels are illustrative, not source citations. Visual review scoring: historical fit 4, background fit 4, motion/depth 4, content fit 4, continuity 4, thumbnail clarity 4, semantic color 4, text accuracy 4 (provisional author review; user approval remains open).
- Ruby, RSpec, Jekyll build, VS Code/Copilot session, hosted rendering and a Mac test run were **not available or not performed** here. Do not record them as passed.

## References

- [Article](article.md)
- [Study workbook and answers](../../labs/02-context-workbook.md)
- [Visual contract](../../visual-standard.md)

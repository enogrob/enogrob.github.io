# Visual standard for the companion series

The **current** Factory Blog `BLOG-VISUAL-IDENTITY.yml` (schema 2, Canonical Flow), `VISUAL-STANDARDS.md`, `MERMAID-STANDARDS.md` and `JEKYLL-CONTRACT.yml` govern every public article and its supporting visuals. Never substitute an older ZIP for the live contract. Compare at least three recent relevant approved covers before generating. Record the references and rate all **eight** current approval dimensions at least 4/5 each. A visual must clarify an actual decision, flow or relationship in that article.

## Article and cover

- Write the article in English as Jekyll Markdown. Keep code, commands, URLs and technical claims as selectable text, with a language tag on every fenced code block.
- Generate a 16:9 cover master and export a 1600×900 WebP. **Render the title inside the cover** with the blog's navy condensed uppercase hierarchy and selective green/red emphasis; ensure mobile thumbnail readability. A cover represents the whole article, while section illustrations relate to their actual sections and omit the author.
- Use the recent Ruby, Bohm/Holoflux and Copilot posts as visual references: **pure bright white** canvas, navy condensed headings on covers with meaningful deep-green keyword, emerald node mesh derived from the canonical sphere as a contextual structural element, luminous multicolor wind-swept Holoflux streams in the foreground, and concrete topic cues. For Rails, ruby/crimson flow is a meaningful accent; evidence, inference and unknown may use green, violet and amber. Human figures, when needed, can digitize into the network. Do **not** impose mountains or a stock landscape on a technical subject. Vary metaphor, mesh shape/placement and framing by section while keeping the same visual world.
- The cover must synthesize the **whole article**: motivating question, distinctive subject, key transformation and outcome or unresolved boundary. Every internal visual must teach the exact section where it appears. Use the available frame to connect meaningful details and invite reading, while leaving code, numerical results and unverified behaviors out of generative artwork.
- When a cover uses a human or symbolic actor, show a **side profile** oriented toward the article's problem. Integrate the face, hair, hands and outline into the network and flow, as in the Bohm reference. For this series, a profile can personify the AI investigation without reproducing a trademarked logo or suggesting a real Copilot screenshot. A person is optional when the concept benefits more from a different focal subject.
- No Zoatworks/Factory logo, QR code, signature or author credit in internal images. Every internal generated illustration needs a short **deep-green uppercase conceptual title and 3–5 semantic labels**; longer explanations belong in a Markdown caption. Supply useful alt text. Export one illustration per WebP asset under `/assets/images/posts/<slug>/` when preparing the Jekyll post.
- Do not render executable code, small commands, metrics or long prose into an illustration. Exact examples remain in Markdown; explanatory labels may appear in a diagram if legible.

## Mermaid and other exact visuals

- Use Mermaid for topology, branches, state changes and evidence relationships. Enable `mermaid: true` in post front matter and use the Factory Blog's exact `mermaid!` fence, canonical initialization and semantic pastel classes. The plain `mermaid` fence is forbidden in Jekyll posts.
- Give diagrams short, concrete node labels with functional icons, explicit light/dark resilient backgrounds and 3–6 semantic pastel colors when appropriate. Add subgraphs for real boundaries. Keep syntax valid for the blog renderer.
- Maintain a source `.mmd` in `docs/diagrams/` and embed the same source in the article. A rendered diagram must be inspected at desktop and mobile widths; preserve readable labels and accessible explanatory prose.
- Use a Markdown table for exact comparisons or mappings, an illustrated image for conceptual intuition, and syntax-highlighted code for exact commands. A visual is optional when it adds no understanding.

## Review before publishing

1. Trace every label and arrow to checked source or clearly mark it as a proposed/expected behavior. Keep migrations as schema references rather than runtime steps.
2. Verify Jekyll front matter, local asset paths, Mermaid rendering, link targets, alt text, image readability and mobile layout.
3. Record at least three recent relevant approved cover references and the eight Factory Blog scores (historical fit, canonical background fit, foreground motion/depth, content fit, cross-image continuity, thumbnail clarity, semantic color and text accuracy; minimum 4/5 each). If references are inaccessible, mark the release gate blocked. Reject repeated layouts and misleading decoration.
4. Record which commands and tests were actually run; never depict a planned check as a passing one.

These rules apply to the planned posts and to new diagrams and support material in this repository. They are production criteria, not claims that the present starter has passed Jekyll or runtime validation.

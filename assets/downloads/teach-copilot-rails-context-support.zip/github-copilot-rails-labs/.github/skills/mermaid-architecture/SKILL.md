---
name: mermaid-architecture
description: Create and review evidence-backed Mermaid architecture, request-flow and sequence diagrams for the CaseFlow Rails blog series. Use when documenting Rails files, dependencies, database interactions, change impact, or source-based workflows in this repository.
---

# Mermaid architecture diagrams

1. **Investigate before drawing.** Inspect `caseflow/Gemfile`, `config/routes.rb`, controllers, models, migration and specs. For each edge, cite a file and distinguish source declaration, test assertion, runtime observation and hypothesis. Never draw an absent status transition, authorization layer, background job or service as though it existed.
2. **Choose the question first.** Use a flowchart for system boundaries or a request path; a sequence diagram only when order and alternate outcomes matter; a table for exact dependencies and evidence. Avoid a diagram if it merely repeats a short list.
3. **Follow Factory Blog semantics.** Use explicit `theme: base`, internal `#FFF8EF` background, `#3E342C` text, `#6F7377` connectors and `13px` font; use blue for input, orange for action, purple for orchestration/model, green for verified outcome, yellow for evidence/data, rose for risk. Use meaningful subgraphs and functional icons, not decoration. Keep at most five nodes/actors horizontally; split dense diagrams before shrinking labels.
4. **Respect the renderer.** In GitHub Markdown and this README use a plain `mermaid` fence. In the published Jekyll post use `mermaid!` with `mermaid: true` front matter. Keep reusable raw Mermaid in `.mmd`, and check that the article block matches its reviewed source. Do not assume a Jekyll diagram will preview with VS Code's ordinary Markdown renderer.
5. **Show depth progressively.** Put a compact architecture view in the README. Put a detailed sequence inside `<details><summary>…</summary>` with a blank line before and after its Mermaid block. Explain a dotted schema dependency separately from a runtime call. If validation failure occurs before a DB write, do not draw an unconditional write arrow.
6. **Validate claims and presentation.** Check exact labels against code, distinguish `Gemfile` constraints from resolved `Gemfile.lock`, verify DB adapter from `config/database.yml`, inspect the rendered preview in GitHub/VS Code, and leave unrun branches labeled as expectations. Check the [architecture atlas](../../../docs/architecture/README.md) and the [editable request diagram](../../../docs/diagrams/request-path.mmd) as examples, not as proof that the system has run.

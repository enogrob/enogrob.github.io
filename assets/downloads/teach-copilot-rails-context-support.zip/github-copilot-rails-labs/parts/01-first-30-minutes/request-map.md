# Reviewed CaseFlow request map · Part 01

## Contents

- [Evidence table](#evidence-table)
- [Diagram](#diagram)
- [References](#references)

## Evidence table

| Claim | Exact file | Classification |
|---|---|---|
| POST /api/requests maps to `create` | `caseflow/config/routes.rb` | Source |
| `request_params` permits only title and description | `caseflow/app/controllers/api/requests_controller.rb` | Source |
| Title required, status among open/in_progress/resolved | `caseflow/app/models/service_request.rb` | Source |
| Status defaults to open if schema is applied | `caseflow/db/migrate/20260925000000_create_service_requests.rb` | Schema expectation; execution unknown |
| Valid and missing-title cases are asserted | `caseflow/spec/requests/api/requests_spec.rb` | Spec assertion; result unknown |
| Status update endpoint exists | `caseflow/config/routes.rb` | Contradicted by supplied source |

## Diagram

The [editable Mermaid source](../../docs/diagrams/request-path.mmd) models the expected branches. The migration is a dotted schema dependency. Run the spec before changing an expected branch to an observation.

## References

- [Complete post](../../docs/posts/01-first-30-minutes/article.md)
- [Rails routing guide](https://guides.rubyonrails.org/routing.html)

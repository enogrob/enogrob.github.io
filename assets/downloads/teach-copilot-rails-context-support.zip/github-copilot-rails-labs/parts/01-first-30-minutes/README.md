# Part 01 · The first 30 minutes

## Contents

- [Read the post](#read-the-post)
- [Practice](#practice)
- [References](#references)

## Read the post

[Full canonical article](../../docs/posts/01-first-30-minutes/article.md) · [architecture atlas](../../docs/architecture/README.md) · [reviewed request map](request-map.md) · [Mermaid source](../../docs/diagrams/request-path.mmd). The linked article uses Jekyll site-root image URLs.

## Practice

Open [the integrated CaseFlow app](../../caseflow/README.md) as your VS Code workspace. Use [the Copilot workspace mapping guide](copilot-workspace.md). Read the [study workbook and answer key](../../docs/labs/01-study-workbook.md), try [the artifact-producing Copilot prompt](../../prompts/01-trace-request.md), and complete [the field lab](../../docs/labs/01-codebase-diagnosis.md). Source inspection has been performed; Ruby runtime is unverified.

## References

- [Article references](../../docs/posts/01-first-30-minutes/article.md)
- [VS Code workspace context](https://code.visualstudio.com/docs/agents/reference/workspace-context)

# Copilot codebase exploration · Part 01

## Contents

- [What Copilot uses](#what-copilot-uses)
- [A useful mapping exercise](#a-useful-mapping-exercise)
- [References](#references)

## What Copilot uses

VS Code's Copilot agents search workspace files and code symbols; semantic search uses an index maintained automatically. The GitHub repository can also be searched through repository-aware tools when available. This is **context retrieval**, not a permanent verified architecture model. A repository map can be written as a reviewed Markdown evidence table plus an editable Mermaid file; the generated version is a draft to check. Open only `caseflow/` as the workspace to keep the exercise scoped; opening the whole companion repository introduces duplicate article and lab text into search results.

`AGENTS.md` provides guidance, but instructions do not replace source verification. The same principle applies when comparing a Claude repository-mapping plugin: inspect what it actually indexes, how fresh the map is, and whether every edge in the diagram has a source citation. We have not validated a specific Claude plugin here.

## A useful mapping exercise

1. Run the [artifact-producing prompt](../../prompts/01-trace-request.md) in VS Code with `caseflow/` open. If it cannot find a file, attach the file explicitly. Save the response as a **draft**.
2. Compare each table row against the five source files and [the reviewed reference map](request-map.md). Mark unsupported claims.
3. Render the generated Mermaid draft in VS Code and compare its route, schema dependency and `201`/`422` branches with [the editable reference diagram](../../docs/diagrams/request-path.mmd).
4. Record three misses, corrections and whether workspace search, an explicit file, or an actual run resolved each. Do not copy a generated diagram into the article until its labels and edges are checked.

The target deliverable is the corrected table and diagram, plus an evidence log. A generic prose summary is not the output of this exercise.

## References

- [VS Code: How Copilot understands your workspace](https://code.visualstudio.com/docs/agents/reference/workspace-context)
- [VS Code: AI features and Mermaid responses](https://code.visualstudio.com/docs/agents/reference/ai-features-cheat-sheet)
- [GitHub Docs: Indexing repositories for Copilot](https://docs.github.com/en/copilot/concepts/indexing-repositories-for-copilot-chat)

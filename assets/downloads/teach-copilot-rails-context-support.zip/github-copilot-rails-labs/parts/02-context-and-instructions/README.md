# Part 02 · Teach Copilot the Rails context

This chapter prepares a **source-cited proposal** for the CaseFlow status-transition issue. It does not implement the transition. Start with the [complete article](../../docs/posts/02-context-and-instructions/article.md), then solve the [workbook](../../docs/labs/02-context-workbook.md) before reading its answers.

## Contents

- [Learning path](#learning-path)
- [Lab deliverable](#lab-deliverable)
- [References](#references)

## Learning path

1. Open `caseflow/` as the workspace root. Read [repository guidance](../../caseflow/.github/copilot-instructions.md) and [model path guidance](../../caseflow/.github/instructions/models.instructions.md).
2. Compare both against actual [routes](../../caseflow/config/routes.rb), [controller](../../caseflow/app/controllers/api/requests_controller.rb), [model](../../caseflow/app/models/service_request.rb) and [migration](../../caseflow/db/migrate/20260925000000_create_service_requests.rb).
3. Run the [audit prompt](../../caseflow/.github/prompts/02-context-audit.prompt.md) with Copilot. Verify which instruction paths it identifies and review its evidence table. The [Mermaid source](../../docs/diagrams/02-context-boundary.mmd) shows the intended context and evidence boundary.
4. Finish the [workbook and answer key](../../docs/labs/02-context-workbook.md). Record actual observations or blockers in your environment notes.

## Lab deliverable

A four-row claim table with source paths and evidence type, plus a proposed status-transition issue with explicit authorization questions and focused positive/negative tests. Do not assert that Copilot loaded a file or that RSpec passed unless you observed it.

## References

- [Full article and references](../../docs/posts/02-context-and-instructions/article.md)
- [Custom instruction support](https://docs.github.com/en/copilot/reference/custom-instructions-support)

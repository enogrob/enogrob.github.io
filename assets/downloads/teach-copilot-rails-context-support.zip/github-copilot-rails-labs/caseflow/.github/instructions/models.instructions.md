---
applyTo: "app/models/**/*.rb"
---

# CaseFlow model guidance

- For a ServiceRequest change, inspect `app/models/service_request.rb`, `db/migrate/20260925000000_create_service_requests.rb`, `app/controllers/api/requests_controller.rb`, and the request specs before proposing behavior.
- Distinguish a model validation from a database constraint. `title` presence and length are model rules; the migration also declares `title` non-null, but does not impose a 160-character database limit.
- `resolved` is an allowed status value; its presence does not imply a public update route or authorization policy.
- Propose both an accepted case and a rejected case for new behavior. Keep exact status and response expectations tied to source or a test run.

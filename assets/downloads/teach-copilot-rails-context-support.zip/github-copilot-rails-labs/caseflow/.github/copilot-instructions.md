# CaseFlow repository guidance for Copilot

- This is a small Rails 8 API teaching app. Inspect the actual route, controller, model, migration, and request specs before describing behavior; do not infer a UI, authentication, jobs, or a status transition.
- Distinguish a source declaration, an existing spec assertion, and a command you actually ran. Quote the path for every behavioral claim and state unknowns explicitly.
- Keep proposed changes within the requested scope. Before editing, identify affected files and a focused verification step. Never say tests passed without captured output.
- For Rails work, use Ruby and the existing RSpec setup. Avoid adding production dependencies or committing secrets and local SQLite files for a documentation task.
- When drawing Mermaid, use the companion repository's [architecture skill](../../.github/skills/mermaid-architecture/SKILL.md) when it applies; label inferred runtime edges as expectations.

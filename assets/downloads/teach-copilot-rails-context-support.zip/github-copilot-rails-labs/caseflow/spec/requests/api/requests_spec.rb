require 'rails_helper'

RSpec.describe 'Service requests API', type: :request do
  describe 'POST /api/requests' do
    it 'creates an open request with valid input' do
      post '/api/requests', params: { request: { title: 'Update billing address' } }, as: :json

      expect(response).to have_http_status(:created)
      expect(JSON.parse(response.body)).to include('title' => 'Update billing address', 'status' => 'open')
      expect(ServiceRequest.count).to eq(1)
    end

    it 'rejects a missing title' do
      post '/api/requests', params: { request: { description: 'Missing title' } }, as: :json

      expect(response).to have_http_status(:unprocessable_entity)
      expect(JSON.parse(response.body).fetch('errors').join(' ')).to match(/Title/i)
      expect(ServiceRequest.count).to eq(0)
    end

    it 'rejects a title longer than 160 characters' do
      post '/api/requests', params: { request: { title: 'A' * 161 } }, as: :json

      expect(response).to have_http_status(:unprocessable_entity)
      expect(JSON.parse(response.body).fetch('errors').join(' ')).to match(/Title/i)
      expect(ServiceRequest.count).to eq(0)
    end
  end

  describe 'GET /api/requests' do
    it 'lists created requests' do
      request = ServiceRequest.create!(title: 'Inspect an invoice')

      get '/api/requests', as: :json

      expect(response).to have_http_status(:ok)
      expect(JSON.parse(response.body)).to include(a_hash_including('id' => request.id, 'title' => request.title))
    end
  end

  describe 'GET /api/requests/:id' do
    it 'shows an existing request' do
      request = ServiceRequest.create!(title: 'Inspect an invoice')

      get "/api/requests/#{request.id}", as: :json

      expect(response).to have_http_status(:ok)
      expect(JSON.parse(response.body)).to include('id' => request.id, 'title' => request.title)
    end
  end
end

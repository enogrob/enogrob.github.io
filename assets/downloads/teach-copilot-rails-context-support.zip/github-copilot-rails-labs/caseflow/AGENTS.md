# CaseFlow learning rules

- Map the code before modifying it; cite paths and distinguish source, assertion and observed output.
- Use the diagrams and evidence table in `../parts/01-first-30-minutes/` as provisional maps, not as proof of execution.
- Keep one bounded change per series part. Do not implement a status update until a later exercise specifies authorization and tests.
- Use synthetic examples only and record actual commands/results or the first blocker.

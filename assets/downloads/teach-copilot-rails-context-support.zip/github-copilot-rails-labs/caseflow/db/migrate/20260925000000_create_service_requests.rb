class CreateServiceRequests < ActiveRecord::Migration[8.0]
  def change
    create_table :service_requests do |t|
      t.string :title, null: false
      t.text :description
      t.string :status, null: false, default: 'open'
      t.timestamps
    end

    add_index :service_requests, :status
  end
end

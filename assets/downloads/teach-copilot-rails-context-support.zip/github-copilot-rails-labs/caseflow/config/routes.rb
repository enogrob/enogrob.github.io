Rails.application.routes.draw do
  namespace :api do
    resources :requests, only: %i[index show create]
  end
end

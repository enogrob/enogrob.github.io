module Api
  class RequestsController < ApplicationController
    def index
      requests = ServiceRequest.order(created_at: :desc).limit(50)
      render json: requests.map { |request| serialize(request) }
    end

    def show
      request = ServiceRequest.find(params[:id])
      render json: serialize(request)
    end

    def create
      request = ServiceRequest.new(request_params)
      if request.save
        render json: serialize(request), status: :created
      else
        render json: { errors: request.errors.full_messages }, status: :unprocessable_entity
      end
    end

    private

    def request_params
      params.require(:request).permit(:title, :description)
    end

    def serialize(request)
      request.as_json(only: %i[id title description status created_at updated_at])
    end
  end
end

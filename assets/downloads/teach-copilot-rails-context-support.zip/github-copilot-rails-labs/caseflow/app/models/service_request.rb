class ServiceRequest < ApplicationRecord
  STATUSES = %w[open in_progress resolved].freeze

  validates :title, presence: true, length: { maximum: 160 }
  validates :status, inclusion: { in: STATUSES }
end

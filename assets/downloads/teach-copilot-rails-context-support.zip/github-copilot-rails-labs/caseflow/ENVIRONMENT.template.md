# CaseFlow environment evidence

Date and Mac model:

## Versions

| Command | Actual output | Path or note |
|---|---|---|
| `ruby -v` | | |
| `bundle -v` | | |
| `bin/rails -v` | | |
| `psql --version` | | |
| `git --version` | | |

## Setup log

| Command | Exit status | Relevant output/error | Next action |
|---|---:|---|---|
| `bundle install` | | | |
| `bin/rails generate rspec:install` | | | |
| `bin/rails db:create db:migrate` | | | |
| `bundle exec rspec` | | | |
| `bin/rails server` | | | |

## Prediction before running

What will `POST /api/requests` accept, store and return?

## Synthetic HTTP result

Command (remove tokens/secrets):

Observed status and JSON:

## Claim and evidence

| Claim | Cited file | Runtime command/output | Observed, inferred or unsupported |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

## Unknowns and next small issue

List what this run could not establish. Propose one acceptance criterion for the next chapter.

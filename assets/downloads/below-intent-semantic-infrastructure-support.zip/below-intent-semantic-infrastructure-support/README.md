# Below Intent — Support Material

This companion package accompanies **Below Intent: The Semantic Infrastructure of Agentic Software Engineering**.

It contains:
- the semantic-layer concepts used in the article;
- a small Ruby sketch of an engineering semantic model;
- example questions an agent could ask of a program / engineering graph;
- Mermaid source extracted from the article.

The examples are conceptual and educational. They do not claim to implement a production-grade semantic database or runtime-observability platform.

# Concept Map

## Semantic layers

- **Product intent** — requirements, evidence, outcomes, constraints.
- **Program semantics** — symbols, relationships, call paths, dependencies, contracts.
- **Runtime evidence** — traces, state, deployments, incidents, performance signals.
- **Engineering semantic graph** — relationships across intent, architecture, implementation, verification, policy, release, runtime, and feedback.

## AI mechanisms

- **RAG** retrieves knowledge.
- **MCP** exposes tools and external systems.
- **Skills** package reusable task guidance and resources.
- **Custom agents** specialize behavior.
- **Hooks / policy** add deterministic controls.
- **Program database** exposes code structure for queries.
- **Runtime observability** exposes live state and behavior.

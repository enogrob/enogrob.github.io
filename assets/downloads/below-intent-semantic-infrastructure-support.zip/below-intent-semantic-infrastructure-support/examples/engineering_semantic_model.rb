# frozen_string_literal: true

# Conceptual sketch only.
#
# The point is not the DSL syntax. The point is that the declaration can
# become both executable behavior and a queryable semantic representation.

system = EngineeringSystem.define(:caseflow) do
  requirement :sla_escalation do
    evidence :customer_interviews, :support_ticket_4312
    constrained_by :notification_policy
  end

  architecture :notifications do
    decided_by :adr_003
    implements :sla_escalation
  end

  verification :sla_request_specs do
    verifies :sla_escalation
  end

  production :caseflow_api do
    exposes :traces, :deployments, :incidents
  end
end

puts system.to_json
puts system.to_mermaid
puts system.query("what verifies sla_escalation?")

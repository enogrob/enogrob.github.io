# Example Agent Queries

A future program database or engineering semantic graph could support questions such as:

- Which public functions can eventually reach this operation?
- Which requirements are implemented by this component?
- Which ADR introduced this dependency?
- Which tests verify this policy?
- Which release first contained this behavior?
- Which incidents involved code introduced by that release?
- Which feedback items caused the requirement to change?
- Which agents can reach production-affecting tools?
- Which policy gates constrain this workflow?
- Which runtime signals provide evidence for the current hypothesis?

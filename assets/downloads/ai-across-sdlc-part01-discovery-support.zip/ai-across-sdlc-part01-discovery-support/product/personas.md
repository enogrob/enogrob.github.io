# Personas

## Operations Analyst
Works on a queue of cases, needs clarity and fewer manual follow-ups.

## Team Lead
Needs to identify blocked cases and cases that are approaching SLA breach.

## Enterprise Customer
Needs predictable handling and visibility into important cases.

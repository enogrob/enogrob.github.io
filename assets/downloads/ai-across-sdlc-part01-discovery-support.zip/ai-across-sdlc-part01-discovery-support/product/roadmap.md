# CaseFlow Roadmap

## Q3 priorities
1. Improve case visibility
2. Reduce manual follow-up
3. Improve upload and review reliability

## Candidate themes
- SLA tracking and escalation
- Better internal notifications
- Bulk triage improvements
- Better audit trail for reviews

# Discovery Report — SLA-based escalation

## Problem statement
CaseFlow users need earlier visibility when important cases are close to missing SLA commitments.

## Evidence found
- customer interviews explicitly mention late visibility
- support tickets mention missed urgent cases and manual tracking
- roadmap already mentions SLA tracking and escalation
- ADRs imply notifications must be asynchronous and escalation should be auditable

## Constraints and risks
- escalation should avoid alert fatigue
- notifications should be targeted
- escalation must be visible in history
- background delivery must remain reliable

## Key questions / unknowns
- how close to breach should escalation happen?
- which roles should receive the first escalation?
- do different case priorities need different policies?
- should repeated escalation be rate-limited?

## Candidate outcomes
- research spike
- user story for targeted SLA escalation
- operational design decision on notification policy

## Recommended next step
Create a backlog-ready spike or user story only after clarifying escalation thresholds and notification recipients.

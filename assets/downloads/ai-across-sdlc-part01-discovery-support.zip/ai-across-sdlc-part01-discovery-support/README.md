# Lab 01 — Discovery & Product Planning

## Objective
Use GitHub Copilot, repository context, and AI assets to transform scattered signals into a structured discovery report for CaseFlow.

## Suggested flow
1. Read the product and discovery sources.
2. If necessary, initialize understanding with `copilot init` or `/init`.
3. Load the discovery instructions and discovery skill.
4. Ask the discovery agent to analyze the SLA-based escalation request.
5. Produce a discovery report.
6. Verify that all major conclusions are labeled as fact, inference, or unknown.

## Expected evidence
- a discovery report
- a clear distinction between fact, inference, and unknown
- candidate next steps that are justified by evidence

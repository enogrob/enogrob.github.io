# ADR-003 — Notification delivery

Decision:
Notification delivery is asynchronous.

Consequences:
- user-facing actions should not wait for delivery
- auditability matters
- duplicate notifications should be avoided where possible

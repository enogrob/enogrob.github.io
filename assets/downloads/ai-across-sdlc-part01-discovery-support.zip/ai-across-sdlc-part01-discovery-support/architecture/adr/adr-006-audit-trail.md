# ADR-006 — Audit trail expectations

Decision:
Important case-state transitions must be visible in the product history.

Implication:
If escalation is implemented, the action should be traceable.

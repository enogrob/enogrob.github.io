# System Overview

CaseFlow is a Rails application with:
- cases
- assignments
- comments
- uploads
- notifications

Known characteristics:
- Sidekiq background jobs
- PostgreSQL
- existing notification service

# Exercises

1. Build a discovery report for SLA-based escalation.
2. Rewrite one weak conclusion so it becomes evidence-based.
3. List three unknowns that should block premature implementation.
4. Decide whether the next action should be a user story, a spike, or a follow-up interview.

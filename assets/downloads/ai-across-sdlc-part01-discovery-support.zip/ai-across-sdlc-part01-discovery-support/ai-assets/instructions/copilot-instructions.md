# Discovery instructions for CaseFlow

When analyzing product requests:

1. Prefer repository and support-material evidence over assumptions.
2. Separate:
   - observed facts,
   - inferred insights,
   - unknowns / open questions.
3. Do not create implementation plans too early.
4. Before suggesting backlog items, explain:
   - the problem,
   - the evidence,
   - the constraints,
   - the main risks,
   - what remains unknown.
5. If the repository context is unclear, suggest using `copilot init` or `/init`.

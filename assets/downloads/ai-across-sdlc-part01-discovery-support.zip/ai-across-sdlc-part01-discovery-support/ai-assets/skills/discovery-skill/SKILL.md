---
name: discovery-skill
description: Use this skill when transforming product signals into an evidence-first discovery report.
---

# Discovery Skill

## Goal
Turn scattered product signals into a structured discovery report.

## Procedure
1. Gather the most relevant sources.
2. Summarize the request in plain language.
3. Extract evidence from interviews, tickets, docs, and roadmap.
4. Distinguish facts from inference.
5. Identify unknowns, edge cases, constraints, and follow-up questions.
6. Propose candidate outcomes, but do not jump to implementation prematurely.

## Output format
- Problem statement
- Evidence found
- Constraints and risks
- Key questions
- Candidate outcomes
- Recommended next step

# Feature Request 07

Request:
Add SLA-based escalation in CaseFlow.

Initial idea:
- detect cases nearing breach
- notify responsible people
- record that escalation happened

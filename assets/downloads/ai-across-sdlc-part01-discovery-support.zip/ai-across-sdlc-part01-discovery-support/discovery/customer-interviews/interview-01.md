# Interview 01 — Enterprise operations lead

- We need faster visibility when a case is about to miss its SLA.
- Today the team notices issues too late.
- Escalation should not spam everyone.
- We need confidence that escalation rules are predictable.

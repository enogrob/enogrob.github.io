# Interview 02 — Support manager

- Analysts often use spreadsheets and manual reminders.
- It is hard to know which cases deserve immediate attention.
- Escalation should surface urgency without creating alert fatigue.

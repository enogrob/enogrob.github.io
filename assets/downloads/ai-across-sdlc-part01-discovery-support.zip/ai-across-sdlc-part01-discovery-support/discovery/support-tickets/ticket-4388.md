# Support Ticket 4388

Title: Team wants targeted escalation instead of broad broadcast

Summary:
Escalation should reach the assigned analyst and team lead first, rather than a large shared channel.

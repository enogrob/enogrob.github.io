# Support Ticket 4312

Title: Missed urgent case because no early warning existed

Summary:
A customer reported that a high-priority case was reviewed late because no early signal highlighted the approaching SLA limit.

Observed pain:
- queue too large
- no proactive escalation
- manual tracking outside the product

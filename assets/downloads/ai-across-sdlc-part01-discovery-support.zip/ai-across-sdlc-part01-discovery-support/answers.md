# Suggested answers

1. The sample discovery report shows one acceptable structure.
2. Weak conclusion example:
   - weak: "users need notifications"
   - stronger: "interviews and ticket 4312 suggest users need earlier targeted visibility for cases nearing SLA breach"
3. Good unknowns:
   - threshold timing
   - recipients
   - rate-limiting / duplicate prevention
4. Recommended next action:
   a spike or refined story, depending on how much policy clarification is still missing.

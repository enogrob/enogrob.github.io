# frozen_string_literal: true

require "json"

module Holoflux
  Concept = Data.define(:name, :metadata)
  Relation = Data.define(:source, :verb, :target, :metadata)

  class Domain
    attr_reader :name, :concepts, :relations

    def initialize(name)
      @name = name
      @concepts = {}
      @relations = []
    end

    def concept(name, **metadata)
      key = name.to_sym
      raise ArgumentError, "duplicate concept: #{key}" if concepts.key?(key)

      concepts[key] = Concept.new(key, metadata)
    end

    def relation(source, verb, target, **metadata)
      source = source.to_sym
      target = target.to_sym

      [source, target].each do |key|
        raise ArgumentError, "unknown concept: #{key}" unless concepts.key?(key)
      end

      relations << Relation.new(source, verb.to_sym, target, metadata)
    end

    def to_h
      {
        name:,
        concepts: concepts.values.map { |c| { name: c.name, **c.metadata } },
        relations: relations.map do |r|
          { source: r.source, verb: r.verb, target: r.target, **r.metadata }
        end
      }
    end
  end

  def self.domain(name, &block)
    model = Domain.new(name.to_sym)
    model.instance_eval(&block)
    model
  end
end

domain = Holoflux.domain(:krishnamurti) do
  concept :what_is, kind: :fact
  concept :thought, kind: :movement
  concept :observer, kind: :constructed_center
  concept :attention, kind: :field
  concept :silence, kind: :field
  concept :whole, kind: :field

  relation :thought, :creates, :observer, status: :candidate
  relation :attention, :reveals, :what_is, status: :candidate
  relation :silence, :opens_to, :whole, status: :candidate
end

puts JSON.pretty_generate(domain.to_h)

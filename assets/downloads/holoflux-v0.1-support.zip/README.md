# Holoflux v0.1 — support material

This folder accompanies the blog post **Holoflux: A Semantic and Visual Language for Expressing the Whole in Motion**.

## Included

- `examples/holoflux.rb` — executable Ruby sketch of a tiny domain DSL.
- `mermaid/01-holoflux-architecture.mmd` — core architecture.
- `mermaid/02-domain-authoring-loop.mmd` — AI + human authoring loop.
- `mermaid/03-krishnamurti-domain.mmd` — first reference-domain map.
- `mermaid/04-holoflux-across-domains.mmd` — common semantic layer across domains.
- `mermaid/05-intent-and-holoflux.mmd` — relationship between intent-oriented interaction and Holoflux.
- `mermaid/06-holoflux-explication-loop.mmd` — model → explication → artifact → insight → revision.
- `mermaid/07-explicate-form-example.mmd` — one semantic source unfolded as a compact Mermaid artifact.

The diagrams use compact 13 px typography and subgraphs to stay readable in the Blog Factory column while avoiding oversized graphs.
- `mermaid/08-holoflux-system.mmd` — responsibility map: IOP, Holoflux, explication, runtime, artifact, evidence.
- `mermaid/09-provenance-trace.mmd` — source → reviewed relation → explication → artifact traceability.
- `mermaid/10-iop-holoflux-explication.mmd` — IOP as intention, Holoflux as meaning, explication as manifestation.

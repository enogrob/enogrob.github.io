#!/usr/bin/env ruby
# frozen_string_literal: true

require "pathname"

root = File.expand_path("..", __dir__)
articles = Dir.glob(File.join(root, "docs/posts/*/article.md")).sort
errors = []
articles.each do |article_path|
  text = File.read(article_path)
  references = [text[/^image:\s*(\S+)/, 1]]
  references.concat(text.scan(/<img\s+[^>]*src=["']([^"']+)["']/).flatten)
  errors << "#{article_path}: missing article image" if references.length < 2 || references.any?(&:nil?)
  errors << "#{article_path}: Jekyll Mermaid fence in portable edition" if text.include?("```mermaid!\n")

  references.compact.each do |reference|
    path = Pathname.new(reference)
    if path.absolute? || !reference.start_with?("assets/") || path.each_filename.include?("..")
      errors << "#{article_path}: invalid relative image #{reference}"
      next
    end
    image = File.expand_path(reference, File.dirname(article_path))
    if !File.file?(image)
      errors << "#{article_path}: missing image #{reference}"
    elsif File.binread(image, 12).byteslice(8, 4) != "WEBP"
      errors << "#{article_path}: invalid WebP #{reference}"
    end
  end
end

errors.each { |error| warn "BLOCKED: #{error}" }
puts "Companion images: #{errors.empty? ? 'PASSED' : 'BLOCKED'} (#{articles.size} articles)"
exit(errors.empty? ? 0 : 1)

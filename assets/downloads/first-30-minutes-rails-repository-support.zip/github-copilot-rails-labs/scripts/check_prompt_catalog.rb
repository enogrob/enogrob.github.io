#!/usr/bin/env ruby
# frozen_string_literal: true

require "pathname"

root = Pathname.new(__dir__).parent
names = %w[01-trace-request 02-context-audit 03-agent-issue-to-pr]
names.each do |name|
  canonical = root.join("caseflow", ".github", "prompts", "#{name}.prompt.md")
  catalog = root.join("prompts", "#{name}.md")
  abort "Missing prompt: #{canonical}" unless canonical.file?
  abort "Missing prompt: #{catalog}" unless catalog.file?
  abort "Prompt catalog differs: #{catalog}" unless canonical.binread == catalog.binread
end

puts "Prompt catalog matches all #{names.length} CaseFlow workspace prompts."

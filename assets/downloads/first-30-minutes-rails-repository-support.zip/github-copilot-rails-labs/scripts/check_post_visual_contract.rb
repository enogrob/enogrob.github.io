#!/usr/bin/env ruby
# frozen_string_literal: true

# Release gate for the Jekyll post and its chapter-ready companion package.
ROOT = File.expand_path("../..", __dir__)
REPO = File.join(ROOT, "github-copilot-rails-labs")
POST = Dir[File.join(ROOT, "post-01-jekyll/_posts/*.md")].first
COVER = File.join(ROOT, "post-01-jekyll/assets/images/posts/first-30-minutes-rails-repository/cover.webp")
DIAGRAM = File.join(REPO, "docs/diagrams/request-path.mmd")
POST_DIR = File.join(REPO, "docs/posts/01-first-30-minutes")
AUDIT = File.join(POST_DIR, "visual-audit.yml")
errors = []

required_files = [POST, COVER, DIAGRAM, AUDIT, File.join(POST_DIR, "article.md")]
required_files.each { |path| errors << "missing #{path}" unless path && File.file?(path) }

if errors.empty?
  article = File.read(POST)
  diagram = File.read(DIAGRAM).strip
  errors << "canonical mermaid! block does not match diagram source" unless article.include?("mermaid: true") && article.include?("```mermaid!\n#{diagram}\n```")
  errors << "legacy Mermaid fence found" if article.include?("```mermaid\n")
  errors << "required description or responsive cover markup missing" unless article.include?("description:") && article.include?('style="width:100%;height:auto;"')
  errors << "contents or references section missing" unless article.include?("## Contents\n") && article.include?("## References and supporting materials")
  download = File.join(ROOT, "post-01-jekyll/assets/downloads/first-30-minutes-rails-repository-support.zip")
  errors << "downloadable companion package or article link missing" unless File.file?(download) && article.include?("/assets/downloads/first-30-minutes-rails-repository-support.zip")
  errors << "support article.md must exactly match Jekyll post source" unless File.binread(POST) == File.binread(File.join(POST_DIR, "article.md"))

  readme = File.read(File.join(REPO, "README.md"))
  ["## Contents", "## Evidence map", "```mermaid\n", "## References", "docs/posts/01-first-30-minutes/article.md", "docs/labs/01-study-workbook.md"].each do |token|
    errors << "README missing #{token.inspect}" unless readme.include?(token)
  end
  workbook_path = File.join(REPO, "docs/labs/01-study-workbook.md")
  workbook = File.file?(workbook_path) ? File.read(workbook_path) : ""
  errors << "study workbook missing learning sections, answers, or Mermaid" unless ["## Contents", "## The mental model", "## Exercises", "## Answer key", "## References", "```mermaid\n"].all? { |token| workbook.include?(token) }
  %w[cover.webp cover-source.png evidence-boundary.webp evidence-boundary-source.png].each do |asset|
    errors << "support package missing #{asset}" unless File.file?(File.join(POST_DIR, "assets", asset))
  end

  %w[
    caseflow/Gemfile caseflow/config/application.rb caseflow/config/database.yml
    caseflow/config/routes.rb caseflow/app/controllers/api/requests_controller.rb
    caseflow/app/models/application_record.rb caseflow/app/models/service_request.rb
    caseflow/app/controllers/application_controller.rb caseflow/spec/rails_helper.rb
    caseflow/spec/requests/api/requests_spec.rb parts/README.md
    parts/01-first-30-minutes/README.md parts/01-first-30-minutes/request-map.md
    parts/01-first-30-minutes/copilot-workspace.md prompts/01-trace-request.md
    docs/architecture/README.md docs/architecture/generated-inventory.md
    scripts/build_caseflow_inventory.rb
  ].each do |source|
    errors << "integrated lab missing #{source}" unless File.file?(File.join(REPO, source))
  end
  prompt = File.read(File.join(REPO, "prompts/01-trace-request.md")).downcase
  errors << "atlas prompt must demand Mermaid, impact and evidence artifacts" unless %w[mermaid].all? { |token| prompt.include?(token) } && prompt.include?("evidence register") && prompt.include?("change-impact table")
  atlas = File.read(File.join(REPO, "docs/architecture/README.md"))
  ["## Capabilities", "## Request path", "## Data and impact", "## Evidence register", "## References"].each do |section|
    errors << "architecture atlas missing #{section}" unless atlas.include?(section)
  end

  # A VP8 WebP frame stores 14-bit little-endian width/height at offsets 26/28.
  bytes = File.binread(COVER, 30)
  valid_webp = bytes.start_with?("RIFF") && bytes.byteslice(8, 4) == "WEBP" && bytes.byteslice(12, 4) == "VP8 "
  if valid_webp
    width = bytes.byteslice(26, 2).unpack1("v") & 0x3fff
    height = bytes.byteslice(28, 2).unpack1("v") & 0x3fff
    errors << "cover must be 1600x900 WebP" unless [width, height] == [1600, 900]
  else
    errors << "cover format cannot be verified as VP8 WebP"
  end

  audit = File.read(AUDIT)
  references = audit.scan(/^approved_cover_[1-3]:\s*(\S+)/).flatten
  errors << "three distinct approved cover references required" unless references.size == 3 && references.uniq.size == 3
  %w[historical_fit canonical_background_fit foreground_motion_and_depth content_fit cross_image_continuity thumbnail_clarity semantic_color_use text_accuracy].each do |dimension|
    rating = audit.match(/^#{dimension}:\s*([1-5])\s*$/)
    errors << "#{dimension} needs reviewed score >= 4" unless rating && rating[1].to_i >= 4
  end
end

errors.each { |problem| warn "BLOCKED: #{problem}" }
puts "Visual release gate: #{errors.empty? ? 'PASSED' : 'BLOCKED'}"
exit(errors.empty? ? 0 : 1)

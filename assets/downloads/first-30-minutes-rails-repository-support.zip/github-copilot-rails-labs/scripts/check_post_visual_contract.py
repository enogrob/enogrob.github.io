#!/usr/bin/env python3
"""Fail closed on easy-to-forget Factory Blog release requirements."""
from pathlib import Path
import re
import sys


def check(article: Path, cover: Path, diagram: Path, audit: Path) -> list[str]:
    errors = []
    text = article.read_text()
    source = diagram.read_text().strip()
    if "mermaid: true" not in text or "```mermaid!\n" + source + "\n```" not in text:
        errors.append("canonical mermaid! block does not match diagram source")
    if "```mermaid\n" in text:
        errors.append("legacy Mermaid fence found")
    if "description:" not in text or "style=\"width:100%;height:auto;\"" not in text:
        errors.append("required description or responsive cover markup missing")
    if "## Contents\n" not in text or "## References and supporting materials" not in text:
        errors.append("contents or references section missing")
    support = article.parents[1] / "assets/downloads/first-30-minutes-rails-repository-support.zip"
    if not support.is_file() or "/assets/downloads/first-30-minutes-rails-repository-support.zip" not in text:
        errors.append("downloadable companion package or article link missing")
    post_dir = diagram.parents[1] / "posts/01-first-30-minutes"
    article_copy = post_dir / "article.md"
    if not article_copy.is_file() or article_copy.read_bytes() != article.read_bytes():
        errors.append("support article.md must exactly match Jekyll post source")
    readme = diagram.parents[2] / "README.md"
    readme_text = readme.read_text()
    for requirement in ("## Contents", "## Evidence map", "```mermaid\n", "## References", "docs/posts/01-first-30-minutes/article.md", "docs/labs/01-study-workbook.md"):
        if requirement not in readme_text:
            errors.append(f"README missing {requirement!r}")
    workbook = diagram.parents[1] / "labs/01-study-workbook.md"
    if not workbook.is_file() or not all(heading in workbook.read_text() for heading in ("## Contents", "## The mental model", "## Exercises", "## Answer key", "## References", "```mermaid\n")):
        errors.append("study workbook missing learning sections, answers, or Mermaid")
    for asset_name in ("cover.webp", "cover-source.png", "evidence-boundary.webp", "evidence-boundary-source.png"):
        if not (post_dir / "assets" / asset_name).is_file():
            errors.append(f"support package missing {asset_name}")
    repo = diagram.parents[2]
    for source in (
        "caseflow/Gemfile", "caseflow/config/application.rb", "caseflow/config/database.yml",
        "caseflow/config/routes.rb", "caseflow/app/controllers/api/requests_controller.rb",
        "caseflow/app/models/application_record.rb", "caseflow/app/models/service_request.rb",
        "caseflow/app/controllers/application_controller.rb", "caseflow/spec/rails_helper.rb",
        "caseflow/spec/requests/api/requests_spec.rb", "parts/README.md",
        "parts/01-first-30-minutes/README.md", "parts/01-first-30-minutes/request-map.md",
        "parts/01-first-30-minutes/copilot-workspace.md", "prompts/01-trace-request.md",
    ):
        if not (repo / source).is_file():
            errors.append(f"integrated lab missing {source}")
    prompt = (repo / "prompts/01-trace-request.md").read_text()
    if "Mermaid" not in prompt or "evidence table" not in prompt:
        errors.append("mapping prompt must demand reviewable table and Mermaid output")
    try:
        from PIL import Image
        with Image.open(cover) as image:
            if image.size != (1600, 900) or image.format != "WEBP":
                errors.append("cover must be 1600x900 WebP")
    except ImportError:
        errors.append("Pillow required to verify cover dimensions")
    references = re.findall(r"^approved_cover_[1-3]:\s*(\S+)", audit.read_text(), re.M)
    if len(references) != 3 or len(set(references)) != 3:
        errors.append("three distinct approved cover references required")
    for dimension in ("historical_fit", "canonical_background_fit", "foreground_motion_and_depth", "content_fit", "cross_image_continuity", "thumbnail_clarity", "semantic_color_use", "text_accuracy"):
        match = re.search(rf"^{dimension}:\s*([1-5])\s*$", audit.read_text(), re.M)
        if not match or int(match.group(1)) < 4:
            errors.append(f"{dimension} needs reviewed score >= 4")
    return errors


if __name__ == "__main__":
    base = Path(__file__).resolve().parents[2]
    asset = base / "post-01-jekyll/assets/images/posts/first-30-minutes-rails-repository/cover.webp"
    article = next((base / "post-01-jekyll/_posts").glob("*.md"))
    diagram = base / "github-copilot-rails-labs/docs/diagrams/request-path.mmd"
    audit = base / "github-copilot-rails-labs/docs/posts/01-first-30-minutes/visual-audit.yml"
    problems = check(article, asset, diagram, audit)
    for problem in problems:
        print("BLOCKED:", problem)
    print("Visual release gate:", "BLOCKED" if problems else "PASSED")
    sys.exit(bool(problems))

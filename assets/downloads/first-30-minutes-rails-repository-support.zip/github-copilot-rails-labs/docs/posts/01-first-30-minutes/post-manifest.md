# Post 01 · publication and support manifest

Status: cover and section illustration approved by Roberto; Jekyll rendering confirmed by Roberto on 2026-09-25. Rails app runtime validation remains pending. The [complete article](article.md) is included in this companion package as an exact copy of the accompanying Jekyll `_posts/2026-09-25-the-first-30-minutes-in-an-unfamiliar-rails-repository.md`. No public publication is claimed.

| Material | Path / state |
|---|---|
| Synthetic Rails source | `caseflow/` (assembled Rails API app; dependencies/runtime unverified) |
| Complete article Markdown | `docs/posts/01-first-30-minutes/article.md` (exact Jekyll source copy) |
| Exercise and answer guide | `docs/labs/01-codebase-diagnosis.md` |
| Pedagogical workbook and commented answer key | `docs/labs/01-study-workbook.md` |
| Bounded Copilot prompt | `prompts/01-trace-request.md` |
| Editable Mermaid source | `docs/diagrams/request-path.mmd` — the diagram embedded in the post |
| Jekyll visuals | `assets/images/posts/first-30-minutes-rails-repository/cover.webp` and `evidence-boundary.webp` in the article package |
| Article visual assets | `docs/posts/01-first-30-minutes/assets/` includes WebP and PNG masters |
| Downloadable support archive | `assets/downloads/first-30-minutes-rails-repository-support.zip` in the Jekyll article package |
| Private interview card | Outside public package; not yet drafted |

## Visual script

- **Cover:** a large Copilot-inspired symbolic assistant in side profile emerges from the green network and looks at an **illustrative CaseFlow browser mockup** in the center, echoing the concrete application focus of the recent Ruby cover. Ruby/source layers, a subdued route gateway and an amber question appear around the central site. The screenshot-like site is a **concept only**; the source app is a Rails API with no built web UI. The series eyebrow reads “GitHub Copilot for Rails Engineers · Part 01,” the main title names the unfamiliar Rails repository, and the subtitle explicitly mentions Copilot. The character remains legible at thumbnail size; no explicit green background sphere at top. 16:9 source and 1600×900 WebP.
- **In-article Mermaid:** exact `mermaid!` Jekyll fence, canonical initialization, functional icons, subgraphs and semantic pastel classes; request goes through route, controller, model validation/save and conditional response; migration is a dotted schema reference. Branches are marked as expected, not executed.
- **Internal image:** at the section about test assertions, a close view titled “From Assertion to Evidence” uses four semantic labels: source, assertion, unverified, observation. A realistic central editor depicts a *conceptual* `requests_spec.rb` tab without readable fabricated code; an amber gate separates it from an **empty** observation pane. The blog's green network and multicolor Holoflux wrap this concrete central scene. The illustration explains this section's evidence boundary; it does not claim the spec passed.

## QA / blockers

- Inspected five integrated CaseFlow files and two request-spec cases; article's code excerpts agree with them.
- Article includes `mermaid: true`, an image alt description and three official source links.
- Integrated source app still lacks installed gems, lockfile and executed specs. Do not claim a passing request or CI result.
- Roberto reported that the article rendered correctly in his Jekyll blog on 2026-09-25. This authoring environment has no direct build log or separate mobile-view confirmation.
- Factory visual reference audit: inspected the recent 2026-09-23 Ruby cover and internal visuals, 2026-09-22 Bohm/Holoflux cover image, and 2026-09-23 Copilot cover. The **live** Factory Blog contract is schema 2 / Canonical Flow; the v0.7.3 ZIP was outdated and is not the production authority. All eight identity scores recorded separately.
- A GitHub repository URL remains pending because no remote exists. The article's local support archive path is present; verify it in the deployed Jekyll preview before publication.
- The Jekyll package now includes a local downloadable support ZIP and the article links to it from the introduction and references. GitHub repository links can be added when a remote exists; the download remains a usable companion meanwhile.
- Preserve PNG master for possible ebook adaptation; WebP is the web derivative. The master is a raster source, so inspect print suitability if a later book requires larger dimensions.

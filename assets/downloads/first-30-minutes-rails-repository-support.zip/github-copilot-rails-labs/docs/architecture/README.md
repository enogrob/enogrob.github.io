# CaseFlow architecture atlas · Part 01

The first 30-minute deliverable is a small, navigable map for a **change question**: “Could a client resolve a request through this API, and what would we change?” This is an audited *source map*, not a measured runtime trace. The source is intentionally small; extending it across policies, jobs and external effects belongs to later parts.

## Contents

- [Capabilities](#capabilities)
- [Request path](#request-path)
- [Data and impact](#data-and-impact)
- [Evidence register](#evidence-register)
- [How to refresh](#how-to-refresh)
- [References](#references)

## Capabilities

| Capability visible in source | Entry point | Evidence | Limit |
|---|---|---|---|
| List recent requests | `GET /api/requests` | [`routes.rb`](../../caseflow/config/routes.rb), [`index`](../../caseflow/app/controllers/api/requests_controller.rb) | No observed response |
| Show one request | `GET /api/requests/:id` | [`routes.rb`](../../caseflow/config/routes.rb), [`show`](../../caseflow/app/controllers/api/requests_controller.rb) | Missing ID not exercised |
| Create a request | `POST /api/requests` | [`routes.rb`](../../caseflow/config/routes.rb), [`create`](../../caseflow/app/controllers/api/requests_controller.rb) | Specs assert 201/422; no passing run supplied |
| Transition status | No route or action supplied | [`routes.rb`](../../caseflow/config/routes.rb), [`controller`](../../caseflow/app/controllers/api/requests_controller.rb) | Requires design, authorization and tests |

## Request path

Open the [editable request diagram](../diagrams/request-path.mmd) in a Mermaid preview. The same diagram is embedded in [the article](../posts/01-first-30-minutes/article.md). Its dotted migration edge is a schema dependency; the solid edges depict a source-backed *expected* path. Use [the deterministic inventory](generated-inventory.md) to jump to the relevant declarations.

## Data and impact

| Proposed change: permit `open` → `resolved` | Inspect | Why it matters |
|---|---|---|
| API surface | [`routes.rb`](../../caseflow/config/routes.rb), [`controller`](../../caseflow/app/controllers/api/requests_controller.rb) | No transition endpoint is currently declared; existing `create` excludes `status`. |
| Persisted state | [`model`](../../caseflow/app/models/service_request.rb), [`migration`](../../caseflow/db/migrate/20260925000000_create_service_requests.rb) | `resolved` is an allowed stored value; that does not define who may change it. |
| Safety contract | [`request specs`](../../caseflow/spec/requests/api/requests_spec.rb) | The two current examples cover creation only. Design tests for allowed and forbidden transitions. |
| Unknown dependencies | Other repo files and running app | Do not infer authorization, callbacks, jobs or external effects from this small app. Search and test before changing it. |

## Evidence register

| Claim | Class | Proof or next check |
|---|---|---|
| Route declares create but not update | Source fact | [`config/routes.rb`](../../caseflow/config/routes.rb) |
| Migration declares `open` default | Schema source | [Migration](../../caseflow/db/migrate/20260925000000_create_service_requests.rb); check migrated DB |
| Missing title should be rejected | Model/controller and spec expectation | [Validation](../../caseflow/app/models/service_request.rb), [spec](../../caseflow/spec/requests/api/requests_spec.rb); run focused spec |
| Valid request returned 201 on your Mac | Unknown in this package | Capture command, exit code and actual response |
| All users may change status | Unsupported | Define authorization requirement first; there is no transition action |

The last row is the **answer**, not a gap to hide: knowing what the source does *not* establish tells the client what to commission next.

## How to refresh

1. In the repository root run `ruby scripts/build_caseflow_inventory.rb`. It extracts declarations from five named files and labels its limits; it does not attempt a general Rails call graph.
2. Open `caseflow/` as the VS Code workspace. Run [the Copilot atlas prompt](../../prompts/01-trace-request.md) and compare its draft capability and impact maps with source and the inventory.
3. Correct the Mermaid edges and citations manually. Record real commands and results or the first blocker in your private environment log.
4. Update this atlas when source changes. Only mark a behavior observed after executing it.

## References

- [Full post](../posts/01-first-30-minutes/article.md)
- [Source inventory](generated-inventory.md)
- [Mermaid request path](../diagrams/request-path.mmd)
- [VS Code workspace context](https://code.visualstudio.com/docs/agents/reference/workspace-context)

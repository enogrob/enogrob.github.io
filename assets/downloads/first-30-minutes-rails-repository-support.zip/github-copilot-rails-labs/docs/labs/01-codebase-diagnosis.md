# Lab 01 · The first 30 minutes

**Goal:** explain the supplied `POST /api/requests` path without mistaking a framework convention, Copilot answer or unrun test for observed behavior.

## 1. Predict

Before opening source files, write three explicitly labelled predictions: accepted input, stored record and returned response. Put these in your local `ENVIRONMENT.md`.

## 2. Inspect the source

Read, in order:

1. `caseflow-overlay/config/routes.rb`
2. `caseflow-overlay/app/controllers/api/requests_controller.rb`
3. `caseflow-overlay/app/models/service_request.rb`
4. `caseflow-overlay/db/migrate/20260925000000_create_service_requests.rb`
5. `caseflow-overlay/spec/requests/api/requests_spec.rb`

The migration defines table schema and defaults; it does not run on each HTTP request. `serialize` is a method in the controller, not a separate serializer file. The spec asserts valid creation and missing-title rejection, but its result has not been observed here.

## 3. Ask Copilot for a bounded map

Use [the post 01 prompt](../../prompts/01-trace-request.md), then open each cited path. Mark nonexistent or unsupported citations. Do not let the answer edit source files in this lab.

## 4. Create a local Rails shell and execute

Follow the overlay README or the accompanying blog post on your Mac. Record exact versions, dependency failures, migration outcome, focused RSpec result and a synthetic HTTP response. Do not paste a hypothetical success message. The starter by itself cannot be run without a generated Rails app and compatible dependencies.

## 5. Explain what the evidence supports

| Claim | Exact source file | Actual command/output, or blocker | Observed / inferred / unsupported |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

**Exercise:** explain why a stored `status` with allowed values does not prove that clients can transition a request. Propose one bounded, testable issue for a next iteration.

**Answer guide:** the supplied route has `index`, `show`, `create`; there is no `update` action or permitted create `status`. The model constrains stored values, while a transition endpoint would require a route, policy, implementation and tests. Record real execution evidence separately.

# Lab 01 · The first 30 minutes

**Goal:** explain the supplied `POST /api/requests` path without mistaking a framework convention, Copilot answer or unrun test for observed behavior.

## 1. Predict

Before opening source files, write three explicitly labelled predictions: accepted input, stored record and returned response. Put these in your local `ENVIRONMENT.md`.

## 2. Inspect the source

Read, in order:

1. `caseflow/config/routes.rb`
2. `caseflow/app/controllers/api/requests_controller.rb`
3. `caseflow/app/models/service_request.rb`
4. `caseflow/db/migrate/20260925000000_create_service_requests.rb`
5. `caseflow/spec/requests/api/requests_spec.rb`

The migration defines table schema and defaults; it does not run on each HTTP request. `serialize` is a method in the controller, not a separate serializer file. The spec asserts valid creation and missing-title rejection, but its result has not been observed here.

## 3. Ask Copilot for a reviewable map

Use [the post 01 prompt](../../prompts/01-trace-request.md), then open each cited path. Compare the generated evidence table and Mermaid diagram with [the reviewed map](../../parts/01-first-30-minutes/request-map.md). Mark nonexistent or unsupported citations, false diagram edges and unlabeled runtime assumptions. Do not let the answer edit source files in this lab.

## 4. Run the integrated Rails app and execute

Follow the integrated app README or the accompanying blog post on your Mac. Record exact versions, dependency failures, migration outcome, focused RSpec result and a synthetic HTTP response. Do not paste a hypothetical success message. The integrated app supplies a Rails source tree, but installation and runtime results remain unverified.

## 5. Explain what the evidence supports

| Claim | Exact source file | Actual command/output, or blocker | Observed / inferred / unsupported |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

**Exercise:** explain why a stored `status` with allowed values does not prove that clients can transition a request. Propose one bounded, testable issue for a next iteration.

**Answer guide:** the supplied route has `index`, `show`, `create`; there is no `update` action or permitted create `status`. The model constrains stored values, while a transition endpoint would require a route, policy, implementation and tests. Record real execution evidence separately.

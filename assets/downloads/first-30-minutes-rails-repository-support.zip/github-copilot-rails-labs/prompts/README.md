# CaseFlow Copilot prompts

This directory offers full readable copies of the course prompts. To run a prompt through GitHub Copilot Chat in VS Code, open `caseflow/` as the workspace and invoke the matching file in `caseflow/.github/prompts/`.

| Part | Read the prompt in this companion | Run in the CaseFlow workspace |
| --- | --- | --- |
| 01 · Understand the repository | [01-trace-request.md](01-trace-request.md) | [.github/prompts/01-trace-request.prompt.md](../caseflow/.github/prompts/01-trace-request.prompt.md) · `/01-trace-request` |
| 02 · Audit context | [02-context-audit.md](02-context-audit.md) | [.github/prompts/02-context-audit.prompt.md](../caseflow/.github/prompts/02-context-audit.prompt.md) · `/02-context-audit` |
| 03 · Issue to PR | [03-agent-issue-to-pr.md](03-agent-issue-to-pr.md) | [.github/prompts/03-agent-issue-to-pr.prompt.md](../caseflow/.github/prompts/03-agent-issue-to-pr.prompt.md) · `/03-agent-issue-to-pr` |

The files in `caseflow/.github/prompts/` are the source of truth. The readable copies in this directory must match them byte-for-byte. Run `ruby scripts/check_prompt_catalog.rb` from the companion root before publishing a package.

# Bounded Copilot prompt · post 01

```text
Trace POST /api/requests through the route, controller, model and migration.
Cite the exact file path for each source-backed statement.
Separate facts visible in source from behavior that still needs a run or test.
State what the supplied tests assert without claiming they passed.
List unknown behavior and do not edit files.
```

Review the answer against the actual source. A plausible filename or ordinary Rails convention is not sufficient evidence for this repository.

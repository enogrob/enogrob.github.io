# Copilot prompt 01 · Build a reviewable architecture atlas

Open **`caseflow/` as the VS Code workspace**. First produce an independent [source inventory](../docs/architecture/generated-inventory.md) from the companion root with `python3 scripts/build_caseflow_inventory.py`. The inventory is narrow and cannot prove runtime behavior. Copilot's workspace search/index helps discover relationships; its output must be audited.

```text
A client asks whether they can resolve a CaseFlow request through this Rails API.
Investigate this workspace in read-only mode. Search route, controller, model,
migration and specs; follow additional dependencies only when found in source.
Produce a draft architecture atlas with:
1. Capabilities: operation | entry point | exact source file/symbol | unknown.
2. A Mermaid flowchart TD of POST /api/requests through route, permitted
   fields, validation/save and expected 201/422; show the migration as a
   dotted schema dependency, not a runtime call.
3. Change-impact table for adding open → resolved: API, model/data, tests,
   authorization and other effects. Label absent or undiscovered components.
4. Evidence register: source fact, spec assertion, observed run or unknown.
5. Three targeted checks that could falsify your most important assumptions.
Do not edit code. Do not invent routes, passing tests, jobs or authorization.
```

Compare the draft with [the reviewed atlas](../docs/architecture/README.md), [the declaration inventory](../docs/architecture/generated-inventory.md) and [the editable diagram](../docs/diagrams/request-path.mmd). Remove every unsupported edge before reusing the map. A small app makes this a learning exercise; the same method becomes more valuable as dependencies grow. See [VS Code workspace context](https://code.visualstudio.com/docs/agents/reference/workspace-context).

# Prompt 01 · Produce a reviewable repository map

Open the **`caseflow/` folder as the VS Code workspace** and use Copilot Chat Agent mode if workspace search tools are available. Attach `config/routes.rb` and `app/controllers/api/requests_controller.rb` explicitly if the workspace search misses them. Ask Copilot to produce a draft; independently compare every edge and claim to code.

```text
Investigate POST /api/requests in this workspace without editing files.
Search for the actual route, controller, model, schema migration and request specs.
Return these artifacts in this order:
1. A compact evidence table: claim | exact relative file path + symbol | source / spec assertion / observed run / unknown.
2. A valid Mermaid flowchart TD with route → strong parameters → model validation/save → 201 or 422. Show the migration as a dotted schema dependency, never a runtime call. Label branches "expected in source; unverified" until commands are run. Use semantic pastel classDefs and meaningful subgraphs.
3. Three things the source cannot establish and the smallest command or test that would resolve each.
Do not claim that a spec passed, invent a file, implement an endpoint or infer an update action from allowed status values. If a file is missing, mark it unknown.
```

## Verify the result

Compare Copilot's output against [the reference source map](../parts/01-first-30-minutes/request-map.md) and [editable Mermaid](../docs/diagrams/request-path.mmd). A generated diagram is a **hypothesis to audit**, not a verified architecture map. In VS Code, Mermaid in chat can be rendered for exploration; keep the reviewed `.mmd` as the reusable diagram source. Read [the workspace context guidance](https://code.visualstudio.com/docs/agents/reference/workspace-context) and [Mermaid chat support](https://code.visualstudio.com/docs/agents/reference/ai-features-cheat-sheet).

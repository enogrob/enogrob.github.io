# CaseFlow source overlay

This directory adds application source and request specs to a **freshly generated** Rails API project. It is not runnable on its own.

On a Mac with a compatible Ruby, Rails and PostgreSQL installation, in an empty directory:

```bash
rails new caseflow --api --database=postgresql
cd caseflow
```

Copy the contents of this `caseflow-overlay/` directory into the new `caseflow/` directory, preserving paths. Inspect the changes with `git diff` before committing. Add a `rspec-rails` version compatible with the Rails version you generated to the development/test group of the new `Gemfile`, then run:

```bash
bundle install
bin/rails generate rspec:install
bin/rails db:create db:migrate
bundle exec rspec
```

Record **actual** output or the first blocker. Do not infer a passing test from this README. Start the server and use synthetic HTTP requests only after setup succeeds. The local `ENVIRONMENT.md` is ignored by the companion repository and must not contain credentials or real customer data.

The supplied route defines `index`, `show`, `create`. The request spec covers only valid POST creation and missing title. A missing-ID response and status transition are not tested by the starter. See the [lab](../docs/labs/01-codebase-diagnosis.md) for the evidence exercise.

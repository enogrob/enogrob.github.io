# CaseFlow agent guidance

- This is a Rails teaching project. Keep changes small and tied to one chapter checkpoint.
- Read the route, controller, model, migration, and relevant specs before editing a request path.
- Never invent passing test results. Run focused RSpec and report the actual command and output.
- Use synthetic data; do not put credentials or client data in prompts, code or tests.
- Explain migration and behavior changes in the PR description.
- Before adding dependencies, justify their purpose and review their maintenance and security impact.

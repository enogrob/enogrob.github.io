# GitHub Copilot for Rails Engineers

*A source-backed blog series and hands-on integrated CaseFlow Rails app, with one post per future book chapter.*

![A digitized Copilot-inspired guide studies a conceptual CaseFlow Rails interface.](docs/posts/01-first-30-minutes/assets/cover.webp)

The cover shows a **conceptual CaseFlow interface**. This repository contains an integrated Rails API source app, not an implemented web UI. This independent educational project is not affiliated with or endorsed by GitHub or Avanade.

## Contents

- [Read post 01](#read-post-01)
- [Explore the material](#explore-the-material)
- [Series parts](parts/README.md)
- [Study and practice](#study-and-practice)
- [Run the lab on your Mac](#run-the-lab-on-your-mac)
- [Evidence map](#evidence-map)
- [Validation status](#validation-status)
- [References](#references)

## Read post 01

**[The First 30 Minutes in an Unfamiliar Rails Repository](docs/posts/01-first-30-minutes/article.md)** is the complete Jekyll Markdown source, including Contents, code, a Mermaid diagram, an exercise and references. It matches the `_posts/` file in the accompanying Jekyll package byte for byte. Site-root image and download URLs in its body are intended for the blog. Open the [cover](docs/posts/01-first-30-minutes/assets/cover.webp) or [section illustration](docs/posts/01-first-30-minutes/assets/evidence-boundary.webp) directly in this package.

## Explore the material

| Read next | Why |
|---|---|
| [Study workbook 01, with answers](docs/labs/01-study-workbook.md) | Learn the evidence model, solve seven varied exercises, then check commented answers at the end. |
| [Lab 01 and answer guide](docs/labs/01-codebase-diagnosis.md) | Build the architecture atlas, verify Copilot's map and document unknowns. |
| [Integrated CaseFlow app](caseflow/README.md) | Inspect routes, controller, model, migration and request specs. |
| [Artifact-producing Copilot prompt](prompts/01-trace-request.md) | Draft a capability map, Mermaid path, change-impact table and evidence register, then audit them. |
| [Workspace mapping guide](parts/01-first-30-minutes/copilot-workspace.md) | See how Copilot retrieves context and how to turn drafts into reviewed artifacts. |
| [CaseFlow architecture atlas](docs/architecture/README.md) | Navigate capabilities, request path, change impact and evidence; refresh the inventory. |
| [Reviewed request map](parts/01-first-30-minutes/request-map.md) | Compare Copilot output with source-backed claims and the editable diagram. |
| [Mermaid diagram source](docs/diagrams/request-path.mmd) | Edit or reuse the same diagram embedded in the post without extracting it from the article. |
| [Post manifest and visual sources](docs/posts/01-first-30-minutes/post-manifest.md) | Find visuals, PNG masters, QA notes and ebook reuse notes. |
| [Series parts](parts/README.md) | Follow Part 01 and the planned chapter entrypoints. |
| [Series map](docs/series-map.md) | Follow the six independent post outcomes. |
| [Production workflow](docs/production-workflow.md) · [Visual standard](docs/visual-standard.md) | Preserve Factory Blog gates in future posts. |

## Study and practice

Start with [the complete post](docs/posts/01-first-30-minutes/article.md), then use [Part 01](parts/01-first-30-minutes/README.md) and work through [the pedagogical workbook](docs/labs/01-study-workbook.md). It mixes a short theory section, prediction, source tracing, a deliberately flawed AI answer, evidence matching, a customer scenario and a hands-on lab. Attempt each exercise before reading its answer key. The [field checklist](docs/labs/01-codebase-diagnosis.md) can be used during the hands-on session.

All companion automation uses Ruby. From this repository's root, regenerate the [source inventory](docs/architecture/generated-inventory.md) with `ruby scripts/build_caseflow_inventory.rb`. When the sibling `post-01-jekyll/` folder and its ZIP are present, run `ruby scripts/check_post_visual_contract.rb` to check the Jekyll article and companion release contract.

## Run the lab on your Mac

1. Read the [complete article](docs/posts/01-first-30-minutes/article.md), generate [the inventory](docs/architecture/generated-inventory.md), and make three predictions about `POST /api/requests`.
2. Open [the integrated CaseFlow app](caseflow/README.md) and follow its setup. The integrated app still needs dependency installation and an actual test run.
3. Inspect the files, try the [prompt](prompts/01-trace-request.md), then run the focused spec if setup succeeds.
4. Record your versions, actual commands, results or first blocker in a local `ENVIRONMENT.md` based on [the template](caseflow/ENVIRONMENT.template.md). Do not commit secrets or customer data.

## Evidence map

The diagram below uses GitHub's standard Mermaid fence; the Jekyll article uses the Factory Blog's `mermaid!` fence and matching source in `docs/diagrams/`.

```mermaid
%%{init: {'theme':'base','themeVariables':{'background':'#FFFFFF','primaryTextColor':'#3E342C','lineColor':'#6F7377'}}}%%
flowchart LR
    subgraph inspect["🔍 Inspect source"]
        A["🎯 Request"] --> B["🧭 Route"] --> C["⚙️ Controller"] --> D["🧱 Model"]
    end
    subgraph verify["🧪 Verify claims"]
        D --> E["📋 Test assertion"] --> F["❔ Run or blocker"]
    end
    F --> G["✅ Evidence log"]
    classDef input fill:#D9EAF7,stroke:#7AA6C2,color:#3E342C;
    classDef process fill:#F8DFC4,stroke:#C9986D,color:#3E342C;
    classDef unknown fill:#FFF1BF,stroke:#BA9C43,color:#3E342C;
    classDef result fill:#DCEFD6,stroke:#86A878,color:#3E342C;
    class A,B input;
    class C,D,E process;
    class F unknown;
    class G result;
```

An assertion in source is not a passing result. The evidence log records the actual run **or** a reproducible blocker.

## Validation status

The integrated app was assembled from the inspected source, and Roberto confirmed that the article rendered in his Jekyll blog on 2026-09-25. The cover and section image were approved. The authoring environment still has no installed gems, migrated SQLite database or recorded passing request spec. See [validation status](docs/validation-status.md) and the [post QA manifest](docs/posts/01-first-30-minutes/post-manifest.md). No GitHub remote or license has been selected for this companion project. The integrated app has not been executed in the authoring environment.

## References

- [Full post source and its references](docs/posts/01-first-30-minutes/article.md)
- [GitHub Docs: Explore a codebase with Copilot](https://docs.github.com/en/copilot/tutorials/explore-a-codebase)
- [GitHub Docs: Review AI-generated code](https://docs.github.com/en/copilot/tutorials/review-ai-generated-code)
- [Rails Guides: Routing](https://guides.rubyonrails.org/routing.html)
- [Rails Guides: Active Record Migrations](https://guides.rubyonrails.org/active_record_migrations.html)

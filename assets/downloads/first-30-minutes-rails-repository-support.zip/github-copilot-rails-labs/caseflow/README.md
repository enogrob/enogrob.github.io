# CaseFlow · Rails API learning app

CaseFlow is the **shared Rails 8 API** used by the *GitHub Copilot for Rails Engineers* series. It creates, lists and shows service requests. It does not expose a status update endpoint. The app source is integrated; dependency installation and passing tests have **not** been independently observed in this authoring environment. Roberto previously reported a missing `ApplicationRecord`; that class is now included, but a passing rerun is not recorded.

## Contents

- [Architecture](#architecture)
- [Dependencies and storage](#dependencies-and-storage)
- [Data and API](#data-and-api)
- [Start locally on a Mac](#start-locally-on-a-mac)
- [Run RSpec](#run-rspec)
- [Try the API with curl](#try-the-api-with-curl)
- [Sequence: creating a request](#sequence-creating-a-request)
- [Explore and update the atlas](#explore-and-update-the-atlas)
- [References](#references)

## Architecture

The diagram shows **source dependencies**, not observed production traffic. `ApplicationController` inherits from `ActionController::API`; `ServiceRequest` inherits from `ApplicationRecord`. A migration declares the SQLite schema. RSpec belongs to the development/test group and does not serve HTTP requests.

```mermaid
%%{init: {'theme':'base','flowchart':{'useMaxWidth':true,'nodeSpacing':36,'rankSpacing':44,'curve':'basis'},'themeVariables':{'background':'#FFF8EF','primaryTextColor':'#3E342C','lineColor':'#6F7377','fontFamily':'Trebuchet MS, Verdana, sans-serif','fontSize':'13px','clusterBkg':'#FBF4E7','clusterBorder':'#B8A17D'}}}%%
flowchart TD
    U["👤 API client"] --> P["🌐 Puma / Rails API"]
    subgraph application["🧭 CaseFlow application"]
      P --> R["🧭 Routes"] --> C["⚙️ RequestsController"]
      C --> M["🧱 ServiceRequest"]
    end
    M --> DB["📦 SQLite: service_requests"]
    T["🧪 RSpec request specs"] -.-> P
    G["📋 Migration: schema + default"] -.-> DB
    classDef input fill:#D9EAF7,stroke:#7AA6C2,color:#3E342C;
    classDef process fill:#F8DFC4,stroke:#C9986D,color:#3E342C;
    classDef model fill:#E8DDF5,stroke:#A68BC4,color:#3E342C;
    classDef data fill:#FFF1BF,stroke:#BA9C43,color:#3E342C;
    classDef test fill:#DCEFD6,stroke:#86A878,color:#3E342C;
    class U,R input;
    class P,C process;
    class M model;
    class DB,G data;
    class T test;
```

**Trace a source edge:** [routes](config/routes.rb) → [controller](app/controllers/api/requests_controller.rb) → [model](app/models/service_request.rb) → [migration](db/migrate/20260925000000_create_service_requests.rb). The [architecture atlas](../docs/architecture/README.md) adds capabilities, change impact and confidence labels. The [generated source inventory](../docs/architecture/generated-inventory.md) links to declarations by file and line.

## Dependencies and storage

| Source | Role | Scope |
|---|---|---|
| [`Gemfile`](Gemfile): `rails ~> 8.0.0` | API framework, routing and Active Record | App |
| [`Gemfile`](Gemfile): `puma >= 6.0` | Local HTTP server | App |
| [`Gemfile`](Gemfile): `sqlite3 >= 2.1` | Database adapter | App |
| [`Gemfile`](Gemfile): `rspec-rails ~> 8.0` | Request specs | Development/test |
| [`config/database.yml`](config/database.yml) | SQLite files under `storage/` for development, test and production | Configuration |

These are **Gemfile constraints**, not installed versions. This package has no `Gemfile.lock`; `bundle install` resolves versions on your Mac. The schema comes from the [migration](db/migrate/20260925000000_create_service_requests.rb), not from executing it during a request. No Redis, Sidekiq, background jobs or external services are configured in this app.

## Data and API

| Operation | Route | Current source behavior |
|---|---|---|
| List | `GET /api/requests` | Up to 50 requests, newest first |
| Show | `GET /api/requests/:id` | Find by id; missing-id behavior is not covered by supplied specs |
| Create | `POST /api/requests` | Permit `title` and `description`; render selected fields on success or validation errors on failed save |
| Change status | No route | `resolved` is an allowed stored value, **not** a client transition API |

`service_requests` contains `title` (required, maximum 160 characters at model level), optional `description`, `status` with declared default `open`, and timestamps. The controller's `serialize` method selects `id`, `title`, `description`, `status`, `created_at` and `updated_at`. Source and specs suggest `201` for valid creation and `422` for missing title; verify these on your installation before reporting them as observed.

## Start locally on a Mac

Install Ruby 3.3.6 (see [`.ruby-version`](.ruby-version)), Bundler and SQLite support. From **this `caseflow/` directory**:

```bash
ruby --version
bundle --version
bundle install
bin/rails db:prepare
bin/rails server
```

Keep the server running in this terminal; it should listen on `http://localhost:3000` if setup succeeds. Record the actual versions, resolved `Gemfile.lock`, migration output or first failure. If you received the entire companion ZIP, there is **no need to run `rails new` or copy an overlay**. `storage/` and local SQLite databases are ignored by Git. Do not put customer data or secrets into this teaching app.

## Run RSpec

In a **second terminal**, still inside `caseflow/`:

```bash
RAILS_ENV=test bin/rails db:prepare
bundle exec rspec spec/requests/api/requests_spec.rb
```

The two request specs assert valid creation and rejection of a missing title. Capture the command, exit status and output. A passing local spec supports only this configured environment; it does not verify deployment, authorization or a status transition. See the [study workbook](../docs/labs/01-study-workbook.md) for interpretation exercises.

## Try the API with curl

With the server running, use **synthetic data**. The examples are commands to execute, not captured responses:

```bash
curl -i -X POST http://localhost:3000/api/requests \
  -H 'Content-Type: application/json' \
  -d '{"request":{"title":"Update billing address","description":"Synthetic example"}}'

curl -i http://localhost:3000/api/requests

# Replace 1 with the id returned by the successful POST:
curl -i http://localhost:3000/api/requests/1

curl -i -X POST http://localhost:3000/api/requests \
  -H 'Content-Type: application/json' \
  -d '{"request":{"description":"Missing title"}}'
```

Compare response status and body against the [controller](app/controllers/api/requests_controller.rb) and [specs](spec/requests/api/requests_spec.rb). If `1` does not exist, use the id actually returned. Do not infer that an authenticated status-change request is available; there is no route for it.

## Sequence: creating a request

The short architecture diagram above is the default orientation. Expand the sequence when you need to inspect success and validation failure. The dashed migration arrow shows *schema preparation*, outside request handling. Both branches are **expected from source**, pending runtime confirmation.

<details>
<summary>Expand the request sequence and source assumptions</summary>

```mermaid
%%{init: {'theme':'base','sequence':{'useMaxWidth':true,'diagramMarginX':40,'diagramMarginY':30,'actorMargin':55,'messageMargin':38},'themeVariables':{'background':'#FFF8EF','primaryTextColor':'#3E342C','lineColor':'#6F7377','fontFamily':'Trebuchet MS, Verdana, sans-serif','fontSize':'13px','clusterBkg':'#FBF4E7','clusterBorder':'#B8A17D','noteBkgColor':'#FFF1BF','noteTextColor':'#3E342C','actorBkg':'#D9EAF7','actorBorder':'#7AA6C2','actorTextColor':'#3E342C','signalColor':'#6F7377','signalTextColor':'#3E342C'}}}%%
sequenceDiagram
    autonumber
    actor U as 👤 Client
    participant R as 🧭 Rails route
    participant C as ⚙️ RequestsController
    participant M as 🧱 ServiceRequest
    participant D as 📦 SQLite
    Note over D: Migration declares schema/default before requests
    U->>R: POST /api/requests
    R->>C: create
    C->>C: permit title, description
    C->>M: new(request_params), save
    alt save succeeds (source expectation)
      M->>D: persist after validation
      D-->>M: stored record
      M-->>C: true
      C-->>U: 201 + selected JSON
    else save fails (source expectation)
      M-->>C: false + errors
      C-->>U: 422 + error messages
    end
```

</details>

Read this as a conceptual source trace: the model validates **before** persisting; a failed save need not send a write to SQLite. The `M->>D` line summarizes the successful persistence path, so verify the actual runtime behavior before claiming a database call occurred for an invalid input.

## Explore and update the atlas

From the companion root, run `ruby scripts/build_caseflow_inventory.rb` to refresh declaration links, then follow [Part 01](../parts/01-first-30-minutes/README.md) to ask Copilot for capability, impact and evidence views. The generator records source declarations; it does not discover all dependencies or run tests. The repo-local [Mermaid architecture skill](../.github/skills/mermaid-architecture/SKILL.md) provides the same semantic palette, diagram discipline and renderer distinction used by the Factory Blog.

## References

- [Rails Getting Started](https://guides.rubyonrails.org/getting_started.html)
- [Rails Routing](https://guides.rubyonrails.org/routing.html)
- [RSpec Rails compatibility](https://github.com/rspec/rspec-rails)
- [Factory Blog visual standard](../docs/visual-standard.md)

# CaseFlow · integrated Rails API learning app

This is a small assembled Rails 8 API application used across the blog series. Its route, controller, model, migration and request specs are integrated in place. It is a source package, **not a verified running build**: Ruby/Bundler and the request specs have not been executed in this authoring environment, and no lockfile is supplied. 

## Contents

- [Setup on a Mac](#setup-on-a-mac)
- [Inspect and verify](#inspect-and-verify)
- [References](#references)

## Setup on a Mac

Use Ruby 3.3.6 or another supported Ruby 3.2+ installation and Bundler, then from this directory run:

```bash
bundle install
bin/rails db:prepare
bundle exec rspec spec/requests/api/requests_spec.rb
```

Record exact dependency resolution in `Gemfile.lock` and commit it before publishing this application as a standalone runnable project, and report any installation or spec failure. This bundle defaults to SQLite for a small Mac lab. Do not infer that the tests passed from their presence in source. Run `bin/rails server` after a successful setup.

## Inspect and verify

Start with [part 01](../parts/01-first-30-minutes/README.md). Follow `config/routes.rb`, `app/controllers/api/requests_controller.rb`, `app/models/service_request.rb`, the migration and `spec/requests/api/requests_spec.rb`. The map and agent instructions are explanatory; check each claim against files and real execution.

## References

- [Rails Getting Started](https://guides.rubyonrails.org/getting_started.html)
- [RSpec Rails compatibility](https://github.com/rspec/rspec-rails)

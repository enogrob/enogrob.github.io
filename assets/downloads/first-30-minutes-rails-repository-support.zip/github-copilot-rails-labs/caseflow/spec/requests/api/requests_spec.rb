require 'rails_helper'

RSpec.describe 'Service requests API', type: :request do
  describe 'POST /api/requests' do
    it 'creates an open request with valid input' do
      post '/api/requests', params: { request: { title: 'Update billing address' } }, as: :json

      expect(response).to have_http_status(:created)
      expect(JSON.parse(response.body)).to include('title' => 'Update billing address', 'status' => 'open')
      expect(ServiceRequest.count).to eq(1)
    end

    it 'rejects a missing title' do
      post '/api/requests', params: { request: { description: 'Missing title' } }, as: :json

      expect(response).to have_http_status(:unprocessable_entity)
      expect(ServiceRequest.count).to eq(0)
    end
  end
end

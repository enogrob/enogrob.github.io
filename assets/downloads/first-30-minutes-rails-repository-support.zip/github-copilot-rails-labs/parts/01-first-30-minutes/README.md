# Part 01 · The first 30 minutes

## Contents

- [Read the post](#read-the-post)
- [Practice](#practice)
- [References](#references)

## Read the post

[Full canonical article](../../docs/posts/01-first-30-minutes/article.md) · [architecture atlas](../../docs/architecture/README.md) · [reviewed request map](request-map.md) · [Mermaid source](../../docs/diagrams/request-path.mmd). The linked article uses Jekyll site-root image URLs.

## Practice

Start with the [Copilot CLI initialization lab](copilot-init-lab.md) in a disposable CaseFlow copy. Review any generated instructions against source before building the request atlas; the packaged app already carries Part 02 guidance.

Open [the integrated CaseFlow app](../../caseflow/README.md) as your VS Code workspace. Use [the Copilot workspace mapping guide](copilot-workspace.md). Read the [study workbook and answer key](../../docs/labs/01-study-workbook.md), try [the artifact-producing Copilot prompt](../../caseflow/.github/prompts/01-trace-request.prompt.md), and complete [the field lab](../../docs/labs/01-codebase-diagnosis.md). Source inspection has been performed; Ruby runtime is unverified.

In the `caseflow/` workspace, invoke `/01-trace-request` in Copilot Chat. The prompt is `.github/prompts/01-trace-request.prompt.md` inside that workspace. The generated inventory and reviewed atlas live outside it in the companion's `docs/architecture/`; use them **after** the independent prompt run to audit the result.

## References

- [Article references](../../docs/posts/01-first-30-minutes/article.md)
- [VS Code workspace context](https://code.visualstudio.com/docs/agents/reference/workspace-context)

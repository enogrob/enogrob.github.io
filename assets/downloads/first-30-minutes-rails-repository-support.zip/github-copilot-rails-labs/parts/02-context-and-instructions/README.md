# Part 02 · Context and instructions

Planned. Part-specific article, workbook, diagram and code changes will be added here after source review. Start with [the series map](../../docs/series-map.md).

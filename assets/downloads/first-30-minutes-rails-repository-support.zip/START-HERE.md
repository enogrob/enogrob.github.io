# GitHub Copilot for Rails Engineers · support archive

Read the three full prompts in `prompts/` at the root of this archive.
To run one in VS Code, open `github-copilot-rails-labs/caseflow/` as the workspace. Its executable prompt files live under `.github/prompts/`; invoke `/01-trace-request`, `/02-context-audit`, or `/03-agent-issue-to-pr` in Copilot Chat.
On macOS, press Command-Shift-Period in Finder if `.github` is hidden.

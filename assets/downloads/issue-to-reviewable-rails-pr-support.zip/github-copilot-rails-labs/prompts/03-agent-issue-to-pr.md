# Copilot task prompt 03 · Issue to reviewable PR

Read `parts/03-issue-to-pr/ISSUE.md` and the baseline CaseFlow routes, controller, model and request specs. Open `caseflow/` as your workspace root for its instruction files. This task is a **synthetic lab**, and the operator token is a provisional exercise assumption, not a production authorization decision.

First produce a short plan with exact affected paths, auth boundary and positive/negative tests. Then implement only the issue's scope in a new branch in your own repository or local workspace. Do not edit generated docs or add dependencies merely to make the diff look complete. Use a server-side `CASEFLOW_OPERATOR_TOKEN`, reject missing configuration and invalid tokens, and do not accept arbitrary `status` from request parameters. Include specs for valid, missing-token, wrong-token and invalid-state cases.

Run the focused spec if the environment supports it; quote exact commands and output. If Ruby, Bundler, SQLite or dependencies block execution, report the first reproducible blocker and never claim a pass. Before asking for review, provide a file-by-file diff summary, an evidence table (source assertion versus actual run), remaining production authorization decisions and suggested reviewer questions. Do not merge. Compare your diff to `parts/03-issue-to-pr/candidate.patch` **after** you have generated your own answer; differences may expose assumptions worth discussing.

References: [issue](../parts/03-issue-to-pr/ISSUE.md), [PR worksheet](../parts/03-issue-to-pr/PR-REVIEW.md), [Rails HTTP token authentication](https://guides.rubyonrails.org/action_controller_advanced_topics.html#http-token-authentication).

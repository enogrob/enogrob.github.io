# GitHub Copilot for Rails Engineers

*A source-backed blog series and hands-on integrated CaseFlow Rails app, with one post per future book chapter.*

![A digitized Copilot-inspired guide studies a conceptual CaseFlow Rails interface.](docs/posts/01-first-30-minutes/assets/cover.webp)

The cover shows a **conceptual CaseFlow interface**. This repository contains an integrated Rails API source app, not an implemented web UI. This independent educational project is not affiliated with or endorsed by GitHub or Avanade.

## Contents

- [Start with the eight-part learning map](#start-here-the-eight-part-learning-map)
- [Read post 01](#read-post-01)
- [Read post 02](#read-post-02)
- [Read post 03](#read-post-03)
- [Read post 04](#read-post-04)
- [Read post 05](#read-post-05)
- [Read post 06](#read-post-06)
- [Read post 07](#read-post-07)
- [Read post 08](#read-post-08)
- [Explore the material](#explore-the-material)
- [CaseFlow architecture](#caseflow-architecture)
- [Series parts](parts/README.md)
- [Study and practice](#study-and-practice)
- [Run the lab on your Mac](#run-the-lab-on-your-mac)
- [Evidence map](#evidence-map)
- [Validation status](#validation-status)
- [References](#references)

## Start here: the eight-part learning map

The [complete unnumbered series guide](docs/posts/series-guide/article.md) links to all eight published chapters, states their learning objectives, and offers an interview route and a full hands-on route. Its [optional conceptual prologue](https://enogrob.github.io/artificial-intelligence/software-engineering/agentic-ai/github-copilot/2026/09/23/inside-github-copilot-agentic-engine.html) introduces the broader Copilot architecture without becoming a ninth chapter. The guide's [entrypoint](parts/series-guide/README.md), [synthesis workbook with answers](docs/labs/series-guide-workbook.md), [editable learning diagram](docs/diagrams/series-learning-map.mmd) and [visual masters](docs/posts/series-guide/post-manifest.md) travel with this cumulative package.

## Read post 01

Before tracing the Rails request, try the [Part 01 Copilot CLI initialization lab](parts/01-first-30-minutes/copilot-init-lab.md) in an isolated app copy. `copilot init` proposes project instructions; verify them against the real files and keep the original app unchanged.

**[The First 30 Minutes in an Unfamiliar Rails Repository](docs/posts/01-first-30-minutes/article.md)** is the complete Jekyll Markdown source, including Contents, code, a Mermaid diagram, an exercise and references. It matches the `_posts/` file in the accompanying Jekyll package byte for byte. Site-root image and download URLs in its body are intended for the blog. Open the [cover](docs/posts/01-first-30-minutes/assets/cover.webp) or [section illustration](docs/posts/01-first-30-minutes/assets/evidence-boundary.webp) directly in this package.

## Read post 02

**[Teach Copilot the Rails Context](docs/posts/02-context-and-instructions/article.md)** is the complete second Jekyll post. Its [study workbook and answer key](docs/labs/02-context-workbook.md), [model-scoped instructions](caseflow/.github/instructions/models.instructions.md), [repository guidance](caseflow/.github/copilot-instructions.md), [audit prompt](caseflow/.github/prompts/02-context-audit.prompt.md), [Mermaid source](docs/diagrams/02-context-boundary.mmd), [visual masters](docs/posts/02-context-and-instructions/post-manifest.md) and [Part 02 guide](parts/02-context-and-instructions/README.md) travel together in this companion. Open `caseflow/` as the VS Code workspace root.

## Read post 03

**[From Issue to Reviewable PR](docs/posts/03-issue-to-pr/article.md)** is the complete third Jekyll post. Follow the [lab entrypoint](parts/03-issue-to-pr/README.md): [synthetic issue](parts/03-issue-to-pr/ISSUE.md), [candidate patch](parts/03-issue-to-pr/candidate.patch) over the complete CaseFlow baseline, [Copilot task prompt](caseflow/.github/prompts/03-agent-issue-to-pr.prompt.md), [PR review worksheet](parts/03-issue-to-pr/PR-REVIEW.md), [study workbook and answers](docs/labs/03-issue-to-pr-workbook.md), [editable diagram](docs/diagrams/03-issue-to-pr.mmd) and [visual masters/manifest](docs/posts/03-issue-to-pr/post-manifest.md). The patch fits the baseline but Ruby tests and a real PR remain pending.

**Where to run the Part 03 prompt:** open `caseflow/` in VS Code, then use `.github/prompts/03-agent-issue-to-pr.prompt.md` with `/03-agent-issue-to-pr`. The former `prompts/03-agent-issue-to-pr.md` is a redirect.

## Read post 04

**[Can the Patch Pass the Gates?](docs/posts/04-ci-and-devsecops/article.md)** covers Rails CI, security checks and the human approval boundary. The [Part 04 guide](parts/04-ci-and-devsecops/README.md) links a [staged Actions workflow](parts/04-ci-and-devsecops/rails-pr.yml), [review worksheet](parts/04-ci-and-devsecops/REVIEW-GATES.md), [study workbook and answers](docs/labs/04-ci-and-devsecops-workbook.md), [editable Mermaid source](docs/diagrams/04-ci-evidence.mmd) and [visual manifest](docs/posts/04-ci-and-devsecops/post-manifest.md). The workflow is deliberately **not activated**, and the baseline has no resolved lockfile or observed CI result.

## Read post 05

**[A Copilot Pilot You Can Measure](docs/posts/05-adoption-and-governance/article.md)** is a complete English post on a bounded Rails-team adoption pilot. Its [Part 05 entrypoint](parts/05-adoption-and-governance/README.md) leads to the [blank charter](parts/05-adoption-and-governance/PILOT-CHARTER.md), [aggregate CSV template](parts/05-adoption-and-governance/pilot-observations.csv), [Ruby summarizer](scripts/summarize_pilot.rb), [decision record](parts/05-adoption-and-governance/DECISION-RECORD.md), [workbook and answers](docs/labs/05-pilot-workbook.md), [Mermaid source](docs/diagrams/05-pilot-decision.mmd) and [visual manifest](docs/posts/05-adoption-and-governance/post-manifest.md). No adoption data or productivity claim is supplied.

## Read post 06

**[From Rails Evidence to Client Roadmap](docs/posts/06-client-workshop/article.md)** completes the original six-part arc with a hypothetical facilitated workshop. The [Part 06 guide](parts/06-client-workshop/README.md) leads to an [agenda](parts/06-client-workshop/WORKSHOP-AGENDA.md), [claim ledger](parts/06-client-workshop/CLAIM-LEDGER.md), [one-page roadmap](parts/06-client-workshop/ROADMAP.md), [blank decision record](parts/06-client-workshop/DECISION-RECORD.md), [workbook and answers](docs/labs/06-workshop-workbook.md), [Mermaid source](docs/diagrams/06-workshop-decision.mmd) and [illustrated image masters](docs/posts/06-client-workshop/post-manifest.md). The workshop does not imply a real client decision.

## Read post 07

**[A Rails Change You Can Audit with Copilot CLI](docs/posts/07-cli-rails-change/article.md)** extends the original six-part plan with a terminal-based CaseFlow exercise for macOS. Begin at the [Part 07 runbook](parts/07-cli-rails-change/RUNBOOK.md), then inspect the [two-stage CLI prompt](parts/07-cli-rails-change/CLI-PROMPT.md), [Ruby preflight](scripts/07_caseflow_cli_preflight.rb), [blank evidence ledger](parts/07-cli-rails-change/EVIDENCE-LEDGER.md), [workbook and answers](docs/labs/07-cli-workbook.md), [Mermaid source](docs/diagrams/07-cli-evidence-gates.mmd) and [visual manifest](docs/posts/07-cli-rails-change/post-manifest.md). No Copilot CLI action or Rails test is claimed as run.

## Read post 08

**[A Repeatable Rails Copilot Workflow](docs/posts/08-repeatable-rails-workflow/article.md)** closes this edition by distinguishing instructions, skills, built-in tools, hooks, MCP and human evidence. The [Part 08 entrypoint](parts/08-repeatable-rails-workflow/README.md) links the [workflow blueprint](parts/08-repeatable-rails-workflow/WORKFLOW-BLUEPRINT.md), intentionally [blank evidence JSON](parts/08-repeatable-rails-workflow/EVIDENCE.json), [Ruby structural validator](scripts/08_validate_evidence.rb), [workbook with answers](docs/labs/08-workflow-workbook.md), [Mermaid source](docs/diagrams/08-workflow-boundaries.mmd) and [illustrated visual manifest](docs/posts/08-repeatable-rails-workflow/post-manifest.md). No skill, hook or MCP connection is installed by this chapter.

## Explore the material

| Read next | Why |
|---|---|
| [Study workbook 01, with answers](docs/labs/01-study-workbook.md) | Learn the evidence model, solve seven varied exercises, then check commented answers at the end. |
| [Lab 01 and answer guide](docs/labs/01-codebase-diagnosis.md) | Build the architecture atlas, verify Copilot's map and document unknowns. |
| [Integrated CaseFlow app](caseflow/README.md) | See architecture, gems, SQLite, startup, RSpec, curl requests and a folding sequence diagram. |
| [Generated application guide](docs/architecture/generated-inventory.md) | Regenerate the source inventory, architecture view, dependency table and local runbook. |
| [Artifact-producing Copilot prompt](caseflow/.github/prompts/01-trace-request.prompt.md) | Draft a capability map, Mermaid path, change-impact table and evidence register, then audit them. |
| [Workspace mapping guide](parts/01-first-30-minutes/copilot-workspace.md) | See how Copilot retrieves context and how to turn drafts into reviewed artifacts. |
| [CaseFlow architecture atlas](docs/architecture/README.md) | Navigate capabilities, request path, change impact and evidence; refresh the inventory. |
| [Reviewed request map](parts/01-first-30-minutes/request-map.md) | Compare Copilot output with source-backed claims and the editable diagram. |
| [Mermaid diagram source](docs/diagrams/request-path.mmd) | Edit or reuse the same diagram embedded in the post without extracting it from the article. |
| [Post manifest and visual sources](docs/posts/01-first-30-minutes/post-manifest.md) | Find visuals, PNG masters, QA notes and ebook reuse notes. |
| [Series parts](parts/README.md) | Follow Part 01 and the planned chapter entrypoints. |
| [Series map](docs/series-map.md) | Follow the six independent post outcomes. |
| [Production workflow](docs/production-workflow.md) · [Visual standard](docs/visual-standard.md) | Preserve Factory Blog gates in future posts. |

## CaseFlow architecture

The app is a Rails API with a SQLite database. The Gemfile declares Rails, Puma and the SQLite adapter; RSpec is used for request specs. These are source declarations, and no successful runtime result is claimed here. Open the [app README](caseflow/README.md) for exact gems, routes, local setup, manual API commands and an expandable sequence diagram.

```mermaid
%%{init: {'theme':'base','flowchart':{'useMaxWidth':true,'nodeSpacing':36,'rankSpacing':44,'curve':'basis'},'themeVariables':{'background':'#FFF8EF','primaryTextColor':'#3E342C','lineColor':'#6F7377','fontFamily':'Trebuchet MS, Verdana, sans-serif','fontSize':'13px','clusterBkg':'#FBF4E7','clusterBorder':'#B8A17D'}}}%%
flowchart TD
    U["👤 Client"] --> P["🌐 Puma + Rails API"]
    subgraph app["🧭 CaseFlow"]
      P --> R["🧭 Routes"] --> C["⚙️ Controller"] --> M["🧱 ServiceRequest"]
    end
    M --> D[("SQLite")]
    T["🧪 RSpec"] -.-> P
    classDef input fill:#D9EAF7,stroke:#7AA6C2,color:#3E342C;
    classDef action fill:#F8DFC4,stroke:#C9986D,color:#3E342C;
    classDef model fill:#E8DDF5,stroke:#A68BC4,color:#3E342C;
    classDef data fill:#FFF1BF,stroke:#BA9C43,color:#3E342C;
    classDef test fill:#DCEFD6,stroke:#86A878,color:#3E342C;
    class U,R input;
    class P,C action;
    class M model;
    class D data;
    class T test;
```

## Study and practice

Start with [the complete post](docs/posts/01-first-30-minutes/article.md), then use [Part 01](parts/01-first-30-minutes/README.md) and work through [the pedagogical workbook](docs/labs/01-study-workbook.md). It mixes a short theory section, prediction, source tracing, a deliberately flawed AI answer, evidence matching, a customer scenario and a hands-on lab. Attempt each exercise before reading its answer key. The [field checklist](docs/labs/01-codebase-diagnosis.md) can be used during the hands-on session.

All companion automation uses Ruby. From this repository's root, regenerate the [source inventory](docs/architecture/generated-inventory.md) with `ruby scripts/build_caseflow_inventory.rb`. When the sibling `post-01-jekyll/` folder and its ZIP are present, run `ruby scripts/check_post_visual_contract.rb` to check the Jekyll article and companion release contract.

## Run the lab on your Mac

1. Read the [complete article](docs/posts/01-first-30-minutes/article.md), generate [the inventory](docs/architecture/generated-inventory.md), and make three predictions about `POST /api/requests`.
2. Open [the integrated CaseFlow app](caseflow/README.md) and follow its setup. The integrated app still needs dependency installation and an actual test run.
3. Inspect the files, try the [prompt](caseflow/.github/prompts/01-trace-request.prompt.md), then run the focused spec if setup succeeds.
4. Record your versions, actual commands, results or first blocker in a local `ENVIRONMENT.md` based on [the template](caseflow/ENVIRONMENT.template.md). Do not commit secrets or customer data.

## Evidence map

The diagram below uses GitHub's standard Mermaid fence; the Jekyll article uses the Factory Blog's `mermaid!` fence and matching source in `docs/diagrams/`.

```mermaid
%%{init: {'theme':'base','themeVariables':{'background':'#FFFFFF','primaryTextColor':'#3E342C','lineColor':'#6F7377'}}}%%
flowchart LR
    subgraph inspect["🔍 Inspect source"]
        A["🎯 Request"] --> B["🧭 Route"] --> C["⚙️ Controller"] --> D["🧱 Model"]
    end
    subgraph verify["🧪 Verify claims"]
        D --> E["📋 Test assertion"] --> F["❔ Run or blocker"]
    end
    F --> G["✅ Evidence log"]
    classDef input fill:#D9EAF7,stroke:#7AA6C2,color:#3E342C;
    classDef process fill:#F8DFC4,stroke:#C9986D,color:#3E342C;
    classDef unknown fill:#FFF1BF,stroke:#BA9C43,color:#3E342C;
    classDef result fill:#DCEFD6,stroke:#86A878,color:#3E342C;
    class A,B input;
    class C,D,E process;
    class F unknown;
    class G result;
```

An assertion in source is not a passing result. The evidence log records the actual run **or** a reproducible blocker.

## Validation status

The integrated app was assembled from the inspected source, and Roberto confirmed that the article rendered in his Jekyll blog on 2026-09-25. The cover and section image were approved. The authoring environment still has no installed gems, migrated SQLite database or recorded passing request spec. See [validation status](docs/validation-status.md) and the [post QA manifest](docs/posts/01-first-30-minutes/post-manifest.md). No GitHub remote or license has been selected for this companion project. The integrated app has not been executed in the authoring environment.

## References

- [Full post source and its references](docs/posts/01-first-30-minutes/article.md)
- [GitHub Docs: Explore a codebase with Copilot](https://docs.github.com/en/copilot/tutorials/explore-a-codebase)
- [GitHub Docs: Review AI-generated code](https://docs.github.com/en/copilot/tutorials/review-ai-generated-code)
- [Rails Guides: Routing](https://guides.rubyonrails.org/routing.html)
- [Rails Guides: Active Record Migrations](https://guides.rubyonrails.org/active_record_migrations.html)


**Run the Part 01 prompt:** open `caseflow/` in VS Code and invoke `/01-trace-request` from `.github/prompts/01-trace-request.prompt.md`. Old `prompts/01-trace-request.md` is a redirect.

# Study workbook 03 · From a bounded issue to reviewable evidence

*Read → predict → delegate → inspect → test → review.* Allow 70–90 minutes including setup. Use the [complete article](../posts/03-issue-to-pr/article.md) and the [baseline CaseFlow app](../../caseflow/README.md). Attempt each exercise before opening [the answer key](#answer-key).

## Contents

- [Learning outcomes](#outcomes)
- [Mental model](#model)
- [Exercises](#exercises)
- [Answer key](#answer-key)
- [Retention and transfer](#retention)
- [References](#references)

## Learning outcomes {:#outcomes}

You can turn an ambiguous Rails change into an acceptance-tested issue, frame one bounded agent task, inspect route/auth/validation changes as a diff, demand positive and negative tests, distinguish code assertions from captured results, and write a review decision with explicit product unknowns.

## Mental model {:#model}

A pull request has four separate claims: **intent** (issue), **proposed implementation** (diff), **expected contract** (spec assertions), and **observed outcome** (test run). A fifth item, **product authority**, decides who may invoke a transition. The patch in this package supplies the first three as a lab proposal; the fourth is pending and the fifth is intentionally unresolved for production.

| Artifact | Locate | Can prove |
|---|---|---|
| Issue | [`ISSUE.md`](../../parts/03-issue-to-pr/ISSUE.md) | What this synthetic exercise proposes |
| Candidate diff | [`candidate.patch`](../../parts/03-issue-to-pr/candidate.patch) | Which files would change |
| Request specs in patch | Patch's `spec/requests/api/requests_spec.rb` hunk | Which outcomes are asserted |
| Focused run log | Your own environment notes | What happened on your Mac |
| Review decision | [`PR-REVIEW.md`](../../parts/03-issue-to-pr/PR-REVIEW.md) | What remains blocked or approved for the lab |

The [editable Mermaid source](../diagrams/03-issue-to-pr.mmd) shows a test branch that may end in a blocker. Do not redraw that branch as an unconditional green check.

## Exercises {:#exercises}

### 1 · Sharpen a vague issue (7 minutes)

Rewrite “users can update status” into exactly five acceptance bullets. Include an actor, an allowed transition, an unauthorized case, a rejected state and a verification requirement. Mark which actor assumption is synthetic.

### 2 · Predict the diff (8 minutes)

Before opening the candidate patch, list the minimum baseline files you expect to change and one file you **should not** need to change. Check against `git apply --stat parts/03-issue-to-pr/candidate.patch`. Does a route declaration alone implement authorization?

### 3 · Find a plausible agent mistake (8 minutes)

Review this fictional change: `resources :requests`; `request.update!(params.require(:request).permit(:status))`; one spec asserts `200`. Identify four review problems. Write a comment that cites two real CaseFlow paths.

### 4 · Negative-path matrix (10 minutes)

Fill in expected response and persisted status for the candidate: (a) open + valid token, (b) open + missing token, (c) open + wrong token, (d) in_progress + valid token, (e) token env var not configured. Which rows have explicit candidate specs? Which still need a spec or runtime check?

### 5 · Apply and observe (20 minutes plus setup)

From the companion root, run `git apply --check parts/03-issue-to-pr/candidate.patch`, then apply the patch in a clean copy. From `caseflow/`, try `RAILS_ENV=test bin/rails db:prepare` and `bundle exec rspec spec/requests/api/requests_spec.rb`. Write the exact command, exit status and the first failure or passing output. If Ruby or Bundler is missing, report that blocker rather than filling in a hypothetical result.

### 6 · Review a security claim (10 minutes)

A PR draft says “the token makes the endpoint production-secure.” Distinguish what the source enforces from what still requires a business and infrastructure decision. Address credential management, identity, HTTPS, audit and concurrent requests in one review comment. Explain why these are not invented test outcomes.

### 7 · Choose a review verdict (7 minutes)

Complete the [PR worksheet](../../parts/03-issue-to-pr/PR-REVIEW.md) with **changes requested**, **evidence pending** or **acceptable for the lab only**. Justify using one source path, one negative spec and one observed result or blocker. What is the next item for Part 04's CI and DevSecOps discussion?

## Answer key

1. Example: synthetic operator token required; only open → resolved permitted; missing/wrong token denied with state unchanged; in_progress rejected with state unchanged; record focused RSpec command and actual result. A real client must approve the actor model; [`ISSUE.md`](../../parts/03-issue-to-pr/ISSUE.md) states it is provisional.
2. [`config/routes.rb`](../../caseflow/config/routes.rb), [`requests_controller.rb`](../../caseflow/app/controllers/api/requests_controller.rb) and [`requests_spec.rb`](../../caseflow/spec/requests/api/requests_spec.rb) are the three candidate paths. No migration is needed because [`status` already exists](../../caseflow/db/migrate/20260925000000_create_service_requests.rb). The route alone is public unless the action enforces the proposed guard.
3. `resources :requests` opens unrelated actions; mass-assigned status allows values and transitions without the acceptance boundary; there is no token check; one happy-path spec misses unauthorized and invalid states. Cite [baseline routes](../../caseflow/config/routes.rb) and [controller strong parameters](../../caseflow/app/controllers/api/requests_controller.rb) in a review comment.
4. Proposed expectations: (a) 200/resolved; (b) 401/open; (c) 401/open; (d) 409/in_progress; (e) denied/open. (a–d) have request specs in the patch; (e) is enforced by the source guard but lacks a dedicated example and needs a local check. A response value is still an expectation until a run is recorded.
5. `git apply --check` was completed against the prepared baseline during authoring; Rails/RSpec were **not run** here. Write down what happened on *your* machine. A missing interpreter is a valid, reproducible blocker, not an answer of “passed.”
6. Source reads a server-side environment value, denies empty configuration and compares tokens; it does not define real operator identity, rotation or revocation, guarantee HTTPS, produce an audit trail, or prevent a race between state check and update. Flag those as deployment decisions in review.
7. Without an actual run and approved production actor policy, “evidence pending” or “changes requested” is justified. “Acceptable for the lab only” requires a passing run and scope review recorded by the learner, and still does not approve production deployment. Part 04 can add an observable CI/security gate after deciding what it enforces.

## Retention and transfer {:#retention}

Tomorrow, without reading the answer key, explain why a patch that applies cleanly and contains four specs can still be unreviewed. In another Rails service, identify a transition's actor, state boundary and negative test before asking an agent to code it.

## References

- [Article and primary references](../posts/03-issue-to-pr/article.md)
- [CaseFlow issue](../../parts/03-issue-to-pr/ISSUE.md)
- [Rails token authentication](https://guides.rubyonrails.org/action_controller_advanced_topics.html#http-token-authentication)
- [GitHub review agent output](https://docs.github.com/en/copilot/how-tos/copilot-on-github/use-copilot-agents/review-copilot-output)

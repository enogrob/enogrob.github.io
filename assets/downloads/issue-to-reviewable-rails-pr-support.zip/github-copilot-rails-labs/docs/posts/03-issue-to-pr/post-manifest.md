# Post 03 production manifest

## Contents

- [Brief and source](#brief)
- [Visual script](#visual)
- [Release checks](#checks)
- [References](#references)

## Brief and source {:#brief}

**Reader:** Rails engineer using VS Code and optionally GitHub Copilot cloud agent. **Question:** how does a bounded issue become a reviewable Rails diff rather than an unexamined agent output? **Deliverable:** source-backed article, synthetic issue, real patch over full app, positive/negative specs inside patch, PR worksheet, workbook and answers. **Limits:** shared operator token only for lab; no customer authorization decision, no real PR, no executed RSpec or HTTP response in authoring environment.

Technical source: baseline [`caseflow/`](../../../caseflow/README.md); diff [`candidate.patch`](../../../parts/03-issue-to-pr/candidate.patch). GitHub agent capabilities checked against current official GitHub documentation; token helper checked against Rails guide. Article Markdown is byte-identical to the accompanying Jekyll `_posts/` source.

## Visual script {:#visual}

| Asset | Specific reader question | Review reference |
|---|---|---|
| [`cover.webp`](assets/cover.webp) | How does an issue become an inspectable agent diff and human-reviewed PR candidate? A digitized Copilot-inspired character in side profile points toward a centered PR dossier showing the actual change surface: route, action and specs, plus an unresolved policy note; an orbital multicolor Holoflux and green network express the series identity | Previous [Part 02 cover](../02-context-and-instructions/assets/cover.webp) required series eyebrow `GITHUB COPILOT FOR RAILS ENGINEERS · PART 03`, same heading hierarchy with distinct scene and an active inspecting profile distinct from the previous cover pose; [PNG master](assets/cover-source.png) |
| [`review-diff.webp`](assets/review-diff.webp) | What should a reviewer examine before accepting an agent's change? A central operator-token guard in cross-section with valid-token, no-token and wrong-state specimens; run still pending | Previous [Part 02 internal image](../02-context-and-instructions/assets/context-boundary.webp) informs thin green title and short labels; [PNG master](assets/review-diff-source.png) |
| [Mermaid source](../../diagrams/03-issue-to-pr.mmd) | Where does test failure or blocked setup branch before a PR decision? | Deterministic source equals article block |

Additional references: [Part 01 cover](../01-first-30-minutes/assets/cover.webp) and [Bohm Holoflux approved post](https://enogrob.github.io/artificial-intelligence/architecture/agentic-ai/philosophy/2026/09/22/intelligence-in-motion-bohm-holoflux-ai-agents.html). No invented file names or passing outcomes are drawn in the illustrations.

## Release checks {:#checks}

- Part 03 series eyebrow, headline and subtitle visually read from WebP; both assets are 1600×900, center chapter-specific factual artifacts and use Canonical Flow patterns in the surrounding field; cover and section use distinct character-led dossier and mechanical cross-section metaphors. Provisional editorial scores (1–5): historical fit 4; canonical background 4; motion/depth 4; article content fit 4; cross-image continuity 4; thumbnail 4; semantic color 4; text accuracy 4. Human blog preview remains pending.
- Article matches support copy byte for byte; Mermaid block matches `.mmd`; package includes all linked Markdown and assets; candidate patch passes `git apply --check` against the clean CaseFlow baseline.
- Ruby/RSpec, Jekyll render, actual Copilot session, API curl and CI were not run here. The prospective PR remains a local worksheet. Runtime and customer authorization are not approved.

## References {:#references}

- [Full article](article.md)
- [Study workbook and answers](../../labs/03-issue-to-pr-workbook.md)
- [Series visual contract](../../visual-standard.md)

# Series parts

Each part owns an entrypoint and its own reviewable evidence. The shared [`caseflow/` Rails app](../caseflow/README.md) evolves through the series; content assets remain linked by part.

- [Part 01](01-first-30-minutes/README.md)
- [Part 02](02-context-and-instructions/README.md)
- [Part 03 · Reviewable PR candidate](03-issue-to-pr/README.md)
- [Part 04](04-ci-and-devsecops/README.md)
- [Part 05](05-adoption-and-governance/README.md)
- [Part 06](06-client-workshop/README.md)

## References

- [Series map](../docs/series-map.md)

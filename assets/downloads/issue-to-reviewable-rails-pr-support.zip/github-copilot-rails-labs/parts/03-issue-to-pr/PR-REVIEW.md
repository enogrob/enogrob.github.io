# PR review worksheet · CaseFlow resolve candidate

*This is a review exercise. No GitHub PR, agent run, test pass or deployment is claimed.*

## Contents

- [Change summary](#summary)
- [Review findings](#findings)
- [Verification log](#verification)
- [Decision](#decision)
- [References](#references)

## Change summary {:#summary}

Apply [the candidate patch](candidate.patch) to the baseline CaseFlow app to inspect one route, one controller action/authentication guard and four request specs. The proposed endpoint permits a single `open → resolved` transition under a synthetic operator token.

## Review findings {:#findings}

| Priority | Inspect | Question to answer before approval |
|---|---|---|
| Must resolve | `caseflow/app/controllers/api/requests_controller.rb` | Is a shared operator token the correct customer authorization policy? This exercise cannot approve it for production. |
| Must resolve | `caseflow/spec/requests/api/requests_spec.rb` | Are success, no token, wrong token and invalid state asserted without claiming a pass? What about unset environment configuration? |
| Must resolve | `caseflow/config/routes.rb` | Is `resolve` narrowly exposed without accepting arbitrary status? |
| Follow up | Model and database | How will concurrent resolves, audit trail and idempotency be handled? Not covered by this patch. |
| Evidence | Focused and whole request specs | Record exact command, exit code, failures and environment before calling this PR green. |

**Review comment example:** “The source enforces an operator token for this endpoint, but the issue deliberately leaves the production actor policy undecided. Please confirm authorization requirements, capture local spec results and add an unset-token negative test before this is considered deployable.”

## Verification log {:#verification}

| Command | Exit status | Observed output | Notes |
|---|---|---|---|
| `git apply --check parts/03-issue-to-pr/candidate.patch` | Static check in prepared package: succeeded | Patch applies to clean baseline | Recheck after any local changes |
| `bundle exec rspec spec/requests/api/requests_spec.rb` | Not run here | Pending on your Mac | Run from `caseflow/` after applying patch |
| Manual `curl` valid / invalid | Not run here | Pending | Use synthetic credentials only |

## Decision {:#decision}

**Current state: candidate for review, not approved for deployment.** Fill the verification log with actual output. Resolve the customer authorization decision and failure cases before changing this verdict.

## References

- [Issue and acceptance criteria](ISSUE.md)
- [Article and source links](../../docs/posts/03-issue-to-pr/article.md)
- [GitHub Docs: review Copilot output](https://docs.github.com/en/copilot/how-tos/copilot-on-github/use-copilot-agents/review-copilot-output)

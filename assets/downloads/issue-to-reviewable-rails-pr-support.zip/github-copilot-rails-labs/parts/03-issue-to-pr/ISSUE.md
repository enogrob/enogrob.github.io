# CaseFlow issue · Resolve an open request (lab candidate)

## Contents

- [Context](#context)
- [Proposed decision for the exercise](#decision)
- [Acceptance criteria](#acceptance)
- [Non-goals and unknowns](#unknowns)
- [References](#references)

## Context {:#context}

Part 01 traced `POST /api/requests`; Part 02 supplied scoped instructions. The baseline [routes](../../caseflow/config/routes.rb) have no update endpoint. The [model](../../caseflow/app/models/service_request.rb) permits storing `resolved`, but clients cannot request that transition today.

## Proposed decision for the exercise {:#decision}

For this **synthetic lab only**, add `PATCH /api/requests/:id/resolve` to transition **open → resolved**. Protect it with a single operator token read from `CASEFLOW_OPERATOR_TOKEN` on the server. Missing configuration and missing/incorrect token must deny the request. Use synthetic values in tests. This is an exercise assumption, **not an approved customer identity or authorization policy**. Production needs a decision about actors, permissions, token rotation, audit events, HTTPS, observability and concurrent updates.

## Acceptance criteria {:#acceptance}

| Case | Expected behavior from proposed patch | Evidence needed |
|---|---|---|
| Open request + correct operator token | `200`, selected JSON shows `resolved`, persisted status changed | Focused request spec run |
| No token or wrong token | `401`; status stays `open` | Negative request specs |
| `in_progress` + correct token | `409` with clear error; original status preserved | Negative request spec |
| Token env var missing | Denied; no public fallback | Inspect guard and add a local probe if desired |
| Existing create, index and show | Existing behavior unchanged | Entire request spec file run |

## Non-goals and unknowns {:#unknowns}

- No generic `PATCH /api/requests/:id` and no mass-assigned status.
- No new gem, migration, background job or UI.
- Missing-id response, concurrent resolves, token rotation and production authorization are **not established** by this teaching patch. Record them as review findings before any real deployment.
- No command output or CI result is asserted in this issue.

## References

- [Candidate patch](candidate.patch)
- [PR review template](PR-REVIEW.md)
- [Rails token authentication guide](https://guides.rubyonrails.org/action_controller_advanced_topics.html#http-token-authentication)

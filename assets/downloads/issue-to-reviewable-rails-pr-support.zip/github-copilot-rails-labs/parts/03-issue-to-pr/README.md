# Part 03 · From issue to reviewable PR

This part delivers a complete [article](../../docs/posts/03-issue-to-pr/article.md), [issue](ISSUE.md), [agent task prompt](../../prompts/03-agent-issue-to-pr.md), [candidate patch](candidate.patch), [PR worksheet](PR-REVIEW.md), [Mermaid source](../../docs/diagrams/03-issue-to-pr.mmd), and [workbook with answers](../../docs/labs/03-issue-to-pr-workbook.md). The baseline [CaseFlow app](../../caseflow/README.md) remains integrated and unmodified; applying the candidate patch creates the proposed feature locally.

## Contents

- [Lab path](#path)
- [Exact commands](#commands)
- [Review boundary](#review)
- [References](#references)

## Lab path {:#path}

Read the issue before showing an agent the patch. Ask for a plan and source-cited diff. Compare the agent's proposed change to the reviewed candidate. Inspect positive and negative specs, run what your Mac supports, and fill in the PR worksheet with actual output or a first blocker.

## Exact commands {:#commands}

From the **companion repository root**:

```bash
git apply --check parts/03-issue-to-pr/candidate.patch
git apply --stat parts/03-issue-to-pr/candidate.patch
git apply parts/03-issue-to-pr/candidate.patch
cd caseflow
bundle install
RAILS_ENV=test bin/rails db:prepare
bundle exec rspec spec/requests/api/requests_spec.rb
```

To undo the exercise on a clean companion checkout from its root, run `git apply -R parts/03-issue-to-pr/candidate.patch`; inspect any local changes first. If using the ZIP without `.git`, `git apply` can still apply a patch to the supplied files from this root. When running the server for a manual synthetic request, follow the [article](../../docs/posts/03-issue-to-pr/article.md#verify) and never commit a real token.

## Review boundary {:#review}

The patch is **not** a live PR or production authorization policy. The run was not completed in the authoring environment. The token and allowed transition are exercise assumptions; get a product/security decision and actual verification before treating the endpoint as deployable.

## References

- [Article](../../docs/posts/03-issue-to-pr/article.md)
- [GitHub Copilot quickstart](https://docs.github.com/en/copilot/get-started/quickstart-for-using-github-copilot-on-github-com)
- [Rails HTTP token authentication](https://guides.rubyonrails.org/action_controller_advanced_topics.html#http-token-authentication)

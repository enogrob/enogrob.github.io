# Ruby in the Age of AI — support material

This small prototype accompanies the post **Ruby in the Age of AI**. It is intentionally dependency-free: Ruby's standard library is enough.

## What it demonstrates

The prototype treats Ruby as an authoring language for AI-native domain concepts. A DSL declaration becomes a semantic model that can be projected into JSON, Markdown, Mermaid, agent definitions, runtime configuration, or other platform adapters.

## Run it

```bash
ruby -v
ruby examples/agents.rb
ruby examples/sdlc.rb
ruby examples/generate.rb
```

Generated files appear in `generated/`.

## Structure

```text
support/
├── README.md
├── examples/
│   ├── agents.rb
│   ├── generate.rb
│   └── sdlc.rb
├── lib/
│   ├── ruby_ai_dsl.rb
│   └── ruby_ai_dsl/
│       ├── agent.rb
│       ├── definition.rb
│       ├── lifecycle.rb
│       └── renderers.rb
├── diagrams/
└── generated/
```

## Core idea

```ruby
agent :discovery do
  knows :product
  uses :github, :rag
  produces :discovery_report
end
```

This is not intended as a production framework yet. It is a minimal executable experiment showing that Ruby DSLs can model agent vocabulary, lifecycle semantics, and generated artifacts without reducing the idea to static configuration.

## Mermaid visual standard

The diagrams in this package follow the current `factory-blog` convention:

- Jekyll front matter enables `mermaid: true`.
- Blog fences use `mermaid!` rather than the legacy `mermaid` fence.
- The blog owns the global Mermaid renderer configuration; diagram sources avoid local `%%{init...}%%` blocks.
- Diagram text is rendered by the factory at the canonical compact size (about 13 px).
- Adaptive article widths are used by complexity: compact ~480 px, medium ~520 px, large up to ~600 px.
- Every functional node uses a semantic icon/emoticon.
- Semantic pastel colors distinguish roles without implying invented status or severity.
- `subgraph` is used only for real conceptual boundaries such as shaping, building, assurance, delivery, behavior, context, and projections.
- Large graphs are reorganized into compact grouped flows rather than stretched into oversized horizontal diagrams.
- Labels remain short and readable on mobile; edges use a neutral, theme-resilient line color.


## Additional diagram

- `diagrams/rails-world-to-ai-native-ruby.mmd` — the central thesis diagram connecting Rails-era DSLs to AI-native Ruby.


## 60-second quickstart

```bash
ruby examples/generate.rb
```

Then inspect:

```text
generated/
├── caseflow.json
├── caseflow.md
└── caseflow.mmd
```

The same Ruby semantic model is projected into machine-readable data, documentation, and a Mermaid diagram.

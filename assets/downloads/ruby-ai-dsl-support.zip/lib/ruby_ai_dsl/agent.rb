# frozen_string_literal: true

require_relative "definition"

module RubyAIDSL
  class Agent < Definition
    def initialize(name, &block)
      super(:agent, name, &block)
    end

    def goal(value) = set(:goal, value)
    def phase(value) = set(:phase, value.to_sym)
    def knows(*values) = list(:knowledge, *values)
    def observes(*values) = list(:observes, *values)
    def uses(*values) = list(:tools, *values)
    def skills(*values) = list(:skills, *values)
    def produces(*values) = list(:outputs, *values)
    def distinguishes(*values) = list(:distinguishes, *values)
    def hands_off_to(value, when_: nil) = set(:handoff, { to: value.to_sym, when: when_ })
    def policy(value) = list(:policies, value)
  end
end

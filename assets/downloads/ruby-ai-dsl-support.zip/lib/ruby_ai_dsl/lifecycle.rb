# frozen_string_literal: true

require_relative "definition"

module RubyAIDSL
  class Phase < Definition
    def initialize(name, &block)
      super(:phase, name, &block)
    end

    def goal(value) = set(:goal, value)
    def sources(*values) = list(:sources, *values)
    def understand(*values) = list(:understand, *values)
    def consume(*values) = list(:consumes, *values)
    def produce(*values) = list(:produces, *values)
    def verify(*values) = list(:verifies, *values)
    def observe(*values) = list(:observes, *values)
    def learn_from(*values) = list(:learns_from, *values)
    def feed_into(value) = set(:feeds_into, value.to_sym)
    def require_all(*values) = list(:requires, *values)
    def distinguish(*values) = list(:distinguishes, *values)
    def implement(value) = set(:implements, value.to_sym)
    def deploy(value) = set(:deploys, value.to_sym)
  end

  class Lifecycle < Definition
    PHASES = %i[discovery planning architecture development testing review release production feedback].freeze

    def initialize(name, &block)
      super(:sdlc, name, &block)
    end

    PHASES.each do |phase_name|
      define_method(phase_name) do |&block|
        node = Phase.new(phase_name, &block)
        @children << node
        node
      end
    end
  end
end

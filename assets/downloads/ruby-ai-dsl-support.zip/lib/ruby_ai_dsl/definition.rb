# frozen_string_literal: true

module RubyAIDSL
  class Definition
    attr_reader :kind, :name, :attributes, :children

    def initialize(kind, name = nil, &block)
      @kind = kind.to_sym
      @name = name&.to_sym
      @attributes = {}
      @children = []
      instance_eval(&block) if block
    end

    def set(key, value)
      @attributes[key.to_sym] = value
      self
    end

    def list(key, *values)
      @attributes[key.to_sym] = values.flatten.map { |v| normalize(v) }
      self
    end

    def child(kind, name = nil, &block)
      node = self.class.new(kind, name, &block)
      @children << node
      node
    end

    def to_h
      {
        kind: kind,
        name: name,
        attributes: attributes,
        children: children.map(&:to_h)
      }.compact
    end

    private

    def normalize(value)
      value.respond_to?(:to_sym) ? value.to_sym : value
    end
  end
end

# frozen_string_literal: true

require "json"

module RubyAIDSL
  module Renderers
    module_function

    EMOJI = {
      discovery: "🔎", planning: "📋", architecture: "🏗️", development: "💻",
      testing: "🧪", review: "🔍", release: "🚀", production: "📊", feedback: "🔁"
    }.freeze

    PHASE_CLASS = {
      discovery: "discover", planning: "plan", architecture: "architecture",
      development: "development", testing: "quality", review: "quality",
      release: "release", production: "production", feedback: "feedback"
    }.freeze

    def json(model)
      JSON.pretty_generate(model.to_h)
    end

    # Mermaid output follows the factory-blog convention:
    # semantic pastel classes, functional icons, natural subgraphs, compact labels,
    # and no per-diagram init block (the blog owns the global Mermaid rendering config).
    def lifecycle_mermaid(lifecycle)
      phases = lifecycle.children
      ids = phases.to_h { |phase| [phase.name, phase.name.to_s.upcase] }
      by_name = phases.to_h { |phase| [phase.name, phase] }

      lines = ["flowchart TB"]
      groups = [
        ["SHAPE", "🧭 Shape the work", %i[discovery planning architecture]],
        ["BUILD", "🛠️ Build and assure", %i[development testing review]],
        ["OPERATE", "🌐 Deliver and learn", %i[release production feedback]]
      ]

      groups.each do |key, label, names|
        present = names.select { |name| by_name.key?(name) }
        next if present.empty?

        lines << %(    subgraph #{key}["#{label}"])
        lines << "      direction LR"
        present.each_cons(2) do |left, right|
          lines << %(      #{node(ids[left], by_name[left])} --> #{node(ids[right], by_name[right])})
        end
        lines << %(      #{node(ids[present.first], by_name[present.first])}) if present.length == 1
        lines << "    end"
        lines << ""
      end

      lines << "    ARCHITECTURE --> DEVELOPMENT" if ids[:architecture] && ids[:development]
      lines << "    REVIEW --> RELEASE" if ids[:review] && ids[:release]
      lines << %(    FEEDBACK -. "continuous learning" .-> DISCOVERY) if ids[:feedback] && ids[:discovery]
      lines << ""
      lines.concat(lifecycle_class_defs)
      lines << "    linkStyle default stroke:#6F7377,stroke-width:1.5px;"
      lines.join("\n")
    end

    def agents_mermaid(agents)
      lines = ["flowchart LR"]
      agents.each do |agent|
        id = agent.name.to_s.upcase
        lines << %(    #{id}["🤖 #{humanize(agent.name)} Agent"]:::agent)
      end
      agents.each do |agent|
        next unless (handoff = agent.attributes[:handoff])

        from = agent.name.to_s.upcase
        to = handoff[:to].to_s.upcase
        label = handoff[:when] ? %( |"#{handoff[:when]}"| ) : " --> "
        lines << (handoff[:when] ? "    #{from} -->|#{handoff[:when]}| #{to}" : "    #{from} --> #{to}")
      end
      lines << ""
      lines << "    classDef agent fill:#D9EAF7,stroke:#5E8FB8,color:#3E342C,stroke-width:1.5px;"
      lines << "    linkStyle default stroke:#6F7377,stroke-width:1.5px;"
      lines.join("\n")
    end

    def markdown(model)
      out = ["# #{humanize(model.name || model.kind)}", ""]
      out << "Kind: `#{model.kind}`"
      out << ""
      model.children.each do |child|
        out << "## #{humanize(child.name || child.kind)}"
        child.attributes.each do |key, value|
          out << "- **#{humanize(key)}:** #{Array(value).join(', ')}"
        end
        out << ""
      end
      out.join("\n")
    end

    def node(id, phase)
      emoji = EMOJI.fetch(phase.name, "🔹")
      klass = PHASE_CLASS.fetch(phase.name, "phase")
      %(#{id}["#{emoji} #{humanize(phase.name)}"]:::#{klass})
    end

    def lifecycle_class_defs
      [
        "    classDef discover fill:#D9EAF7,stroke:#5E8FB8,color:#3E342C,stroke-width:1.5px;",
        "    classDef plan fill:#E8DDF5,stroke:#8B6DB1,color:#3E342C,stroke-width:1.5px;",
        "    classDef architecture fill:#FFF1BF,stroke:#C59B20,color:#3E342C,stroke-width:1.5px;",
        "    classDef development fill:#DDF3EA,stroke:#5F9D86,color:#3E342C,stroke-width:1.5px;",
        "    classDef quality fill:#D9EAF7,stroke:#5E8FB8,color:#3E342C,stroke-width:1.5px;",
        "    classDef release fill:#F8DFC4,stroke:#C97A40,color:#3E342C,stroke-width:1.5px;",
        "    classDef production fill:#DCEFD6,stroke:#6D9E63,color:#3E342C,stroke-width:1.5px;",
        "    classDef feedback fill:#FFF1BF,stroke:#C59B20,color:#3E342C,stroke-width:1.5px;",
        "    classDef phase fill:#DDF3EA,stroke:#5F9D86,color:#3E342C,stroke-width:1.5px;"
      ]
    end

    def humanize(value)
      value.to_s.split("_").map(&:capitalize).join(" ")
    end
  end
end

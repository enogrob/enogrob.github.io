# frozen_string_literal: true

require_relative "ruby_ai_dsl/agent"
require_relative "ruby_ai_dsl/lifecycle"
require_relative "ruby_ai_dsl/renderers"

module RubyAIDSL
  class World
    attr_reader :agents, :lifecycles

    def initialize(&block)
      @agents = []
      @lifecycles = []
      instance_eval(&block) if block
    end

    def agent(name, &block)
      Agent.new(name, &block).tap { |agent| @agents << agent }
    end

    def sdlc(name, &block)
      Lifecycle.new(name, &block).tap { |lifecycle| @lifecycles << lifecycle }
    end
  end

  module_function

  def define(&block)
    World.new(&block)
  end
end

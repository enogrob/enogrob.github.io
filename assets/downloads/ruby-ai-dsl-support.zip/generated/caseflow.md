# Caseflow

Kind: `sdlc`

## Discovery
- **Produces:** discovery_report

## Planning
- **Consumes:** discovery_report
- **Produces:** prioritized_backlog

## Architecture
- **Produces:** adr, component_map

## Development
- **Implements:** approved_architecture

## Testing
- **Verifies:** critical_flows

## Review
- **Verifies:** quality, security

## Release
- **Requires:** passing_tests
- **Deploys:** production

## Production
- **Observes:** metrics, logs, traces

## Feedback
- **Learns From:** production
- **Feeds Into:** discovery

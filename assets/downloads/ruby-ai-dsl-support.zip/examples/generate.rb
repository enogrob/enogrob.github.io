# frozen_string_literal: true

require "fileutils"
$LOAD_PATH.unshift File.expand_path("../lib", __dir__)
require "ruby_ai_dsl"

world = RubyAIDSL.define do
  sdlc :caseflow do
    discovery { produce :discovery_report }
    planning { consume :discovery_report; produce :prioritized_backlog }
    architecture { produce :adr, :component_map }
    development { implement :approved_architecture }
    testing { verify :critical_flows }
    review { verify :quality, :security }
    release { require_all :passing_tests; deploy :production }
    production { observe :metrics, :logs, :traces }
    feedback { learn_from :production; feed_into :discovery }
  end
end

root = File.expand_path("..", __dir__)
out = File.join(root, "generated")
FileUtils.mkdir_p(out)

lifecycle = world.lifecycles.fetch(0)
File.write(File.join(out, "caseflow.json"), RubyAIDSL::Renderers.json(lifecycle))
File.write(File.join(out, "caseflow.md"), RubyAIDSL::Renderers.markdown(lifecycle))
File.write(File.join(out, "caseflow.mmd"), RubyAIDSL::Renderers.lifecycle_mermaid(lifecycle))

puts "Generated: #{out}"

# frozen_string_literal: true

$LOAD_PATH.unshift File.expand_path("../lib", __dir__)
require "ruby_ai_dsl"

world = RubyAIDSL.define do
  sdlc :caseflow do
    discovery do
      goal "Understand the problem before proposing solutions"
      sources :customer_interviews, :support_tickets, :roadmap, :architecture_docs
      distinguish :evidence, :inference, :unknowns
      produce :discovery_report
    end

    planning do
      consume :discovery_report
      produce :prioritized_backlog, :acceptance_criteria
    end

    architecture do
      consume :discovery_report
      produce :adr, :component_map, :api_contract
    end

    development do
      implement :approved_architecture
    end

    testing do
      verify :business_rules, :integrations, :critical_flows
    end

    review do
      verify :quality, :security, :compliance
    end

    release do
      require_all :passing_tests, :approved_review
      deploy :production
    end

    production do
      observe :metrics, :logs, :traces, :events
    end

    feedback do
      learn_from :customers, :usage, :incidents
      feed_into :discovery
    end
  end
end

lifecycle = world.lifecycles.fetch(0)

puts RubyAIDSL::Renderers.json(lifecycle)
puts
puts RubyAIDSL::Renderers.lifecycle_mermaid(lifecycle)

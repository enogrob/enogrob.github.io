# frozen_string_literal: true

$LOAD_PATH.unshift File.expand_path("../lib", __dir__)
require "ruby_ai_dsl"

world = RubyAIDSL.define do
  agent :discovery do
    goal "Understand the problem before proposing solutions"
    phase :discovery
    observes :customer_interviews, :support_tickets, :roadmap
    knows :product, :architecture
    distinguishes :evidence, :inference, :unknowns
    skills :product_discovery
    uses :github, :rag
    produces :discovery_report
    hands_off_to :planning
  end

  agent :planning do
    goal "Shape evidence into actionable delivery work"
    phase :planning
    knows :product
    uses :github
    produces :prioritized_backlog, :acceptance_criteria
  end
end

puts RubyAIDSL::Renderers.json(world.agents.first)
puts
puts RubyAIDSL::Renderers.agents_mermaid(world.agents)

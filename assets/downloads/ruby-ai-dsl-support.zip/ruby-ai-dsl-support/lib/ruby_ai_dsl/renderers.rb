# frozen_string_literal: true

require "json"

module RubyAIDSL
  module Renderers
    module_function

    OPERATIONS_STYLE = {
      service: ["🌐", "service"],
      incident: ["🚨", "incident"],
      runbook: ["📚", "runbook"],
      policy: ["🛡️", "policy"],
      postmortem: ["📝", "postmortem"]
    }.freeze

    def json(model)
      JSON.pretty_generate(model.to_h)
    end

    # Mermaid output follows the factory-blog convention:
    # semantic pastel classes, functional icons, natural subgraphs, compact labels,
    # and no per-diagram init block (the blog owns the global Mermaid rendering config).
    def operations_mermaid(operations)
      children = operations.children
      ids = {}
      used = Hash.new(0)
      children.each do |child|
        base = (child.name || child.kind).to_s.upcase.gsub(/[^A-Z0-9_]/, "_")
        used[base] += 1
        ids[child.object_id] = used[base] > 1 ? "#{base}_#{used[base]}" : base
      end

      lines = ["flowchart TB"]
      groups = [
        ["SERVICES", "🌐 Services", :service],
        ["DETECT", "🚨 Detect and respond", :incident],
        ["RESPOND", "🛠️ Respond", :runbook],
        ["GOVERN", "🛡️ Govern", :policy],
        ["LEARN", "🔁 Learn", :postmortem]
      ]

      groups.each do |key, label, kind|
        nodes = children.select { |child| child.kind == kind }
        next if nodes.empty?

        lines << %(    subgraph #{key}["#{label}"])
        lines << "      direction LR"
        nodes.each do |node|
          emoji, klass = OPERATIONS_STYLE.fetch(kind)
          lines << %(      #{ids[node.object_id]}["#{emoji} #{humanize(node.name || node.kind)}"]:::#{klass})
        end
        lines << "    end"
        lines << ""
      end

      incidents = children.select { |child| child.kind == :incident }
      runbooks = children.select { |child| child.kind == :runbook }
      postmortems = children.select { |child| child.kind == :postmortem }

      incidents.each do |incident|
        runbooks.each do |runbook|
          lines << %(    #{ids[incident.object_id]} -->|"consults"| #{ids[runbook.object_id]})
        end
        postmortems.each do |postmortem|
          lines << %(    #{ids[incident.object_id]} --> #{ids[postmortem.object_id]})
        end
      end
      if postmortems.any? && runbooks.any?
        lines << %(    #{ids[postmortems.first.object_id]} -. "improves" .-> #{ids[runbooks.first.object_id]})
      end

      lines << ""
      lines.concat(operations_class_defs)
      lines << "    linkStyle default stroke:#6F7377,stroke-width:1.5px;"
      lines.join("\n")
    end

    def agents_mermaid(agents)
      lines = ["flowchart LR"]
      agents.each do |agent|
        id = agent.name.to_s.upcase
        lines << %(    #{id}["🤖 #{humanize(agent.name)} Agent"]:::agent)
      end
      agents.each do |agent|
        next unless (handoff = agent.attributes[:handoff])

        from = agent.name.to_s.upcase
        to = handoff[:to].to_s.upcase
        lines << (handoff[:when] ? "    #{from} -->|#{handoff[:when]}| #{to}" : "    #{from} --> #{to}")
      end
      lines << ""
      lines << "    classDef agent fill:#D9EAF7,stroke:#5E8FB8,color:#3E342C,stroke-width:1.5px;"
      lines << "    linkStyle default stroke:#6F7377,stroke-width:1.5px;"
      lines.join("\n")
    end

    def markdown(model)
      out = ["# #{humanize(model.name || model.kind)}", ""]
      out << "Kind: `#{model.kind}`"
      out << ""
      model.children.each do |child|
        out << "## #{humanize(child.name || child.kind)}"
        child.attributes.each do |key, value|
          out << "- **#{humanize(key)}:** #{format_value(value)}"
        end
        out << ""
      end
      out.join("\n")
    end

    def format_value(value)
      case value
      when Array then value.join(", ")
      when Hash then value.map { |k, v| "#{humanize(k)}: #{v}" }.join(", ")
      else value.to_s
      end
    end

    def operations_class_defs
      [
        "    classDef service fill:#D9EAF7,stroke:#5E8FB8,color:#3E342C,stroke-width:1.5px;",
        "    classDef incident fill:#F8DFC4,stroke:#C97A40,color:#3E342C,stroke-width:1.5px;",
        "    classDef runbook fill:#DDF3EA,stroke:#5F9D86,color:#3E342C,stroke-width:1.5px;",
        "    classDef policy fill:#DCEFD6,stroke:#6D9E63,color:#3E342C,stroke-width:1.5px;",
        "    classDef postmortem fill:#FFF1BF,stroke:#C59B20,color:#3E342C,stroke-width:1.5px;"
      ]
    end

    def humanize(value)
      value.to_s.split("_").map(&:capitalize).join(" ")
    end
  end
end

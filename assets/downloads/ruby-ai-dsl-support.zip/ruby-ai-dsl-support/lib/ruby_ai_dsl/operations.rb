# frozen_string_literal: true

require_relative "definition"

module RubyAIDSL
  class Service < Definition
    def initialize(name, &block)
      super(:service, name, &block)
    end

    def stack(*values) = list(:stack, *values)
    def sla(**targets) = set(:sla, targets)
  end

  class IncidentHandler < Definition
    def initialize(trigger, &block)
      super(:handler, trigger, &block)
    end

    def page(value) = set(:pages, value.to_sym)
    def converge_at(value) = set(:converges_at, value.to_sym)

    def parallel(&block)
      instance_eval(&block)
      set(:parallel_tracks, @tracks || [])
    end

    def investigate(*values)
      (@tracks ||= []) << values.flatten.map { |v| v.to_sym }
    end
  end

  class Incident < Definition
    def initialize(name, &block)
      super(:incident, name, &block)
    end

    def severity(value) = set(:severity, value.to_sym)
    def signals(*values) = list(:signals, *values)

    def on(trigger, &block)
      node = IncidentHandler.new(trigger, &block)
      @children << node
      node
    end

    def escalate_to(value, if: nil)
      set(:escalation, { to: value.to_sym, if: binding.local_variable_get(:if) })
    end
  end

  class Runbook < Definition
    def initialize(name, &block)
      super(:runbook, name, &block)
    end

    def knows(*values) = list(:knowledge, *values)
    def uses(*values) = list(:tools, *values)
  end

  class Policy < Definition
    def initialize(name, &block)
      super(:policy, name, &block)
    end

    def require(*values) = list(:requires, *values)
    def require_audit_log = set(:audit_log, true)
  end

  class Postmortem < Definition
    def initialize(&block)
      super(:postmortem, nil, &block)
    end

    def required_after(*values) = list(:required_after, *values)
    def produce(*values) = list(:produces, *values)
    def feed_into(*values) = list(:feeds_into, *values)
  end

  class Operations < Definition
    def initialize(name, &block)
      super(:operations, name, &block)
    end

    def service(name, &block) = attach(Service.new(name, &block))
    def incident(name, &block) = attach(Incident.new(name, &block))
    def runbook(name, &block) = attach(Runbook.new(name, &block))
    def policy(name, &block) = attach(Policy.new(name, &block))
    def postmortem(&block) = attach(Postmortem.new(&block))

    private

    def attach(node)
      @children << node
      node
    end
  end
end

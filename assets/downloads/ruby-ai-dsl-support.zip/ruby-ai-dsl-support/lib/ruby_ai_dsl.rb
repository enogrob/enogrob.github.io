# frozen_string_literal: true

require_relative "ruby_ai_dsl/agent"
require_relative "ruby_ai_dsl/operations"
require_relative "ruby_ai_dsl/renderers"

module RubyAIDSL
  class World
    attr_reader :agents

    def initialize(&block)
      @agents = []
      @operations = []
      instance_eval(&block) if block
    end

    def agent(name, &block)
      Agent.new(name, &block).tap { |agent| @agents << agent }
    end

    # DSL entry point and collection reader in one:
    #   operations :caseflow do ... end   # declares a model
    #   world.operations                  # returns all declared models
    def operations(name = nil, &block)
      return @operations if name.nil? && block.nil?

      Operations.new(name, &block).tap { |ops| @operations << ops }
    end
  end

  module_function

  def define(&block)
    World.new(&block)
  end
end

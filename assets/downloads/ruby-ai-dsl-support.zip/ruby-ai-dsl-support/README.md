# Ruby in the Age of AI — support material

This small prototype accompanies the post **Ruby in the Age of AI**. It is intentionally dependency-free: Ruby's standard library is enough.

## What it demonstrates

The prototype treats Ruby as an authoring language for AI-native domain concepts. A DSL declaration becomes a semantic model that can be projected into JSON, Markdown, Mermaid, agent definitions, runtime configuration, or other platform adapters.

## Run it

```bash
ruby -v
ruby examples/agents.rb
ruby examples/operations.rb
ruby examples/generate.rb
```

Generated files appear in `generated/`.

## Structure

```text
ruby-ai-dsl-support/
├── README.md
├── examples/
│   ├── agents.rb
│   ├── generate.rb
│   └── operations.rb
├── lib/
│   ├── ruby_ai_dsl.rb
│   └── ruby_ai_dsl/
│       ├── agent.rb
│       ├── definition.rb
│       ├── operations.rb
│       └── renderers.rb
├── diagrams/
└── generated/
```

## Core idea

```ruby
operations :caseflow do
  service(:web_app) { sla availability: 0.999 }
  incident(:elevated_error_rate) { severity :critical }
  runbook(:database_health) { uses :observability_platform }
  policy(:production_access) { require :on_call_rotation; require_audit_log }
  postmortem { required_after :critical; produce :timeline, :action_items }
end
```

This is not intended as a production framework yet. It is a minimal executable experiment showing that Ruby DSLs can model agent vocabulary, production operations semantics, and generated artifacts without reducing the idea to static configuration.

## Mermaid visual standard

The diagrams in this package follow the current `factory-blog` convention:

- Jekyll front matter enables `mermaid: true`.
- Blog fences use `mermaid!` rather than the legacy `mermaid` fence.
- The blog owns the global Mermaid renderer configuration; diagram sources avoid local `%%{init...}%%` blocks.
- Diagram text is rendered by the factory at the canonical compact size (about 13 px).
- Adaptive article widths are used by complexity: compact ~480 px, medium ~520 px, large up to ~600 px.
- Every functional node uses a semantic icon/emoticon.
- Semantic pastel colors distinguish roles without implying invented status or severity.
- `subgraph` is used only for real conceptual boundaries such as detection, response, learning, behavior, context, and projections.
- Large graphs are reorganized into compact grouped flows rather than stretched into oversized horizontal diagrams.
- Labels remain short and readable on mobile; edges use a neutral, theme-resilient line color.

## Additional diagrams

- `diagrams/rails-world-to-ai-native-ruby.mmd` — the central thesis diagram connecting Rails-era DSLs to AI-native Ruby.
- `diagrams/operations-as-a-program.mmd` — the operations flow (detect, resolve, learn) declared by the DSL example.
- `diagrams/agents-in-operations.mmd` — the operations agent graph: monitoring, triage, investigation, mitigation, communication, and postmortem.

# frozen_string_literal: true

require "fileutils"
$LOAD_PATH.unshift File.expand_path("../lib", __dir__)
require "ruby_ai_dsl"

world = RubyAIDSL.define do
  operations :caseflow do
    service(:web_app) { sla availability: 0.999 }
    incident(:elevated_error_rate) { severity :critical }
    runbook(:database_health) { uses :observability_platform }
    policy(:production_access) { require :on_call_rotation; require_audit_log }
    postmortem { required_after :critical; produce :timeline, :action_items }
  end
end

root = File.expand_path("..", __dir__)
out = File.join(root, "generated")
FileUtils.mkdir_p(out)

operations = world.operations.fetch(0)
File.write(File.join(out, "caseflow.json"), RubyAIDSL::Renderers.json(operations))
File.write(File.join(out, "caseflow.md"), RubyAIDSL::Renderers.markdown(operations))
File.write(File.join(out, "caseflow.mmd"), RubyAIDSL::Renderers.operations_mermaid(operations))

puts "Generated: #{out}"

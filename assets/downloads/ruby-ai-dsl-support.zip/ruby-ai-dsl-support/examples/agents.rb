# frozen_string_literal: true

$LOAD_PATH.unshift File.expand_path("../lib", __dir__)
require "ruby_ai_dsl"

world = RubyAIDSL.define do
  agent :triage do
    goal "Classify severity and assemble initial context within minutes"
    observes :metrics, :logs, :traces, :customer_reports
    knows :runbooks, :service_catalog
    skills :incident_triage
    uses :observability_platform, :pagerduty
    produces :triage_summary
    hands_off_to :investigation
  end

  agent :investigation do
    goal "Correlate signals and identify the likely root cause"
    knows :runbooks, :recent_deploys
    skills :root_cause_analysis
    uses :observability_platform, :rails_console_readonly
    produces :root_cause_hypothesis
    hands_off_to :mitigation
  end

  agent :postmortem do
    goal "Turn incidents into durable operational knowledge"
    knows :incident_timeline, :action_items
    skills :facilitation, :technical_writing
    uses :github, :documentation
    produces :postmortem_report
    hands_off_to :triage, when_: "runbooks updated"
  end
end

puts RubyAIDSL::Renderers.json(world.agents.first)
puts
puts RubyAIDSL::Renderers.agents_mermaid(world.agents)

# frozen_string_literal: true

$LOAD_PATH.unshift File.expand_path("../lib", __dir__)
require "ruby_ai_dsl"

world = RubyAIDSL.define do
  operations "CaseFlow" do
    service :web_app do
      stack :rails, :postgresql, :redis
      sla availability: 0.999
    end

    incident :elevated_error_rate do
      severity :critical

      signals :error_rate_spike,
              :p95_latency_above_threshold,
              :customer_reports

      on :trigger do
        page :on_call_engineer

        parallel do
          investigate :recent_deploys
          investigate :database_health
          investigate :dependency_outages
        end

        converge_at :triage_summary
      end

      escalate_to :incident_commander,
                  if: :unresolved_after_30_minutes
    end

    runbook :database_health do
      knows :connection_pooling,
            :replication_lag,
            :slow_query_log

      uses :observability_platform,
           :rails_console_readonly
    end

    policy :production_access do
      require :on_call_rotation
      require :mfa
      require_audit_log
    end

    postmortem do
      required_after :critical
      produce :timeline,
              :root_cause,
              :action_items

      feed_into :runbooks,
                :monitoring
    end
  end
end

operations = world.operations.fetch(0)

puts RubyAIDSL::Renderers.json(operations)
puts
puts RubyAIDSL::Renderers.operations_mermaid(operations)

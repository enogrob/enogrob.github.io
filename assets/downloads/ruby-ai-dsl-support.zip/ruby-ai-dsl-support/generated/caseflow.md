# Caseflow

Kind: `operations`

## Web App
- **Sla:** Availability: 0.999

## Elevated Error Rate
- **Severity:** critical

## Database Health
- **Tools:** observability_platform

## Production Access
- **Requires:** on_call_rotation
- **Audit Log:** true

## Postmortem
- **Required After:** critical
- **Produces:** timeline, action_items
